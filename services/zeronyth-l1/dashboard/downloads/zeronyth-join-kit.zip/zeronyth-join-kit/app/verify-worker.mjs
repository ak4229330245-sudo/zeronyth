import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// economy/lib/verify-worker.mjs
import { parentPort } from "node:worker_threads";

// economy/node_modules/ethers/lib.esm/_version.js
var version = "6.17.0";

// economy/node_modules/ethers/lib.esm/utils/properties.js
function checkType(value, type, name) {
  const types = type.split("|").map((t3) => t3.trim());
  for (let i = 0; i < types.length; i++) {
    switch (type) {
      case "any":
        return;
      case "bigint":
      case "boolean":
      case "number":
      case "string":
        if (typeof value === type) {
          return;
        }
    }
  }
  const error = new Error(`invalid value for type ${type}`);
  error.code = "INVALID_ARGUMENT";
  error.argument = `value.${name}`;
  error.value = value;
  throw error;
}
function defineProperties(target, values, types) {
  for (let key in values) {
    let value = values[key];
    const type = types ? types[key] : null;
    if (type) {
      checkType(value, type, key);
    }
    Object.defineProperty(target, key, { enumerable: true, value, writable: false });
  }
}

// economy/node_modules/ethers/lib.esm/utils/errors.js
function stringify(value, seen) {
  if (value == null) {
    return "null";
  }
  if (seen == null) {
    seen = /* @__PURE__ */ new Set();
  }
  if (typeof value === "object") {
    if (seen.has(value)) {
      return "[Circular]";
    }
    seen.add(value);
  }
  if (Array.isArray(value)) {
    return "[ " + value.map((v) => stringify(v, seen)).join(", ") + " ]";
  }
  if (value instanceof Uint8Array) {
    const HEX = "0123456789abcdef";
    let result = "0x";
    for (let i = 0; i < value.length; i++) {
      result += HEX[value[i] >> 4];
      result += HEX[value[i] & 15];
    }
    return result;
  }
  if (typeof value === "object" && typeof value.toJSON === "function") {
    return stringify(value.toJSON(), seen);
  }
  switch (typeof value) {
    case "boolean":
    case "number":
    case "symbol":
      return value.toString();
    case "bigint":
      return BigInt(value).toString();
    case "string":
      return JSON.stringify(value);
    case "object": {
      const keys = Object.keys(value);
      keys.sort();
      return "{ " + keys.map((k) => `${stringify(k, seen)}: ${stringify(value[k], seen)}`).join(", ") + " }";
    }
  }
  return `[ COULD NOT SERIALIZE ]`;
}
function makeError(message, code, info) {
  let shortMessage = message;
  {
    const details = [];
    if (info) {
      if ("message" in info || "code" in info || "name" in info) {
        throw new Error(`value will overwrite populated values: ${stringify(info)}`);
      }
      for (const key in info) {
        if (key === "shortMessage") {
          continue;
        }
        const value = info[key];
        details.push(key + "=" + stringify(value));
      }
    }
    details.push(`code=${code}`);
    details.push(`version=${version}`);
    if (details.length) {
      message += " (" + details.join(", ") + ")";
    }
  }
  let error;
  switch (code) {
    case "INVALID_ARGUMENT":
      error = new TypeError(message);
      break;
    case "NUMERIC_FAULT":
    case "BUFFER_OVERRUN":
      error = new RangeError(message);
      break;
    default:
      error = new Error(message);
  }
  defineProperties(error, { code });
  if (info) {
    Object.assign(error, info);
  }
  if (error.shortMessage == null) {
    defineProperties(error, { shortMessage });
  }
  return error;
}
function assert(check, message, code, info) {
  if (!check) {
    throw makeError(message, code, info);
  }
}
function assertArgument(check, message, name, value) {
  assert(check, message, "INVALID_ARGUMENT", { argument: name, value });
}
var _normalizeForms = ["NFD", "NFC", "NFKD", "NFKC"].reduce((accum, form) => {
  try {
    if ("test".normalize(form) !== "test") {
      throw new Error("bad");
    }
    ;
    if (form === "NFD") {
      const check = String.fromCharCode(233).normalize("NFD");
      const expected = String.fromCharCode(101, 769);
      if (check !== expected) {
        throw new Error("broken");
      }
    }
    accum.push(form);
  } catch (error) {
  }
  return accum;
}, []);
function assertPrivate(givenGuard, guard, className) {
  if (className == null) {
    className = "";
  }
  if (givenGuard !== guard) {
    let method = className, operation = "new";
    if (className) {
      method += ".";
      operation += " " + className;
    }
    assert(false, `private constructor; use ${method}from* methods`, "UNSUPPORTED_OPERATION", {
      operation
    });
  }
}

// economy/node_modules/ethers/lib.esm/utils/data.js
function _getBytes(value, name, copy) {
  if (value instanceof Uint8Array) {
    if (copy) {
      return new Uint8Array(value);
    }
    return value;
  }
  if (typeof value === "string" && value.length % 2 === 0 && value.match(/^0x[0-9a-f]*$/i)) {
    const result = new Uint8Array((value.length - 2) / 2);
    let offset = 2;
    for (let i = 0; i < result.length; i++) {
      result[i] = parseInt(value.substring(offset, offset + 2), 16);
      offset += 2;
    }
    return result;
  }
  assertArgument(false, "invalid BytesLike value", name || "value", value);
}
function getBytes(value, name) {
  return _getBytes(value, name, false);
}
function getBytesCopy(value, name) {
  return _getBytes(value, name, true);
}
function isHexString(value, length) {
  if (typeof value !== "string" || !value.match(/^0x[0-9A-Fa-f]*$/)) {
    return false;
  }
  if (typeof length === "number" && value.length !== 2 + 2 * length) {
    return false;
  }
  if (length === true && value.length % 2 !== 0) {
    return false;
  }
  return true;
}
function isBytesLike(value) {
  return isHexString(value, true) || value instanceof Uint8Array;
}
var HexCharacters = "0123456789abcdef";
function hexlify(data) {
  const bytes2 = getBytes(data);
  let result = "0x";
  for (let i = 0; i < bytes2.length; i++) {
    const v = bytes2[i];
    result += HexCharacters[(v & 240) >> 4] + HexCharacters[v & 15];
  }
  return result;
}
function concat(datas) {
  return "0x" + datas.map((d) => hexlify(d).substring(2)).join("");
}
function dataLength(data) {
  if (isHexString(data, true)) {
    return (data.length - 2) / 2;
  }
  return getBytes(data).length;
}
function zeroPad(data, length, left) {
  const bytes2 = getBytes(data);
  assert(length >= bytes2.length, "padding exceeds data length", "BUFFER_OVERRUN", {
    buffer: new Uint8Array(bytes2),
    length,
    offset: length + 1
  });
  const result = new Uint8Array(length);
  result.fill(0);
  if (left) {
    result.set(bytes2, length - bytes2.length);
  } else {
    result.set(bytes2, 0);
  }
  return hexlify(result);
}
function zeroPadValue(data, length) {
  return zeroPad(data, length, true);
}

// economy/node_modules/ethers/lib.esm/utils/maths.js
var BN_0 = BigInt(0);
var BN_1 = BigInt(1);
var maxValue = 9007199254740991;
function getBigInt(value, name) {
  switch (typeof value) {
    case "bigint":
      return value;
    case "number":
      assertArgument(Number.isInteger(value), "underflow", name || "value", value);
      assertArgument(value >= -maxValue && value <= maxValue, "overflow", name || "value", value);
      return BigInt(value);
    case "string":
      try {
        if (value === "") {
          throw new Error("empty string");
        }
        if (value[0] === "-" && value[1] !== "-") {
          return -BigInt(value.substring(1));
        }
        return BigInt(value);
      } catch (e) {
        assertArgument(false, `invalid BigNumberish string: ${e.message}`, name || "value", value);
      }
  }
  assertArgument(false, "invalid BigNumberish value", name || "value", value);
}
function getUint(value, name) {
  const result = getBigInt(value, name);
  assert(result >= BN_0, "unsigned value cannot be negative", "NUMERIC_FAULT", {
    fault: "overflow",
    operation: "getUint",
    value
  });
  return result;
}
function getNumber(value, name) {
  switch (typeof value) {
    case "bigint":
      assertArgument(value >= -maxValue && value <= maxValue, "overflow", name || "value", value);
      return Number(value);
    case "number":
      assertArgument(Number.isInteger(value), "underflow", name || "value", value);
      assertArgument(value >= -maxValue && value <= maxValue, "overflow", name || "value", value);
      return value;
    case "string":
      try {
        if (value === "") {
          throw new Error("empty string");
        }
        return getNumber(BigInt(value), name);
      } catch (e) {
        assertArgument(false, `invalid numeric string: ${e.message}`, name || "value", value);
      }
  }
  assertArgument(false, "invalid numeric value", name || "value", value);
}
function toBeHex(_value, _width) {
  const value = getUint(_value, "value");
  let result = value.toString(16);
  if (_width == null) {
    if (result.length % 2) {
      result = "0" + result;
    }
  } else {
    const width = getNumber(_width, "width");
    if (width === 0 && value === BN_0) {
      return "0x";
    }
    assert(width * 2 >= result.length, `value exceeds width (${width} bytes)`, "NUMERIC_FAULT", {
      operation: "toBeHex",
      fault: "overflow",
      value: _value
    });
    while (result.length < width * 2) {
      result = "0" + result;
    }
  }
  return "0x" + result;
}
function toBeArray(_value, _width) {
  const value = getUint(_value, "value");
  if (value === BN_0) {
    const width = _width != null ? getNumber(_width, "width") : 0;
    return new Uint8Array(width);
  }
  let hex = value.toString(16);
  if (hex.length % 2) {
    hex = "0" + hex;
  }
  if (_width != null) {
    const width = getNumber(_width, "width");
    while (hex.length < width * 2) {
      hex = "00" + hex;
    }
    assert(width * 2 === hex.length, `value exceeds width (${width} bytes)`, "NUMERIC_FAULT", {
      operation: "toBeArray",
      fault: "overflow",
      value: _value
    });
  }
  const result = new Uint8Array(hex.length / 2);
  for (let i = 0; i < result.length; i++) {
    const offset = i * 2;
    result[i] = parseInt(hex.substring(offset, offset + 2), 16);
  }
  return result;
}

// economy/node_modules/ethers/lib.esm/utils/rlp-decode.js
function hexlifyByte(value) {
  let result = value.toString(16);
  while (result.length < 2) {
    result = "0" + result;
  }
  return "0x" + result;
}
function unarrayifyInteger(data, offset, length) {
  let result = 0;
  for (let i = 0; i < length; i++) {
    result = result * 256 + data[offset + i];
  }
  return result;
}
function _decodeChildren(data, offset, childOffset, length) {
  const result = [];
  while (childOffset < offset + 1 + length) {
    const decoded = _decode(data, childOffset);
    result.push(decoded.result);
    childOffset += decoded.consumed;
    assert(childOffset <= offset + 1 + length, "child data too short", "BUFFER_OVERRUN", {
      buffer: data,
      length,
      offset
    });
  }
  return { consumed: 1 + length, result };
}
function _decode(data, offset) {
  assert(data.length !== 0, "data too short", "BUFFER_OVERRUN", {
    buffer: data,
    length: 0,
    offset: 1
  });
  const checkOffset = (offset2) => {
    assert(offset2 <= data.length, "data short segment too short", "BUFFER_OVERRUN", {
      buffer: data,
      length: data.length,
      offset: offset2
    });
  };
  if (data[offset] >= 248) {
    const lengthLength = data[offset] - 247;
    checkOffset(offset + 1 + lengthLength);
    const length = unarrayifyInteger(data, offset + 1, lengthLength);
    checkOffset(offset + 1 + lengthLength + length);
    return _decodeChildren(data, offset, offset + 1 + lengthLength, lengthLength + length);
  } else if (data[offset] >= 192) {
    const length = data[offset] - 192;
    checkOffset(offset + 1 + length);
    return _decodeChildren(data, offset, offset + 1, length);
  } else if (data[offset] >= 184) {
    const lengthLength = data[offset] - 183;
    checkOffset(offset + 1 + lengthLength);
    const length = unarrayifyInteger(data, offset + 1, lengthLength);
    checkOffset(offset + 1 + lengthLength + length);
    const result = hexlify(data.slice(offset + 1 + lengthLength, offset + 1 + lengthLength + length));
    return { consumed: 1 + lengthLength + length, result };
  } else if (data[offset] >= 128) {
    const length = data[offset] - 128;
    checkOffset(offset + 1 + length);
    const result = hexlify(data.slice(offset + 1, offset + 1 + length));
    return { consumed: 1 + length, result };
  }
  return { consumed: 1, result: hexlifyByte(data[offset]) };
}
function decodeRlp(_data) {
  const data = getBytes(_data, "data");
  const decoded = _decode(data, 0);
  assertArgument(decoded.consumed === data.length, "unexpected junk after rlp payload", "data", _data);
  return decoded.result;
}

// economy/node_modules/ethers/lib.esm/utils/rlp-encode.js
function arrayifyInteger(value) {
  const result = [];
  while (value) {
    result.unshift(value & 255);
    value >>= 8;
  }
  return result;
}
function _encode(object) {
  if (Array.isArray(object)) {
    let payload = [];
    object.forEach(function(child) {
      payload = payload.concat(_encode(child));
    });
    if (payload.length <= 55) {
      payload.unshift(192 + payload.length);
      return payload;
    }
    const length2 = arrayifyInteger(payload.length);
    length2.unshift(247 + length2.length);
    return length2.concat(payload);
  }
  const data = Array.prototype.slice.call(getBytes(object, "object"));
  if (data.length === 1 && data[0] <= 127) {
    return data;
  } else if (data.length <= 55) {
    data.unshift(128 + data.length);
    return data;
  }
  const length = arrayifyInteger(data.length);
  length.unshift(183 + length.length);
  return length.concat(data);
}
var nibbles = "0123456789abcdef";
function encodeRlp(object) {
  let result = "0x";
  for (const v of _encode(object)) {
    result += nibbles[v >> 4];
    result += nibbles[v & 15];
  }
  return result;
}

// economy/node_modules/ethers/lib.esm/crypto/crypto.js
import { createHash, createHmac, pbkdf2Sync, randomBytes } from "crypto";

// economy/node_modules/@noble/hashes/esm/_assert.js
function number(n) {
  if (!Number.isSafeInteger(n) || n < 0)
    throw new Error(`Wrong positive integer: ${n}`);
}
function bytes(b, ...lengths) {
  if (!(b instanceof Uint8Array))
    throw new Error("Expected Uint8Array");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error(`Expected Uint8Array of length ${lengths}, not of length=${b.length}`);
}
function hash(hash2) {
  if (typeof hash2 !== "function" || typeof hash2.create !== "function")
    throw new Error("Hash should be wrapped by utils.wrapConstructor");
  number(hash2.outputLen);
  number(hash2.blockLen);
}
function exists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function output(out, instance) {
  bytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error(`digestInto() expects output buffer of length at least ${min}`);
  }
}

// economy/node_modules/@noble/hashes/esm/_u64.js
var U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
var _32n = /* @__PURE__ */ BigInt(32);
function fromBig(n, le2 = false) {
  if (le2)
    return { h: Number(n & U32_MASK64), l: Number(n >> _32n & U32_MASK64) };
  return { h: Number(n >> _32n & U32_MASK64) | 0, l: Number(n & U32_MASK64) | 0 };
}
function split(lst, le2 = false) {
  let Ah = new Uint32Array(lst.length);
  let Al = new Uint32Array(lst.length);
  for (let i = 0; i < lst.length; i++) {
    const { h, l } = fromBig(lst[i], le2);
    [Ah[i], Al[i]] = [h, l];
  }
  return [Ah, Al];
}
var rotlSH = (h, l, s) => h << s | l >>> 32 - s;
var rotlSL = (h, l, s) => l << s | h >>> 32 - s;
var rotlBH = (h, l, s) => l << s - 32 | h >>> 64 - s;
var rotlBL = (h, l, s) => h << s - 32 | l >>> 64 - s;

// economy/node_modules/@noble/hashes/esm/cryptoNode.js
import * as nc from "node:crypto";
var crypto = nc && typeof nc === "object" && "webcrypto" in nc ? nc.webcrypto : void 0;

// economy/node_modules/@noble/hashes/esm/utils.js
var u8a = (a) => a instanceof Uint8Array;
var u32 = (arr) => new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
var createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
var rotr = (word, shift) => word << 32 - shift | word >>> shift;
var isLE = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
if (!isLE)
  throw new Error("Non little-endian hardware is not supported");
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  if (!u8a(data))
    throw new Error(`expected Uint8Array, got ${typeof data}`);
  return data;
}
function concatBytes(...arrays) {
  const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
  let pad = 0;
  arrays.forEach((a) => {
    if (!u8a(a))
      throw new Error("Uint8Array expected");
    r.set(a, pad);
    pad += a.length;
  });
  return r;
}
var Hash = class {
  // Safe version that clones internal state
  clone() {
    return this._cloneInto();
  }
};
var toStr = {}.toString;
function wrapConstructor(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}
function wrapXOFConstructorWithOpts(hashCons) {
  const hashC = (msg, opts) => hashCons(opts).update(toBytes(msg)).digest();
  const tmp = hashCons({});
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = (opts) => hashCons(opts);
  return hashC;
}
function randomBytes2(bytesLength = 32) {
  if (crypto && typeof crypto.getRandomValues === "function") {
    return crypto.getRandomValues(new Uint8Array(bytesLength));
  }
  throw new Error("crypto.getRandomValues must be defined");
}

// economy/node_modules/@noble/hashes/esm/sha3.js
var [SHA3_PI, SHA3_ROTL, _SHA3_IOTA] = [[], [], []];
var _0n = /* @__PURE__ */ BigInt(0);
var _1n = /* @__PURE__ */ BigInt(1);
var _2n = /* @__PURE__ */ BigInt(2);
var _7n = /* @__PURE__ */ BigInt(7);
var _256n = /* @__PURE__ */ BigInt(256);
var _0x71n = /* @__PURE__ */ BigInt(113);
for (let round = 0, R = _1n, x = 1, y = 0; round < 24; round++) {
  [x, y] = [y, (2 * x + 3 * y) % 5];
  SHA3_PI.push(2 * (5 * y + x));
  SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
  let t3 = _0n;
  for (let j = 0; j < 7; j++) {
    R = (R << _1n ^ (R >> _7n) * _0x71n) % _256n;
    if (R & _2n)
      t3 ^= _1n << (_1n << /* @__PURE__ */ BigInt(j)) - _1n;
  }
  _SHA3_IOTA.push(t3);
}
var [SHA3_IOTA_H, SHA3_IOTA_L] = /* @__PURE__ */ split(_SHA3_IOTA, true);
var rotlH = (h, l, s) => s > 32 ? rotlBH(h, l, s) : rotlSH(h, l, s);
var rotlL = (h, l, s) => s > 32 ? rotlBL(h, l, s) : rotlSL(h, l, s);
function keccakP(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds; round < 24; round++) {
    for (let x = 0; x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0; x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0; y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t3 = 0; t3 < 24; t3++) {
      const shift = SHA3_ROTL[t3];
      const Th = rotlH(curH, curL, shift);
      const Tl = rotlL(curH, curL, shift);
      const PI = SHA3_PI[t3];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0; y < 50; y += 10) {
      for (let x = 0; x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0; x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H[round];
    s[1] ^= SHA3_IOTA_L[round];
  }
  B.fill(0);
}
var Keccak = class _Keccak extends Hash {
  // NOTE: we accept arguments in bytes instead of bits here.
  constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
    super();
    this.blockLen = blockLen;
    this.suffix = suffix;
    this.outputLen = outputLen;
    this.enableXOF = enableXOF;
    this.rounds = rounds;
    this.pos = 0;
    this.posOut = 0;
    this.finished = false;
    this.destroyed = false;
    number(outputLen);
    if (0 >= this.blockLen || this.blockLen >= 200)
      throw new Error("Sha3 supports only keccak-f1600 function");
    this.state = new Uint8Array(200);
    this.state32 = u32(this.state);
  }
  keccak() {
    keccakP(this.state32, this.rounds);
    this.posOut = 0;
    this.pos = 0;
  }
  update(data) {
    exists(this);
    const { blockLen, state } = this;
    data = toBytes(data);
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      for (let i = 0; i < take; i++)
        state[this.pos++] ^= data[pos++];
      if (this.pos === blockLen)
        this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished)
      return;
    this.finished = true;
    const { state, suffix, pos, blockLen } = this;
    state[pos] ^= suffix;
    if ((suffix & 128) !== 0 && pos === blockLen - 1)
      this.keccak();
    state[blockLen - 1] ^= 128;
    this.keccak();
  }
  writeInto(out) {
    exists(this, false);
    bytes(out);
    this.finish();
    const bufferOut = this.state;
    const { blockLen } = this;
    for (let pos = 0, len = out.length; pos < len; ) {
      if (this.posOut >= blockLen)
        this.keccak();
      const take = Math.min(blockLen - this.posOut, len - pos);
      out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
      this.posOut += take;
      pos += take;
    }
    return out;
  }
  xofInto(out) {
    if (!this.enableXOF)
      throw new Error("XOF is not possible for this instance");
    return this.writeInto(out);
  }
  xof(bytes2) {
    number(bytes2);
    return this.xofInto(new Uint8Array(bytes2));
  }
  digestInto(out) {
    output(out, this);
    if (this.finished)
      throw new Error("digest() was already called");
    this.writeInto(out);
    this.destroy();
    return out;
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen));
  }
  destroy() {
    this.destroyed = true;
    this.state.fill(0);
  }
  _cloneInto(to2) {
    const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
    to2 || (to2 = new _Keccak(blockLen, suffix, outputLen, enableXOF, rounds));
    to2.state32.set(this.state32);
    to2.pos = this.pos;
    to2.posOut = this.posOut;
    to2.finished = this.finished;
    to2.rounds = rounds;
    to2.suffix = suffix;
    to2.outputLen = outputLen;
    to2.enableXOF = enableXOF;
    to2.destroyed = this.destroyed;
    return to2;
  }
};
var gen = (suffix, blockLen, outputLen) => wrapConstructor(() => new Keccak(blockLen, suffix, outputLen));
var sha3_224 = /* @__PURE__ */ gen(6, 144, 224 / 8);
var sha3_256 = /* @__PURE__ */ gen(6, 136, 256 / 8);
var sha3_384 = /* @__PURE__ */ gen(6, 104, 384 / 8);
var sha3_512 = /* @__PURE__ */ gen(6, 72, 512 / 8);
var keccak_224 = /* @__PURE__ */ gen(1, 144, 224 / 8);
var keccak_256 = /* @__PURE__ */ gen(1, 136, 256 / 8);
var keccak_384 = /* @__PURE__ */ gen(1, 104, 384 / 8);
var keccak_512 = /* @__PURE__ */ gen(1, 72, 512 / 8);
var genShake = (suffix, blockLen, outputLen) => wrapXOFConstructorWithOpts((opts = {}) => new Keccak(blockLen, suffix, opts.dkLen === void 0 ? outputLen : opts.dkLen, true));
var shake128 = /* @__PURE__ */ genShake(31, 168, 128 / 8);
var shake256 = /* @__PURE__ */ genShake(31, 136, 256 / 8);

// economy/node_modules/ethers/lib.esm/crypto/keccak.js
var locked = false;
var _keccak256 = function(data) {
  return keccak_256(data);
};
var __keccak256 = _keccak256;
function keccak256(_data) {
  const data = getBytes(_data, "data");
  return hexlify(__keccak256(data));
}
keccak256._ = _keccak256;
keccak256.lock = function() {
  locked = true;
};
keccak256.register = function(func) {
  if (locked) {
    throw new TypeError("keccak256 is locked");
  }
  __keccak256 = func;
};
Object.freeze(keccak256);

// economy/node_modules/@noble/hashes/esm/_sha2.js
function setBigUint64(view, byteOffset, value, isLE2) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE2);
  const _32n2 = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n2 & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE2 ? 4 : 0;
  const l = isLE2 ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE2);
  view.setUint32(byteOffset + l, wl, isLE2);
}
var SHA2 = class extends Hash {
  constructor(blockLen, outputLen, padOffset, isLE2) {
    super();
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE2;
    this.finished = false;
    this.length = 0;
    this.pos = 0;
    this.destroyed = false;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    exists(this);
    const { view, buffer, blockLen } = this;
    data = toBytes(data);
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    exists(this);
    output(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE: isLE2 } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    this.buffer.subarray(pos).fill(0);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i = pos; i < blockLen; i++)
      buffer[i] = 0;
    setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE2);
    this.process(view, 0);
    const oview = createView(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE2);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to2) {
    to2 || (to2 = new this.constructor());
    to2.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to2.length = length;
    to2.pos = pos;
    to2.finished = finished;
    to2.destroyed = destroyed;
    if (length % blockLen)
      to2.buffer.set(buffer);
    return to2;
  }
};

// economy/node_modules/@noble/hashes/esm/sha256.js
var Chi = (a, b, c) => a & b ^ ~a & c;
var Maj = (a, b, c) => a & b ^ a & c ^ b & c;
var SHA256_K = /* @__PURE__ */ new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var IV = /* @__PURE__ */ new Uint32Array([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA256 = class extends SHA2 {
  constructor() {
    super(64, 32, 8, false);
    this.A = IV[0] | 0;
    this.B = IV[1] | 0;
    this.C = IV[2] | 0;
    this.D = IV[3] | 0;
    this.E = IV[4] | 0;
    this.F = IV[5] | 0;
    this.G = IV[6] | 0;
    this.H = IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    SHA256_W.fill(0);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    this.buffer.fill(0);
  }
};
var sha256 = /* @__PURE__ */ wrapConstructor(() => new SHA256());

// economy/node_modules/@noble/hashes/esm/hmac.js
var HMAC = class extends Hash {
  constructor(hash2, _key) {
    super();
    this.finished = false;
    this.destroyed = false;
    hash(hash2);
    const key = toBytes(_key);
    this.iHash = hash2.create();
    if (typeof this.iHash.update !== "function")
      throw new Error("Expected instance of class which extends utils.Hash");
    this.blockLen = this.iHash.blockLen;
    this.outputLen = this.iHash.outputLen;
    const blockLen = this.blockLen;
    const pad = new Uint8Array(blockLen);
    pad.set(key.length > blockLen ? hash2.create().update(key).digest() : key);
    for (let i = 0; i < pad.length; i++)
      pad[i] ^= 54;
    this.iHash.update(pad);
    this.oHash = hash2.create();
    for (let i = 0; i < pad.length; i++)
      pad[i] ^= 54 ^ 92;
    this.oHash.update(pad);
    pad.fill(0);
  }
  update(buf) {
    exists(this);
    this.iHash.update(buf);
    return this;
  }
  digestInto(out) {
    exists(this);
    bytes(out, this.outputLen);
    this.finished = true;
    this.iHash.digestInto(out);
    this.oHash.update(out);
    this.oHash.digestInto(out);
    this.destroy();
  }
  digest() {
    const out = new Uint8Array(this.oHash.outputLen);
    this.digestInto(out);
    return out;
  }
  _cloneInto(to2) {
    to2 || (to2 = Object.create(Object.getPrototypeOf(this), {}));
    const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
    to2 = to2;
    to2.finished = finished;
    to2.destroyed = destroyed;
    to2.blockLen = blockLen;
    to2.outputLen = outputLen;
    to2.oHash = oHash._cloneInto(to2.oHash);
    to2.iHash = iHash._cloneInto(to2.iHash);
    return to2;
  }
  destroy() {
    this.destroyed = true;
    this.oHash.destroy();
    this.iHash.destroy();
  }
};
var hmac = (hash2, key, message) => new HMAC(hash2, key).update(message).digest();
hmac.create = (hash2, key) => new HMAC(hash2, key);

// economy/node_modules/ethers/lib.esm/crypto/sha2.js
var _sha256 = function(data) {
  return createHash("sha256").update(data).digest();
};
var _sha512 = function(data) {
  return createHash("sha512").update(data).digest();
};
var __sha256 = _sha256;
var __sha512 = _sha512;
var locked256 = false;
var locked512 = false;
function sha2562(_data) {
  const data = getBytes(_data, "data");
  return hexlify(__sha256(data));
}
sha2562._ = _sha256;
sha2562.lock = function() {
  locked256 = true;
};
sha2562.register = function(func) {
  if (locked256) {
    throw new Error("sha256 is locked");
  }
  __sha256 = func;
};
Object.freeze(sha2562);
function sha512(_data) {
  const data = getBytes(_data, "data");
  return hexlify(__sha512(data));
}
sha512._ = _sha512;
sha512.lock = function() {
  locked512 = true;
};
sha512.register = function(func) {
  if (locked512) {
    throw new Error("sha512 is locked");
  }
  __sha512 = func;
};
Object.freeze(sha2562);

// economy/node_modules/@noble/curves/esm/abstract/utils.js
var utils_exports = {};
__export(utils_exports, {
  bitGet: () => bitGet,
  bitLen: () => bitLen,
  bitMask: () => bitMask,
  bitSet: () => bitSet,
  bytesToHex: () => bytesToHex,
  bytesToNumberBE: () => bytesToNumberBE,
  bytesToNumberLE: () => bytesToNumberLE,
  concatBytes: () => concatBytes2,
  createHmacDrbg: () => createHmacDrbg,
  ensureBytes: () => ensureBytes,
  equalBytes: () => equalBytes,
  hexToBytes: () => hexToBytes,
  hexToNumber: () => hexToNumber,
  numberToBytesBE: () => numberToBytesBE,
  numberToBytesLE: () => numberToBytesLE,
  numberToHexUnpadded: () => numberToHexUnpadded,
  numberToVarBytesBE: () => numberToVarBytesBE,
  utf8ToBytes: () => utf8ToBytes2,
  validateObject: () => validateObject
});
var _0n2 = BigInt(0);
var _1n2 = BigInt(1);
var _2n2 = BigInt(2);
var u8a2 = (a) => a instanceof Uint8Array;
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
function bytesToHex(bytes2) {
  if (!u8a2(bytes2))
    throw new Error("Uint8Array expected");
  let hex = "";
  for (let i = 0; i < bytes2.length; i++) {
    hex += hexes[bytes2[i]];
  }
  return hex;
}
function numberToHexUnpadded(num) {
  const hex = num.toString(16);
  return hex.length & 1 ? `0${hex}` : hex;
}
function hexToNumber(hex) {
  if (typeof hex !== "string")
    throw new Error("hex string expected, got " + typeof hex);
  return BigInt(hex === "" ? "0" : `0x${hex}`);
}
function hexToBytes(hex) {
  if (typeof hex !== "string")
    throw new Error("hex string expected, got " + typeof hex);
  const len = hex.length;
  if (len % 2)
    throw new Error("padded hex string expected, got unpadded hex of length " + len);
  const array = new Uint8Array(len / 2);
  for (let i = 0; i < array.length; i++) {
    const j = i * 2;
    const hexByte = hex.slice(j, j + 2);
    const byte = Number.parseInt(hexByte, 16);
    if (Number.isNaN(byte) || byte < 0)
      throw new Error("Invalid byte sequence");
    array[i] = byte;
  }
  return array;
}
function bytesToNumberBE(bytes2) {
  return hexToNumber(bytesToHex(bytes2));
}
function bytesToNumberLE(bytes2) {
  if (!u8a2(bytes2))
    throw new Error("Uint8Array expected");
  return hexToNumber(bytesToHex(Uint8Array.from(bytes2).reverse()));
}
function numberToBytesBE(n, len) {
  return hexToBytes(n.toString(16).padStart(len * 2, "0"));
}
function numberToBytesLE(n, len) {
  return numberToBytesBE(n, len).reverse();
}
function numberToVarBytesBE(n) {
  return hexToBytes(numberToHexUnpadded(n));
}
function ensureBytes(title, hex, expectedLength) {
  let res;
  if (typeof hex === "string") {
    try {
      res = hexToBytes(hex);
    } catch (e) {
      throw new Error(`${title} must be valid hex string, got "${hex}". Cause: ${e}`);
    }
  } else if (u8a2(hex)) {
    res = Uint8Array.from(hex);
  } else {
    throw new Error(`${title} must be hex string or Uint8Array`);
  }
  const len = res.length;
  if (typeof expectedLength === "number" && len !== expectedLength)
    throw new Error(`${title} expected ${expectedLength} bytes, got ${len}`);
  return res;
}
function concatBytes2(...arrays) {
  const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
  let pad = 0;
  arrays.forEach((a) => {
    if (!u8a2(a))
      throw new Error("Uint8Array expected");
    r.set(a, pad);
    pad += a.length;
  });
  return r;
}
function equalBytes(b1, b2) {
  if (b1.length !== b2.length)
    return false;
  for (let i = 0; i < b1.length; i++)
    if (b1[i] !== b2[i])
      return false;
  return true;
}
function utf8ToBytes2(str) {
  if (typeof str !== "string")
    throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
  return new Uint8Array(new TextEncoder().encode(str));
}
function bitLen(n) {
  let len;
  for (len = 0; n > _0n2; n >>= _1n2, len += 1)
    ;
  return len;
}
function bitGet(n, pos) {
  return n >> BigInt(pos) & _1n2;
}
var bitSet = (n, pos, value) => {
  return n | (value ? _1n2 : _0n2) << BigInt(pos);
};
var bitMask = (n) => (_2n2 << BigInt(n - 1)) - _1n2;
var u8n = (data) => new Uint8Array(data);
var u8fr = (arr) => Uint8Array.from(arr);
function createHmacDrbg(hashLen, qByteLen, hmacFn) {
  if (typeof hashLen !== "number" || hashLen < 2)
    throw new Error("hashLen must be a number");
  if (typeof qByteLen !== "number" || qByteLen < 2)
    throw new Error("qByteLen must be a number");
  if (typeof hmacFn !== "function")
    throw new Error("hmacFn must be a function");
  let v = u8n(hashLen);
  let k = u8n(hashLen);
  let i = 0;
  const reset = () => {
    v.fill(1);
    k.fill(0);
    i = 0;
  };
  const h = (...b) => hmacFn(k, v, ...b);
  const reseed = (seed = u8n()) => {
    k = h(u8fr([0]), seed);
    v = h();
    if (seed.length === 0)
      return;
    k = h(u8fr([1]), seed);
    v = h();
  };
  const gen2 = () => {
    if (i++ >= 1e3)
      throw new Error("drbg: tried 1000 values");
    let len = 0;
    const out = [];
    while (len < qByteLen) {
      v = h();
      const sl = v.slice();
      out.push(sl);
      len += v.length;
    }
    return concatBytes2(...out);
  };
  const genUntil = (seed, pred) => {
    reset();
    reseed(seed);
    let res = void 0;
    while (!(res = pred(gen2())))
      reseed();
    reset();
    return res;
  };
  return genUntil;
}
var validatorFns = {
  bigint: (val) => typeof val === "bigint",
  function: (val) => typeof val === "function",
  boolean: (val) => typeof val === "boolean",
  string: (val) => typeof val === "string",
  stringOrUint8Array: (val) => typeof val === "string" || val instanceof Uint8Array,
  isSafeInteger: (val) => Number.isSafeInteger(val),
  array: (val) => Array.isArray(val),
  field: (val, object) => object.Fp.isValid(val),
  hash: (val) => typeof val === "function" && Number.isSafeInteger(val.outputLen)
};
function validateObject(object, validators, optValidators = {}) {
  const checkField = (fieldName, type, isOptional) => {
    const checkVal = validatorFns[type];
    if (typeof checkVal !== "function")
      throw new Error(`Invalid validator "${type}", expected function`);
    const val = object[fieldName];
    if (isOptional && val === void 0)
      return;
    if (!checkVal(val, object)) {
      throw new Error(`Invalid param ${String(fieldName)}=${val} (${typeof val}), expected ${type}`);
    }
  };
  for (const [fieldName, type] of Object.entries(validators))
    checkField(fieldName, type, false);
  for (const [fieldName, type] of Object.entries(optValidators))
    checkField(fieldName, type, true);
  return object;
}

// economy/node_modules/@noble/curves/esm/abstract/modular.js
var _0n3 = BigInt(0);
var _1n3 = BigInt(1);
var _2n3 = BigInt(2);
var _3n = BigInt(3);
var _4n = BigInt(4);
var _5n = BigInt(5);
var _8n = BigInt(8);
var _9n = BigInt(9);
var _16n = BigInt(16);
function mod(a, b) {
  const result = a % b;
  return result >= _0n3 ? result : b + result;
}
function pow(num, power, modulo) {
  if (modulo <= _0n3 || power < _0n3)
    throw new Error("Expected power/modulo > 0");
  if (modulo === _1n3)
    return _0n3;
  let res = _1n3;
  while (power > _0n3) {
    if (power & _1n3)
      res = res * num % modulo;
    num = num * num % modulo;
    power >>= _1n3;
  }
  return res;
}
function pow2(x, power, modulo) {
  let res = x;
  while (power-- > _0n3) {
    res *= res;
    res %= modulo;
  }
  return res;
}
function invert(number2, modulo) {
  if (number2 === _0n3 || modulo <= _0n3) {
    throw new Error(`invert: expected positive integers, got n=${number2} mod=${modulo}`);
  }
  let a = mod(number2, modulo);
  let b = modulo;
  let x = _0n3, y = _1n3, u = _1n3, v = _0n3;
  while (a !== _0n3) {
    const q = b / a;
    const r = b % a;
    const m = x - u * q;
    const n = y - v * q;
    b = a, a = r, x = u, y = v, u = m, v = n;
  }
  const gcd = b;
  if (gcd !== _1n3)
    throw new Error("invert: does not exist");
  return mod(x, modulo);
}
function tonelliShanks(P) {
  const legendreC = (P - _1n3) / _2n3;
  let Q, S, Z;
  for (Q = P - _1n3, S = 0; Q % _2n3 === _0n3; Q /= _2n3, S++)
    ;
  for (Z = _2n3; Z < P && pow(Z, legendreC, P) !== P - _1n3; Z++)
    ;
  if (S === 1) {
    const p1div4 = (P + _1n3) / _4n;
    return function tonelliFast(Fp2, n) {
      const root = Fp2.pow(n, p1div4);
      if (!Fp2.eql(Fp2.sqr(root), n))
        throw new Error("Cannot find square root");
      return root;
    };
  }
  const Q1div2 = (Q + _1n3) / _2n3;
  return function tonelliSlow(Fp2, n) {
    if (Fp2.pow(n, legendreC) === Fp2.neg(Fp2.ONE))
      throw new Error("Cannot find square root");
    let r = S;
    let g = Fp2.pow(Fp2.mul(Fp2.ONE, Z), Q);
    let x = Fp2.pow(n, Q1div2);
    let b = Fp2.pow(n, Q);
    while (!Fp2.eql(b, Fp2.ONE)) {
      if (Fp2.eql(b, Fp2.ZERO))
        return Fp2.ZERO;
      let m = 1;
      for (let t22 = Fp2.sqr(b); m < r; m++) {
        if (Fp2.eql(t22, Fp2.ONE))
          break;
        t22 = Fp2.sqr(t22);
      }
      const ge2 = Fp2.pow(g, _1n3 << BigInt(r - m - 1));
      g = Fp2.sqr(ge2);
      x = Fp2.mul(x, ge2);
      b = Fp2.mul(b, g);
      r = m;
    }
    return x;
  };
}
function FpSqrt(P) {
  if (P % _4n === _3n) {
    const p1div4 = (P + _1n3) / _4n;
    return function sqrt3mod4(Fp2, n) {
      const root = Fp2.pow(n, p1div4);
      if (!Fp2.eql(Fp2.sqr(root), n))
        throw new Error("Cannot find square root");
      return root;
    };
  }
  if (P % _8n === _5n) {
    const c1 = (P - _5n) / _8n;
    return function sqrt5mod8(Fp2, n) {
      const n2 = Fp2.mul(n, _2n3);
      const v = Fp2.pow(n2, c1);
      const nv = Fp2.mul(n, v);
      const i = Fp2.mul(Fp2.mul(nv, _2n3), v);
      const root = Fp2.mul(nv, Fp2.sub(i, Fp2.ONE));
      if (!Fp2.eql(Fp2.sqr(root), n))
        throw new Error("Cannot find square root");
      return root;
    };
  }
  if (P % _16n === _9n) {
  }
  return tonelliShanks(P);
}
var FIELD_FIELDS = [
  "create",
  "isValid",
  "is0",
  "neg",
  "inv",
  "sqrt",
  "sqr",
  "eql",
  "add",
  "sub",
  "mul",
  "pow",
  "div",
  "addN",
  "subN",
  "mulN",
  "sqrN"
];
function validateField(field) {
  const initial = {
    ORDER: "bigint",
    MASK: "bigint",
    BYTES: "isSafeInteger",
    BITS: "isSafeInteger"
  };
  const opts = FIELD_FIELDS.reduce((map, val) => {
    map[val] = "function";
    return map;
  }, initial);
  return validateObject(field, opts);
}
function FpPow(f, num, power) {
  if (power < _0n3)
    throw new Error("Expected power > 0");
  if (power === _0n3)
    return f.ONE;
  if (power === _1n3)
    return num;
  let p = f.ONE;
  let d = num;
  while (power > _0n3) {
    if (power & _1n3)
      p = f.mul(p, d);
    d = f.sqr(d);
    power >>= _1n3;
  }
  return p;
}
function FpInvertBatch(f, nums) {
  const tmp = new Array(nums.length);
  const lastMultiplied = nums.reduce((acc, num, i) => {
    if (f.is0(num))
      return acc;
    tmp[i] = acc;
    return f.mul(acc, num);
  }, f.ONE);
  const inverted = f.inv(lastMultiplied);
  nums.reduceRight((acc, num, i) => {
    if (f.is0(num))
      return acc;
    tmp[i] = f.mul(acc, tmp[i]);
    return f.mul(acc, num);
  }, inverted);
  return tmp;
}
function nLength(n, nBitLength) {
  const _nBitLength = nBitLength !== void 0 ? nBitLength : n.toString(2).length;
  const nByteLength = Math.ceil(_nBitLength / 8);
  return { nBitLength: _nBitLength, nByteLength };
}
function Field(ORDER, bitLen2, isLE2 = false, redef = {}) {
  if (ORDER <= _0n3)
    throw new Error(`Expected Field ORDER > 0, got ${ORDER}`);
  const { nBitLength: BITS, nByteLength: BYTES } = nLength(ORDER, bitLen2);
  if (BYTES > 2048)
    throw new Error("Field lengths over 2048 bytes are not supported");
  const sqrtP = FpSqrt(ORDER);
  const f = Object.freeze({
    ORDER,
    BITS,
    BYTES,
    MASK: bitMask(BITS),
    ZERO: _0n3,
    ONE: _1n3,
    create: (num) => mod(num, ORDER),
    isValid: (num) => {
      if (typeof num !== "bigint")
        throw new Error(`Invalid field element: expected bigint, got ${typeof num}`);
      return _0n3 <= num && num < ORDER;
    },
    is0: (num) => num === _0n3,
    isOdd: (num) => (num & _1n3) === _1n3,
    neg: (num) => mod(-num, ORDER),
    eql: (lhs, rhs) => lhs === rhs,
    sqr: (num) => mod(num * num, ORDER),
    add: (lhs, rhs) => mod(lhs + rhs, ORDER),
    sub: (lhs, rhs) => mod(lhs - rhs, ORDER),
    mul: (lhs, rhs) => mod(lhs * rhs, ORDER),
    pow: (num, power) => FpPow(f, num, power),
    div: (lhs, rhs) => mod(lhs * invert(rhs, ORDER), ORDER),
    // Same as above, but doesn't normalize
    sqrN: (num) => num * num,
    addN: (lhs, rhs) => lhs + rhs,
    subN: (lhs, rhs) => lhs - rhs,
    mulN: (lhs, rhs) => lhs * rhs,
    inv: (num) => invert(num, ORDER),
    sqrt: redef.sqrt || ((n) => sqrtP(f, n)),
    invertBatch: (lst) => FpInvertBatch(f, lst),
    // TODO: do we really need constant cmov?
    // We don't have const-time bigints anyway, so probably will be not very useful
    cmov: (a, b, c) => c ? b : a,
    toBytes: (num) => isLE2 ? numberToBytesLE(num, BYTES) : numberToBytesBE(num, BYTES),
    fromBytes: (bytes2) => {
      if (bytes2.length !== BYTES)
        throw new Error(`Fp.fromBytes: expected ${BYTES}, got ${bytes2.length}`);
      return isLE2 ? bytesToNumberLE(bytes2) : bytesToNumberBE(bytes2);
    }
  });
  return Object.freeze(f);
}
function getFieldBytesLength(fieldOrder) {
  if (typeof fieldOrder !== "bigint")
    throw new Error("field order must be bigint");
  const bitLength = fieldOrder.toString(2).length;
  return Math.ceil(bitLength / 8);
}
function getMinHashLength(fieldOrder) {
  const length = getFieldBytesLength(fieldOrder);
  return length + Math.ceil(length / 2);
}
function mapHashToField(key, fieldOrder, isLE2 = false) {
  const len = key.length;
  const fieldLen = getFieldBytesLength(fieldOrder);
  const minLen = getMinHashLength(fieldOrder);
  if (len < 16 || len < minLen || len > 1024)
    throw new Error(`expected ${minLen}-1024 bytes of input, got ${len}`);
  const num = isLE2 ? bytesToNumberBE(key) : bytesToNumberLE(key);
  const reduced = mod(num, fieldOrder - _1n3) + _1n3;
  return isLE2 ? numberToBytesLE(reduced, fieldLen) : numberToBytesBE(reduced, fieldLen);
}

// economy/node_modules/@noble/curves/esm/abstract/curve.js
var _0n4 = BigInt(0);
var _1n4 = BigInt(1);
function wNAF(c, bits) {
  const constTimeNegate = (condition, item) => {
    const neg = item.negate();
    return condition ? neg : item;
  };
  const opts = (W) => {
    const windows = Math.ceil(bits / W) + 1;
    const windowSize = 2 ** (W - 1);
    return { windows, windowSize };
  };
  return {
    constTimeNegate,
    // non-const time multiplication ladder
    unsafeLadder(elm, n) {
      let p = c.ZERO;
      let d = elm;
      while (n > _0n4) {
        if (n & _1n4)
          p = p.add(d);
        d = d.double();
        n >>= _1n4;
      }
      return p;
    },
    /**
     * Creates a wNAF precomputation window. Used for caching.
     * Default window size is set by `utils.precompute()` and is equal to 8.
     * Number of precomputed points depends on the curve size:
     * 2^(𝑊−1) * (Math.ceil(𝑛 / 𝑊) + 1), where:
     * - 𝑊 is the window size
     * - 𝑛 is the bitlength of the curve order.
     * For a 256-bit curve and window size 8, the number of precomputed points is 128 * 33 = 4224.
     * @returns precomputed point tables flattened to a single array
     */
    precomputeWindow(elm, W) {
      const { windows, windowSize } = opts(W);
      const points = [];
      let p = elm;
      let base = p;
      for (let window = 0; window < windows; window++) {
        base = p;
        points.push(base);
        for (let i = 1; i < windowSize; i++) {
          base = base.add(p);
          points.push(base);
        }
        p = base.double();
      }
      return points;
    },
    /**
     * Implements ec multiplication using precomputed tables and w-ary non-adjacent form.
     * @param W window size
     * @param precomputes precomputed tables
     * @param n scalar (we don't check here, but should be less than curve order)
     * @returns real and fake (for const-time) points
     */
    wNAF(W, precomputes, n) {
      const { windows, windowSize } = opts(W);
      let p = c.ZERO;
      let f = c.BASE;
      const mask2 = BigInt(2 ** W - 1);
      const maxNumber = 2 ** W;
      const shiftBy = BigInt(W);
      for (let window = 0; window < windows; window++) {
        const offset = window * windowSize;
        let wbits = Number(n & mask2);
        n >>= shiftBy;
        if (wbits > windowSize) {
          wbits -= maxNumber;
          n += _1n4;
        }
        const offset1 = offset;
        const offset2 = offset + Math.abs(wbits) - 1;
        const cond1 = window % 2 !== 0;
        const cond2 = wbits < 0;
        if (wbits === 0) {
          f = f.add(constTimeNegate(cond1, precomputes[offset1]));
        } else {
          p = p.add(constTimeNegate(cond2, precomputes[offset2]));
        }
      }
      return { p, f };
    },
    wNAFCached(P, precomputesMap, n, transform) {
      const W = P._WINDOW_SIZE || 1;
      let comp = precomputesMap.get(P);
      if (!comp) {
        comp = this.precomputeWindow(P, W);
        if (W !== 1) {
          precomputesMap.set(P, transform(comp));
        }
      }
      return this.wNAF(W, comp, n);
    }
  };
}
function validateBasic(curve) {
  validateField(curve.Fp);
  validateObject(curve, {
    n: "bigint",
    h: "bigint",
    Gx: "field",
    Gy: "field"
  }, {
    nBitLength: "isSafeInteger",
    nByteLength: "isSafeInteger"
  });
  return Object.freeze({
    ...nLength(curve.n, curve.nBitLength),
    ...curve,
    ...{ p: curve.Fp.ORDER }
  });
}

// economy/node_modules/@noble/curves/esm/abstract/weierstrass.js
function validatePointOpts(curve) {
  const opts = validateBasic(curve);
  validateObject(opts, {
    a: "field",
    b: "field"
  }, {
    allowedPrivateKeyLengths: "array",
    wrapPrivateKey: "boolean",
    isTorsionFree: "function",
    clearCofactor: "function",
    allowInfinityPoint: "boolean",
    fromBytes: "function",
    toBytes: "function"
  });
  const { endo, Fp: Fp2, a } = opts;
  if (endo) {
    if (!Fp2.eql(a, Fp2.ZERO)) {
      throw new Error("Endomorphism can only be defined for Koblitz curves that have a=0");
    }
    if (typeof endo !== "object" || typeof endo.beta !== "bigint" || typeof endo.splitScalar !== "function") {
      throw new Error("Expected endomorphism with beta: bigint and splitScalar: function");
    }
  }
  return Object.freeze({ ...opts });
}
var { bytesToNumberBE: b2n, hexToBytes: h2b } = utils_exports;
var DER = {
  // asn.1 DER encoding utils
  Err: class DERErr extends Error {
    constructor(m = "") {
      super(m);
    }
  },
  _parseInt(data) {
    const { Err: E } = DER;
    if (data.length < 2 || data[0] !== 2)
      throw new E("Invalid signature integer tag");
    const len = data[1];
    const res = data.subarray(2, len + 2);
    if (!len || res.length !== len)
      throw new E("Invalid signature integer: wrong length");
    if (res[0] & 128)
      throw new E("Invalid signature integer: negative");
    if (res[0] === 0 && !(res[1] & 128))
      throw new E("Invalid signature integer: unnecessary leading zero");
    return { d: b2n(res), l: data.subarray(len + 2) };
  },
  toSig(hex) {
    const { Err: E } = DER;
    const data = typeof hex === "string" ? h2b(hex) : hex;
    if (!(data instanceof Uint8Array))
      throw new Error("ui8a expected");
    let l = data.length;
    if (l < 2 || data[0] != 48)
      throw new E("Invalid signature tag");
    if (data[1] !== l - 2)
      throw new E("Invalid signature: incorrect length");
    const { d: r, l: sBytes } = DER._parseInt(data.subarray(2));
    const { d: s, l: rBytesLeft } = DER._parseInt(sBytes);
    if (rBytesLeft.length)
      throw new E("Invalid signature: left bytes after parsing");
    return { r, s };
  },
  hexFromSig(sig) {
    const slice = (s2) => Number.parseInt(s2[0], 16) & 8 ? "00" + s2 : s2;
    const h = (num) => {
      const hex = num.toString(16);
      return hex.length & 1 ? `0${hex}` : hex;
    };
    const s = slice(h(sig.s));
    const r = slice(h(sig.r));
    const shl = s.length / 2;
    const rhl = r.length / 2;
    const sl = h(shl);
    const rl = h(rhl);
    return `30${h(rhl + shl + 4)}02${rl}${r}02${sl}${s}`;
  }
};
var _0n5 = BigInt(0);
var _1n5 = BigInt(1);
var _2n4 = BigInt(2);
var _3n2 = BigInt(3);
var _4n2 = BigInt(4);
function weierstrassPoints(opts) {
  const CURVE = validatePointOpts(opts);
  const { Fp: Fp2 } = CURVE;
  const toBytes2 = CURVE.toBytes || ((_c, point, _isCompressed) => {
    const a = point.toAffine();
    return concatBytes2(Uint8Array.from([4]), Fp2.toBytes(a.x), Fp2.toBytes(a.y));
  });
  const fromBytes = CURVE.fromBytes || ((bytes2) => {
    const tail = bytes2.subarray(1);
    const x = Fp2.fromBytes(tail.subarray(0, Fp2.BYTES));
    const y = Fp2.fromBytes(tail.subarray(Fp2.BYTES, 2 * Fp2.BYTES));
    return { x, y };
  });
  function weierstrassEquation(x) {
    const { a, b } = CURVE;
    const x2 = Fp2.sqr(x);
    const x3 = Fp2.mul(x2, x);
    return Fp2.add(Fp2.add(x3, Fp2.mul(x, a)), b);
  }
  if (!Fp2.eql(Fp2.sqr(CURVE.Gy), weierstrassEquation(CURVE.Gx)))
    throw new Error("bad generator point: equation left != right");
  function isWithinCurveOrder(num) {
    return typeof num === "bigint" && _0n5 < num && num < CURVE.n;
  }
  function assertGE(num) {
    if (!isWithinCurveOrder(num))
      throw new Error("Expected valid bigint: 0 < bigint < curve.n");
  }
  function normPrivateKeyToScalar(key) {
    const { allowedPrivateKeyLengths: lengths, nByteLength, wrapPrivateKey, n } = CURVE;
    if (lengths && typeof key !== "bigint") {
      if (key instanceof Uint8Array)
        key = bytesToHex(key);
      if (typeof key !== "string" || !lengths.includes(key.length))
        throw new Error("Invalid key");
      key = key.padStart(nByteLength * 2, "0");
    }
    let num;
    try {
      num = typeof key === "bigint" ? key : bytesToNumberBE(ensureBytes("private key", key, nByteLength));
    } catch (error) {
      throw new Error(`private key must be ${nByteLength} bytes, hex or bigint, not ${typeof key}`);
    }
    if (wrapPrivateKey)
      num = mod(num, n);
    assertGE(num);
    return num;
  }
  const pointPrecomputes = /* @__PURE__ */ new Map();
  function assertPrjPoint(other) {
    if (!(other instanceof Point2))
      throw new Error("ProjectivePoint expected");
  }
  class Point2 {
    constructor(px, py, pz) {
      this.px = px;
      this.py = py;
      this.pz = pz;
      if (px == null || !Fp2.isValid(px))
        throw new Error("x required");
      if (py == null || !Fp2.isValid(py))
        throw new Error("y required");
      if (pz == null || !Fp2.isValid(pz))
        throw new Error("z required");
    }
    // Does not validate if the point is on-curve.
    // Use fromHex instead, or call assertValidity() later.
    static fromAffine(p) {
      const { x, y } = p || {};
      if (!p || !Fp2.isValid(x) || !Fp2.isValid(y))
        throw new Error("invalid affine point");
      if (p instanceof Point2)
        throw new Error("projective point not allowed");
      const is0 = (i) => Fp2.eql(i, Fp2.ZERO);
      if (is0(x) && is0(y))
        return Point2.ZERO;
      return new Point2(x, y, Fp2.ONE);
    }
    get x() {
      return this.toAffine().x;
    }
    get y() {
      return this.toAffine().y;
    }
    /**
     * Takes a bunch of Projective Points but executes only one
     * inversion on all of them. Inversion is very slow operation,
     * so this improves performance massively.
     * Optimization: converts a list of projective points to a list of identical points with Z=1.
     */
    static normalizeZ(points) {
      const toInv = Fp2.invertBatch(points.map((p) => p.pz));
      return points.map((p, i) => p.toAffine(toInv[i])).map(Point2.fromAffine);
    }
    /**
     * Converts hash string or Uint8Array to Point.
     * @param hex short/long ECDSA hex
     */
    static fromHex(hex) {
      const P = Point2.fromAffine(fromBytes(ensureBytes("pointHex", hex)));
      P.assertValidity();
      return P;
    }
    // Multiplies generator point by privateKey.
    static fromPrivateKey(privateKey) {
      return Point2.BASE.multiply(normPrivateKeyToScalar(privateKey));
    }
    // "Private method", don't use it directly
    _setWindowSize(windowSize) {
      this._WINDOW_SIZE = windowSize;
      pointPrecomputes.delete(this);
    }
    // A point on curve is valid if it conforms to equation.
    assertValidity() {
      if (this.is0()) {
        if (CURVE.allowInfinityPoint && !Fp2.is0(this.py))
          return;
        throw new Error("bad point: ZERO");
      }
      const { x, y } = this.toAffine();
      if (!Fp2.isValid(x) || !Fp2.isValid(y))
        throw new Error("bad point: x or y not FE");
      const left = Fp2.sqr(y);
      const right = weierstrassEquation(x);
      if (!Fp2.eql(left, right))
        throw new Error("bad point: equation left != right");
      if (!this.isTorsionFree())
        throw new Error("bad point: not in prime-order subgroup");
    }
    hasEvenY() {
      const { y } = this.toAffine();
      if (Fp2.isOdd)
        return !Fp2.isOdd(y);
      throw new Error("Field doesn't support isOdd");
    }
    /**
     * Compare one point to another.
     */
    equals(other) {
      assertPrjPoint(other);
      const { px: X1, py: Y1, pz: Z1 } = this;
      const { px: X2, py: Y2, pz: Z2 } = other;
      const U1 = Fp2.eql(Fp2.mul(X1, Z2), Fp2.mul(X2, Z1));
      const U2 = Fp2.eql(Fp2.mul(Y1, Z2), Fp2.mul(Y2, Z1));
      return U1 && U2;
    }
    /**
     * Flips point to one corresponding to (x, -y) in Affine coordinates.
     */
    negate() {
      return new Point2(this.px, Fp2.neg(this.py), this.pz);
    }
    // Renes-Costello-Batina exception-free doubling formula.
    // There is 30% faster Jacobian formula, but it is not complete.
    // https://eprint.iacr.org/2015/1060, algorithm 3
    // Cost: 8M + 3S + 3*a + 2*b3 + 15add.
    double() {
      const { a, b } = CURVE;
      const b3 = Fp2.mul(b, _3n2);
      const { px: X1, py: Y1, pz: Z1 } = this;
      let X3 = Fp2.ZERO, Y3 = Fp2.ZERO, Z3 = Fp2.ZERO;
      let t0 = Fp2.mul(X1, X1);
      let t1 = Fp2.mul(Y1, Y1);
      let t22 = Fp2.mul(Z1, Z1);
      let t3 = Fp2.mul(X1, Y1);
      t3 = Fp2.add(t3, t3);
      Z3 = Fp2.mul(X1, Z1);
      Z3 = Fp2.add(Z3, Z3);
      X3 = Fp2.mul(a, Z3);
      Y3 = Fp2.mul(b3, t22);
      Y3 = Fp2.add(X3, Y3);
      X3 = Fp2.sub(t1, Y3);
      Y3 = Fp2.add(t1, Y3);
      Y3 = Fp2.mul(X3, Y3);
      X3 = Fp2.mul(t3, X3);
      Z3 = Fp2.mul(b3, Z3);
      t22 = Fp2.mul(a, t22);
      t3 = Fp2.sub(t0, t22);
      t3 = Fp2.mul(a, t3);
      t3 = Fp2.add(t3, Z3);
      Z3 = Fp2.add(t0, t0);
      t0 = Fp2.add(Z3, t0);
      t0 = Fp2.add(t0, t22);
      t0 = Fp2.mul(t0, t3);
      Y3 = Fp2.add(Y3, t0);
      t22 = Fp2.mul(Y1, Z1);
      t22 = Fp2.add(t22, t22);
      t0 = Fp2.mul(t22, t3);
      X3 = Fp2.sub(X3, t0);
      Z3 = Fp2.mul(t22, t1);
      Z3 = Fp2.add(Z3, Z3);
      Z3 = Fp2.add(Z3, Z3);
      return new Point2(X3, Y3, Z3);
    }
    // Renes-Costello-Batina exception-free addition formula.
    // There is 30% faster Jacobian formula, but it is not complete.
    // https://eprint.iacr.org/2015/1060, algorithm 1
    // Cost: 12M + 0S + 3*a + 3*b3 + 23add.
    add(other) {
      assertPrjPoint(other);
      const { px: X1, py: Y1, pz: Z1 } = this;
      const { px: X2, py: Y2, pz: Z2 } = other;
      let X3 = Fp2.ZERO, Y3 = Fp2.ZERO, Z3 = Fp2.ZERO;
      const a = CURVE.a;
      const b3 = Fp2.mul(CURVE.b, _3n2);
      let t0 = Fp2.mul(X1, X2);
      let t1 = Fp2.mul(Y1, Y2);
      let t22 = Fp2.mul(Z1, Z2);
      let t3 = Fp2.add(X1, Y1);
      let t4 = Fp2.add(X2, Y2);
      t3 = Fp2.mul(t3, t4);
      t4 = Fp2.add(t0, t1);
      t3 = Fp2.sub(t3, t4);
      t4 = Fp2.add(X1, Z1);
      let t5 = Fp2.add(X2, Z2);
      t4 = Fp2.mul(t4, t5);
      t5 = Fp2.add(t0, t22);
      t4 = Fp2.sub(t4, t5);
      t5 = Fp2.add(Y1, Z1);
      X3 = Fp2.add(Y2, Z2);
      t5 = Fp2.mul(t5, X3);
      X3 = Fp2.add(t1, t22);
      t5 = Fp2.sub(t5, X3);
      Z3 = Fp2.mul(a, t4);
      X3 = Fp2.mul(b3, t22);
      Z3 = Fp2.add(X3, Z3);
      X3 = Fp2.sub(t1, Z3);
      Z3 = Fp2.add(t1, Z3);
      Y3 = Fp2.mul(X3, Z3);
      t1 = Fp2.add(t0, t0);
      t1 = Fp2.add(t1, t0);
      t22 = Fp2.mul(a, t22);
      t4 = Fp2.mul(b3, t4);
      t1 = Fp2.add(t1, t22);
      t22 = Fp2.sub(t0, t22);
      t22 = Fp2.mul(a, t22);
      t4 = Fp2.add(t4, t22);
      t0 = Fp2.mul(t1, t4);
      Y3 = Fp2.add(Y3, t0);
      t0 = Fp2.mul(t5, t4);
      X3 = Fp2.mul(t3, X3);
      X3 = Fp2.sub(X3, t0);
      t0 = Fp2.mul(t3, t1);
      Z3 = Fp2.mul(t5, Z3);
      Z3 = Fp2.add(Z3, t0);
      return new Point2(X3, Y3, Z3);
    }
    subtract(other) {
      return this.add(other.negate());
    }
    is0() {
      return this.equals(Point2.ZERO);
    }
    wNAF(n) {
      return wnaf.wNAFCached(this, pointPrecomputes, n, (comp) => {
        const toInv = Fp2.invertBatch(comp.map((p) => p.pz));
        return comp.map((p, i) => p.toAffine(toInv[i])).map(Point2.fromAffine);
      });
    }
    /**
     * Non-constant-time multiplication. Uses double-and-add algorithm.
     * It's faster, but should only be used when you don't care about
     * an exposed private key e.g. sig verification, which works over *public* keys.
     */
    multiplyUnsafe(n) {
      const I = Point2.ZERO;
      if (n === _0n5)
        return I;
      assertGE(n);
      if (n === _1n5)
        return this;
      const { endo } = CURVE;
      if (!endo)
        return wnaf.unsafeLadder(this, n);
      let { k1neg, k1, k2neg, k2 } = endo.splitScalar(n);
      let k1p = I;
      let k2p = I;
      let d = this;
      while (k1 > _0n5 || k2 > _0n5) {
        if (k1 & _1n5)
          k1p = k1p.add(d);
        if (k2 & _1n5)
          k2p = k2p.add(d);
        d = d.double();
        k1 >>= _1n5;
        k2 >>= _1n5;
      }
      if (k1neg)
        k1p = k1p.negate();
      if (k2neg)
        k2p = k2p.negate();
      k2p = new Point2(Fp2.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
      return k1p.add(k2p);
    }
    /**
     * Constant time multiplication.
     * Uses wNAF method. Windowed method may be 10% faster,
     * but takes 2x longer to generate and consumes 2x memory.
     * Uses precomputes when available.
     * Uses endomorphism for Koblitz curves.
     * @param scalar by which the point would be multiplied
     * @returns New point
     */
    multiply(scalar) {
      assertGE(scalar);
      let n = scalar;
      let point, fake;
      const { endo } = CURVE;
      if (endo) {
        const { k1neg, k1, k2neg, k2 } = endo.splitScalar(n);
        let { p: k1p, f: f1p } = this.wNAF(k1);
        let { p: k2p, f: f2p } = this.wNAF(k2);
        k1p = wnaf.constTimeNegate(k1neg, k1p);
        k2p = wnaf.constTimeNegate(k2neg, k2p);
        k2p = new Point2(Fp2.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
        point = k1p.add(k2p);
        fake = f1p.add(f2p);
      } else {
        const { p, f } = this.wNAF(n);
        point = p;
        fake = f;
      }
      return Point2.normalizeZ([point, fake])[0];
    }
    /**
     * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
     * Not using Strauss-Shamir trick: precomputation tables are faster.
     * The trick could be useful if both P and Q are not G (not in our case).
     * @returns non-zero affine point
     */
    multiplyAndAddUnsafe(Q, a, b) {
      const G = Point2.BASE;
      const mul = (P, a2) => a2 === _0n5 || a2 === _1n5 || !P.equals(G) ? P.multiplyUnsafe(a2) : P.multiply(a2);
      const sum = mul(this, a).add(mul(Q, b));
      return sum.is0() ? void 0 : sum;
    }
    // Converts Projective point to affine (x, y) coordinates.
    // Can accept precomputed Z^-1 - for example, from invertBatch.
    // (x, y, z) ∋ (x=x/z, y=y/z)
    toAffine(iz) {
      const { px: x, py: y, pz: z } = this;
      const is0 = this.is0();
      if (iz == null)
        iz = is0 ? Fp2.ONE : Fp2.inv(z);
      const ax = Fp2.mul(x, iz);
      const ay = Fp2.mul(y, iz);
      const zz = Fp2.mul(z, iz);
      if (is0)
        return { x: Fp2.ZERO, y: Fp2.ZERO };
      if (!Fp2.eql(zz, Fp2.ONE))
        throw new Error("invZ was invalid");
      return { x: ax, y: ay };
    }
    isTorsionFree() {
      const { h: cofactor, isTorsionFree } = CURVE;
      if (cofactor === _1n5)
        return true;
      if (isTorsionFree)
        return isTorsionFree(Point2, this);
      throw new Error("isTorsionFree() has not been declared for the elliptic curve");
    }
    clearCofactor() {
      const { h: cofactor, clearCofactor } = CURVE;
      if (cofactor === _1n5)
        return this;
      if (clearCofactor)
        return clearCofactor(Point2, this);
      return this.multiplyUnsafe(CURVE.h);
    }
    toRawBytes(isCompressed = true) {
      this.assertValidity();
      return toBytes2(Point2, this, isCompressed);
    }
    toHex(isCompressed = true) {
      return bytesToHex(this.toRawBytes(isCompressed));
    }
  }
  Point2.BASE = new Point2(CURVE.Gx, CURVE.Gy, Fp2.ONE);
  Point2.ZERO = new Point2(Fp2.ZERO, Fp2.ONE, Fp2.ZERO);
  const _bits = CURVE.nBitLength;
  const wnaf = wNAF(Point2, CURVE.endo ? Math.ceil(_bits / 2) : _bits);
  return {
    CURVE,
    ProjectivePoint: Point2,
    normPrivateKeyToScalar,
    weierstrassEquation,
    isWithinCurveOrder
  };
}
function validateOpts(curve) {
  const opts = validateBasic(curve);
  validateObject(opts, {
    hash: "hash",
    hmac: "function",
    randomBytes: "function"
  }, {
    bits2int: "function",
    bits2int_modN: "function",
    lowS: "boolean"
  });
  return Object.freeze({ lowS: true, ...opts });
}
function weierstrass(curveDef) {
  const CURVE = validateOpts(curveDef);
  const { Fp: Fp2, n: CURVE_ORDER } = CURVE;
  const compressedLen = Fp2.BYTES + 1;
  const uncompressedLen = 2 * Fp2.BYTES + 1;
  function isValidFieldElement(num) {
    return _0n5 < num && num < Fp2.ORDER;
  }
  function modN(a) {
    return mod(a, CURVE_ORDER);
  }
  function invN(a) {
    return invert(a, CURVE_ORDER);
  }
  const { ProjectivePoint: Point2, normPrivateKeyToScalar, weierstrassEquation, isWithinCurveOrder } = weierstrassPoints({
    ...CURVE,
    toBytes(_c, point, isCompressed) {
      const a = point.toAffine();
      const x = Fp2.toBytes(a.x);
      const cat = concatBytes2;
      if (isCompressed) {
        return cat(Uint8Array.from([point.hasEvenY() ? 2 : 3]), x);
      } else {
        return cat(Uint8Array.from([4]), x, Fp2.toBytes(a.y));
      }
    },
    fromBytes(bytes2) {
      const len = bytes2.length;
      const head = bytes2[0];
      const tail = bytes2.subarray(1);
      if (len === compressedLen && (head === 2 || head === 3)) {
        const x = bytesToNumberBE(tail);
        if (!isValidFieldElement(x))
          throw new Error("Point is not on curve");
        const y2 = weierstrassEquation(x);
        let y = Fp2.sqrt(y2);
        const isYOdd = (y & _1n5) === _1n5;
        const isHeadOdd = (head & 1) === 1;
        if (isHeadOdd !== isYOdd)
          y = Fp2.neg(y);
        return { x, y };
      } else if (len === uncompressedLen && head === 4) {
        const x = Fp2.fromBytes(tail.subarray(0, Fp2.BYTES));
        const y = Fp2.fromBytes(tail.subarray(Fp2.BYTES, 2 * Fp2.BYTES));
        return { x, y };
      } else {
        throw new Error(`Point of length ${len} was invalid. Expected ${compressedLen} compressed bytes or ${uncompressedLen} uncompressed bytes`);
      }
    }
  });
  const numToNByteStr = (num) => bytesToHex(numberToBytesBE(num, CURVE.nByteLength));
  function isBiggerThanHalfOrder(number2) {
    const HALF = CURVE_ORDER >> _1n5;
    return number2 > HALF;
  }
  function normalizeS(s) {
    return isBiggerThanHalfOrder(s) ? modN(-s) : s;
  }
  const slcNum = (b, from, to2) => bytesToNumberBE(b.slice(from, to2));
  class Signature2 {
    constructor(r, s, recovery) {
      this.r = r;
      this.s = s;
      this.recovery = recovery;
      this.assertValidity();
    }
    // pair (bytes of r, bytes of s)
    static fromCompact(hex) {
      const l = CURVE.nByteLength;
      hex = ensureBytes("compactSignature", hex, l * 2);
      return new Signature2(slcNum(hex, 0, l), slcNum(hex, l, 2 * l));
    }
    // DER encoded ECDSA signature
    // https://bitcoin.stackexchange.com/questions/57644/what-are-the-parts-of-a-bitcoin-transaction-input-script
    static fromDER(hex) {
      const { r, s } = DER.toSig(ensureBytes("DER", hex));
      return new Signature2(r, s);
    }
    assertValidity() {
      if (!isWithinCurveOrder(this.r))
        throw new Error("r must be 0 < r < CURVE.n");
      if (!isWithinCurveOrder(this.s))
        throw new Error("s must be 0 < s < CURVE.n");
    }
    addRecoveryBit(recovery) {
      return new Signature2(this.r, this.s, recovery);
    }
    recoverPublicKey(msgHash) {
      const { r, s, recovery: rec } = this;
      const h = bits2int_modN(ensureBytes("msgHash", msgHash));
      if (rec == null || ![0, 1, 2, 3].includes(rec))
        throw new Error("recovery id invalid");
      const radj = rec === 2 || rec === 3 ? r + CURVE.n : r;
      if (radj >= Fp2.ORDER)
        throw new Error("recovery id 2 or 3 invalid");
      const prefix = (rec & 1) === 0 ? "02" : "03";
      const R = Point2.fromHex(prefix + numToNByteStr(radj));
      const ir2 = invN(radj);
      const u1 = modN(-h * ir2);
      const u2 = modN(s * ir2);
      const Q = Point2.BASE.multiplyAndAddUnsafe(R, u1, u2);
      if (!Q)
        throw new Error("point at infinify");
      Q.assertValidity();
      return Q;
    }
    // Signatures should be low-s, to prevent malleability.
    hasHighS() {
      return isBiggerThanHalfOrder(this.s);
    }
    normalizeS() {
      return this.hasHighS() ? new Signature2(this.r, modN(-this.s), this.recovery) : this;
    }
    // DER-encoded
    toDERRawBytes() {
      return hexToBytes(this.toDERHex());
    }
    toDERHex() {
      return DER.hexFromSig({ r: this.r, s: this.s });
    }
    // padded bytes of r, then padded bytes of s
    toCompactRawBytes() {
      return hexToBytes(this.toCompactHex());
    }
    toCompactHex() {
      return numToNByteStr(this.r) + numToNByteStr(this.s);
    }
  }
  const utils = {
    isValidPrivateKey(privateKey) {
      try {
        normPrivateKeyToScalar(privateKey);
        return true;
      } catch (error) {
        return false;
      }
    },
    normPrivateKeyToScalar,
    /**
     * Produces cryptographically secure private key from random of size
     * (groupLen + ceil(groupLen / 2)) with modulo bias being negligible.
     */
    randomPrivateKey: () => {
      const length = getMinHashLength(CURVE.n);
      return mapHashToField(CURVE.randomBytes(length), CURVE.n);
    },
    /**
     * Creates precompute table for an arbitrary EC point. Makes point "cached".
     * Allows to massively speed-up `point.multiply(scalar)`.
     * @returns cached point
     * @example
     * const fast = utils.precompute(8, ProjectivePoint.fromHex(someonesPubKey));
     * fast.multiply(privKey); // much faster ECDH now
     */
    precompute(windowSize = 8, point = Point2.BASE) {
      point._setWindowSize(windowSize);
      point.multiply(BigInt(3));
      return point;
    }
  };
  function getPublicKey(privateKey, isCompressed = true) {
    return Point2.fromPrivateKey(privateKey).toRawBytes(isCompressed);
  }
  function isProbPub(item) {
    const arr = item instanceof Uint8Array;
    const str = typeof item === "string";
    const len = (arr || str) && item.length;
    if (arr)
      return len === compressedLen || len === uncompressedLen;
    if (str)
      return len === 2 * compressedLen || len === 2 * uncompressedLen;
    if (item instanceof Point2)
      return true;
    return false;
  }
  function getSharedSecret(privateA, publicB, isCompressed = true) {
    if (isProbPub(privateA))
      throw new Error("first arg must be private key");
    if (!isProbPub(publicB))
      throw new Error("second arg must be public key");
    const b = Point2.fromHex(publicB);
    return b.multiply(normPrivateKeyToScalar(privateA)).toRawBytes(isCompressed);
  }
  const bits2int = CURVE.bits2int || function(bytes2) {
    const num = bytesToNumberBE(bytes2);
    const delta = bytes2.length * 8 - CURVE.nBitLength;
    return delta > 0 ? num >> BigInt(delta) : num;
  };
  const bits2int_modN = CURVE.bits2int_modN || function(bytes2) {
    return modN(bits2int(bytes2));
  };
  const ORDER_MASK = bitMask(CURVE.nBitLength);
  function int2octets(num) {
    if (typeof num !== "bigint")
      throw new Error("bigint expected");
    if (!(_0n5 <= num && num < ORDER_MASK))
      throw new Error(`bigint expected < 2^${CURVE.nBitLength}`);
    return numberToBytesBE(num, CURVE.nByteLength);
  }
  function prepSig(msgHash, privateKey, opts = defaultSigOpts) {
    if (["recovered", "canonical"].some((k) => k in opts))
      throw new Error("sign() legacy options not supported");
    const { hash: hash2, randomBytes: randomBytes3 } = CURVE;
    let { lowS, prehash, extraEntropy: ent } = opts;
    if (lowS == null)
      lowS = true;
    msgHash = ensureBytes("msgHash", msgHash);
    if (prehash)
      msgHash = ensureBytes("prehashed msgHash", hash2(msgHash));
    const h1int = bits2int_modN(msgHash);
    const d = normPrivateKeyToScalar(privateKey);
    const seedArgs = [int2octets(d), int2octets(h1int)];
    if (ent != null) {
      const e = ent === true ? randomBytes3(Fp2.BYTES) : ent;
      seedArgs.push(ensureBytes("extraEntropy", e));
    }
    const seed = concatBytes2(...seedArgs);
    const m = h1int;
    function k2sig(kBytes) {
      const k = bits2int(kBytes);
      if (!isWithinCurveOrder(k))
        return;
      const ik = invN(k);
      const q = Point2.BASE.multiply(k).toAffine();
      const r = modN(q.x);
      if (r === _0n5)
        return;
      const s = modN(ik * modN(m + r * d));
      if (s === _0n5)
        return;
      let recovery = (q.x === r ? 0 : 2) | Number(q.y & _1n5);
      let normS = s;
      if (lowS && isBiggerThanHalfOrder(s)) {
        normS = normalizeS(s);
        recovery ^= 1;
      }
      return new Signature2(r, normS, recovery);
    }
    return { seed, k2sig };
  }
  const defaultSigOpts = { lowS: CURVE.lowS, prehash: false };
  const defaultVerOpts = { lowS: CURVE.lowS, prehash: false };
  function sign(msgHash, privKey, opts = defaultSigOpts) {
    const { seed, k2sig } = prepSig(msgHash, privKey, opts);
    const C = CURVE;
    const drbg = createHmacDrbg(C.hash.outputLen, C.nByteLength, C.hmac);
    return drbg(seed, k2sig);
  }
  Point2.BASE._setWindowSize(8);
  function verify(signature, msgHash, publicKey, opts = defaultVerOpts) {
    const sg = signature;
    msgHash = ensureBytes("msgHash", msgHash);
    publicKey = ensureBytes("publicKey", publicKey);
    if ("strict" in opts)
      throw new Error("options.strict was renamed to lowS");
    const { lowS, prehash } = opts;
    let _sig = void 0;
    let P;
    try {
      if (typeof sg === "string" || sg instanceof Uint8Array) {
        try {
          _sig = Signature2.fromDER(sg);
        } catch (derError) {
          if (!(derError instanceof DER.Err))
            throw derError;
          _sig = Signature2.fromCompact(sg);
        }
      } else if (typeof sg === "object" && typeof sg.r === "bigint" && typeof sg.s === "bigint") {
        const { r: r2, s: s2 } = sg;
        _sig = new Signature2(r2, s2);
      } else {
        throw new Error("PARSE");
      }
      P = Point2.fromHex(publicKey);
    } catch (error) {
      if (error.message === "PARSE")
        throw new Error(`signature must be Signature instance, Uint8Array or hex string`);
      return false;
    }
    if (lowS && _sig.hasHighS())
      return false;
    if (prehash)
      msgHash = CURVE.hash(msgHash);
    const { r, s } = _sig;
    const h = bits2int_modN(msgHash);
    const is2 = invN(s);
    const u1 = modN(h * is2);
    const u2 = modN(r * is2);
    const R = Point2.BASE.multiplyAndAddUnsafe(P, u1, u2)?.toAffine();
    if (!R)
      return false;
    const v = modN(R.x);
    return v === r;
  }
  return {
    CURVE,
    getPublicKey,
    getSharedSecret,
    sign,
    verify,
    ProjectivePoint: Point2,
    Signature: Signature2,
    utils
  };
}

// economy/node_modules/@noble/curves/esm/_shortw_utils.js
function getHash(hash2) {
  return {
    hash: hash2,
    hmac: (key, ...msgs) => hmac(hash2, key, concatBytes(...msgs)),
    randomBytes: randomBytes2
  };
}
function createCurve(curveDef, defHash) {
  const create = (hash2) => weierstrass({ ...curveDef, ...getHash(hash2) });
  return Object.freeze({ ...create(defHash), create });
}

// economy/node_modules/@noble/curves/esm/secp256k1.js
var secp256k1P = BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f");
var secp256k1N = BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141");
var _1n6 = BigInt(1);
var _2n5 = BigInt(2);
var divNearest = (a, b) => (a + b / _2n5) / b;
function sqrtMod(y) {
  const P = secp256k1P;
  const _3n3 = BigInt(3), _6n = BigInt(6), _11n = BigInt(11), _22n = BigInt(22);
  const _23n = BigInt(23), _44n = BigInt(44), _88n = BigInt(88);
  const b2 = y * y * y % P;
  const b3 = b2 * b2 * y % P;
  const b6 = pow2(b3, _3n3, P) * b3 % P;
  const b9 = pow2(b6, _3n3, P) * b3 % P;
  const b11 = pow2(b9, _2n5, P) * b2 % P;
  const b22 = pow2(b11, _11n, P) * b11 % P;
  const b44 = pow2(b22, _22n, P) * b22 % P;
  const b88 = pow2(b44, _44n, P) * b44 % P;
  const b176 = pow2(b88, _88n, P) * b88 % P;
  const b220 = pow2(b176, _44n, P) * b44 % P;
  const b223 = pow2(b220, _3n3, P) * b3 % P;
  const t1 = pow2(b223, _23n, P) * b22 % P;
  const t22 = pow2(t1, _6n, P) * b2 % P;
  const root = pow2(t22, _2n5, P);
  if (!Fp.eql(Fp.sqr(root), y))
    throw new Error("Cannot find square root");
  return root;
}
var Fp = Field(secp256k1P, void 0, void 0, { sqrt: sqrtMod });
var secp256k1 = createCurve({
  a: BigInt(0),
  b: BigInt(7),
  Fp,
  n: secp256k1N,
  // Base point (x, y) aka generator point
  Gx: BigInt("55066263022277343669578718895168534326250603453777594175500187360389116729240"),
  Gy: BigInt("32670510020758816978083085130507043184471273380659243275938904335757337482424"),
  h: BigInt(1),
  lowS: true,
  /**
   * secp256k1 belongs to Koblitz curves: it has efficiently computable endomorphism.
   * Endomorphism uses 2x less RAM, speeds up precomputation by 2x and ECDH / key recovery by 20%.
   * For precomputed wNAF it trades off 1/2 init time & 1/3 ram for 20% perf hit.
   * Explanation: https://gist.github.com/paulmillr/eb670806793e84df628a7c434a873066
   */
  endo: {
    beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee"),
    splitScalar: (k) => {
      const n = secp256k1N;
      const a1 = BigInt("0x3086d221a7d46bcde86c90e49284eb15");
      const b1 = -_1n6 * BigInt("0xe4437ed6010e88286f547fa90abfe4c3");
      const a2 = BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8");
      const b2 = a1;
      const POW_2_128 = BigInt("0x100000000000000000000000000000000");
      const c1 = divNearest(b2 * k, n);
      const c2 = divNearest(-b1 * k, n);
      let k1 = mod(k - c1 * a1 - c2 * a2, n);
      let k2 = mod(-c1 * b1 - c2 * b2, n);
      const k1neg = k1 > POW_2_128;
      const k2neg = k2 > POW_2_128;
      if (k1neg)
        k1 = n - k1;
      if (k2neg)
        k2 = n - k2;
      if (k1 > POW_2_128 || k2 > POW_2_128) {
        throw new Error("splitScalar: Endomorphism failed, k=" + k);
      }
      return { k1neg, k1, k2neg, k2 };
    }
  }
}, sha256);
var _0n6 = BigInt(0);
var Point = secp256k1.ProjectivePoint;

// economy/node_modules/ethers/lib.esm/constants/addresses.js
var ZeroAddress = "0x0000000000000000000000000000000000000000";

// economy/node_modules/ethers/lib.esm/constants/hashes.js
var ZeroHash = "0x0000000000000000000000000000000000000000000000000000000000000000";

// economy/node_modules/ethers/lib.esm/crypto/signature.js
var BN_02 = BigInt(0);
var BN_12 = BigInt(1);
var BN_2 = BigInt(2);
var BN_27 = BigInt(27);
var BN_28 = BigInt(28);
var BN_35 = BigInt(35);
var BN_N = BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141");
var BN_N_2 = BN_N / BN_2;
var inspect = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
var _guard = {};
function toUint256(value) {
  return zeroPadValue(toBeArray(value), 32);
}
var Signature = class _Signature {
  #r;
  #s;
  #v;
  #networkV;
  /**
   *  The ``r`` value for a signature.
   *
   *  This represents the ``x`` coordinate of a "reference" or
   *  challenge point, from which the ``y`` can be computed.
   */
  get r() {
    return this.#r;
  }
  set r(value) {
    assertArgument(dataLength(value) === 32, "invalid r", "value", value);
    this.#r = hexlify(value);
  }
  /**
   *  The ``s`` value for a signature.
   */
  get s() {
    assertArgument(parseInt(this.#s.substring(0, 3)) < 8, "non-canonical s; use ._s", "s", this.#s);
    return this.#s;
  }
  set s(_value) {
    assertArgument(dataLength(_value) === 32, "invalid s", "value", _value);
    this.#s = hexlify(_value);
  }
  /**
   *  Return the s value, unchecked for EIP-2 compliance.
   *
   *  This should generally not be used and is for situations where
   *  a non-canonical S value might be relevant, such as Frontier blocks
   *  that were mined prior to EIP-2 or invalid Authorization List
   *  signatures.
   */
  get _s() {
    return this.#s;
  }
  /**
   *  Returns true if the Signature is valid for [[link-eip-2]] signatures.
   */
  isValid() {
    const s = BigInt(this.#s);
    return s <= BN_N_2;
  }
  /**
   *  The ``v`` value for a signature.
   *
   *  Since a given ``x`` value for ``r`` has two possible values for
   *  its correspondin ``y``, the ``v`` indicates which of the two ``y``
   *  values to use.
   *
   *  It is normalized to the values ``27`` or ``28`` for legacy
   *  purposes.
   */
  get v() {
    return this.#v;
  }
  set v(value) {
    const v = getNumber(value, "value");
    assertArgument(v === 27 || v === 28, "invalid v", "v", value);
    this.#v = v;
  }
  /**
   *  The EIP-155 ``v`` for legacy transactions. For non-legacy
   *  transactions, this value is ``null``.
   */
  get networkV() {
    return this.#networkV;
  }
  /**
   *  The chain ID for EIP-155 legacy transactions. For non-legacy
   *  transactions, this value is ``null``.
   */
  get legacyChainId() {
    const v = this.networkV;
    if (v == null) {
      return null;
    }
    return _Signature.getChainId(v);
  }
  /**
   *  The ``yParity`` for the signature.
   *
   *  See ``v`` for more details on how this value is used.
   */
  get yParity() {
    return this.v === 27 ? 0 : 1;
  }
  /**
   *  The [[link-eip-2098]] compact representation of the ``yParity``
   *  and ``s`` compacted into a single ``bytes32``.
   */
  get yParityAndS() {
    const yParityAndS = getBytes(this.s);
    if (this.yParity) {
      yParityAndS[0] |= 128;
    }
    return hexlify(yParityAndS);
  }
  /**
   *  The [[link-eip-2098]] compact representation.
   */
  get compactSerialized() {
    return concat([this.r, this.yParityAndS]);
  }
  /**
   *  The serialized representation.
   */
  get serialized() {
    return concat([this.r, this.s, this.yParity ? "0x1c" : "0x1b"]);
  }
  /**
   *  @private
   */
  constructor(guard, r, s, v) {
    assertPrivate(guard, _guard, "Signature");
    this.#r = r;
    this.#s = s;
    this.#v = v;
    this.#networkV = null;
  }
  /**
   *  Returns the canonical signature.
   *
   *  This is only necessary when dealing with legacy transaction which
   *  did not enforce canonical S values (i.e. [[link-eip-2]]. Most
   *  developers should never require this.
   */
  getCanonical() {
    if (this.isValid()) {
      return this;
    }
    const s = BN_N - BigInt(this._s);
    const v = 55 - this.v;
    const result = new _Signature(_guard, this.r, toUint256(s), v);
    if (this.networkV) {
      result.#networkV = this.networkV;
    }
    return result;
  }
  /**
   *  Returns a new identical [[Signature]].
   */
  clone() {
    const clone = new _Signature(_guard, this.r, this._s, this.v);
    if (this.networkV) {
      clone.#networkV = this.networkV;
    }
    return clone;
  }
  /**
   *  Returns a representation that is compatible with ``JSON.stringify``.
   */
  toJSON() {
    const networkV = this.networkV;
    return {
      _type: "signature",
      networkV: networkV != null ? networkV.toString() : null,
      r: this.r,
      s: this._s,
      v: this.v
    };
  }
  [inspect]() {
    return this.toString();
  }
  toString() {
    if (this.isValid()) {
      return `Signature { r: ${this.r}, s: ${this._s}, v: ${this.v} }`;
    }
    return `Signature { r: ${this.r}, s: ${this._s}, v: ${this.v}, valid: false }`;
  }
  /**
   *  Compute the chain ID from the ``v`` in a legacy EIP-155 transactions.
   *
   *  @example:
   *    Signature.getChainId(45)
   *    //_result:
   *
   *    Signature.getChainId(46)
   *    //_result:
   */
  static getChainId(v) {
    const bv = getBigInt(v, "v");
    if (bv == BN_27 || bv == BN_28) {
      return BN_02;
    }
    assertArgument(bv >= BN_35, "invalid EIP-155 v", "v", v);
    return (bv - BN_35) / BN_2;
  }
  /**
   *  Compute the ``v`` for a chain ID for a legacy EIP-155 transactions.
   *
   *  Legacy transactions which use [[link-eip-155]] hijack the ``v``
   *  property to include the chain ID.
   *
   *  @example:
   *    Signature.getChainIdV(5, 27)
   *    //_result:
   *
   *    Signature.getChainIdV(5, 28)
   *    //_result:
   *
   */
  static getChainIdV(chainId, v) {
    return getBigInt(chainId) * BN_2 + BigInt(35 + v - 27);
  }
  /**
   *  Compute the normalized legacy transaction ``v`` from a ``yParirty``,
   *  a legacy transaction ``v`` or a legacy [[link-eip-155]] transaction.
   *
   *  @example:
   *    // The values 0 and 1 imply v is actually yParity
   *    Signature.getNormalizedV(0)
   *    //_result:
   *
   *    // Legacy non-EIP-1559 transaction (i.e. 27 or 28)
   *    Signature.getNormalizedV(27)
   *    //_result:
   *
   *    // Legacy EIP-155 transaction (i.e. >= 35)
   *    Signature.getNormalizedV(46)
   *    //_result:
   *
   *    // Invalid values throw
   *    Signature.getNormalizedV(5)
   *    //_error:
   */
  static getNormalizedV(v) {
    const bv = getBigInt(v);
    if (bv === BN_02 || bv === BN_27) {
      return 27;
    }
    if (bv === BN_12 || bv === BN_28) {
      return 28;
    }
    assertArgument(bv >= BN_35, "invalid v", "v", v);
    return bv & BN_12 ? 27 : 28;
  }
  /**
   *  Creates a new [[Signature]].
   *
   *  If no %%sig%% is provided, a new [[Signature]] is created
   *  with default values.
   *
   *  If %%sig%% is a string, it is parsed.
   */
  static from(sig) {
    function assertError(check, message) {
      assertArgument(check, message, "signature", sig);
    }
    ;
    if (sig == null) {
      return new _Signature(_guard, ZeroHash, ZeroHash, 27);
    }
    if (typeof sig === "string") {
      const bytes2 = getBytes(sig, "signature");
      if (bytes2.length === 64) {
        const r2 = hexlify(bytes2.slice(0, 32));
        const s2 = bytes2.slice(32, 64);
        const v2 = s2[0] & 128 ? 28 : 27;
        s2[0] &= 127;
        return new _Signature(_guard, r2, hexlify(s2), v2);
      }
      if (bytes2.length === 65) {
        const r2 = hexlify(bytes2.slice(0, 32));
        const s2 = hexlify(bytes2.slice(32, 64));
        const v2 = _Signature.getNormalizedV(bytes2[64]);
        return new _Signature(_guard, r2, s2, v2);
      }
      assertError(false, "invalid raw signature length");
    }
    if (sig instanceof _Signature) {
      return sig.clone();
    }
    const _r2 = sig.r;
    assertError(_r2 != null, "missing r");
    const r = toUint256(_r2);
    const s = (function(s2, yParityAndS) {
      if (s2 != null) {
        return toUint256(s2);
      }
      if (yParityAndS != null) {
        assertError(isHexString(yParityAndS, 32), "invalid yParityAndS");
        const bytes2 = getBytes(yParityAndS);
        bytes2[0] &= 127;
        return hexlify(bytes2);
      }
      assertError(false, "missing s");
    })(sig.s, sig.yParityAndS);
    const { networkV, v } = (function(_v, yParityAndS, yParity) {
      if (_v != null) {
        const v2 = getBigInt(_v);
        return {
          networkV: v2 >= BN_35 ? v2 : void 0,
          v: _Signature.getNormalizedV(v2)
        };
      }
      if (yParityAndS != null) {
        assertError(isHexString(yParityAndS, 32), "invalid yParityAndS");
        return { v: getBytes(yParityAndS)[0] & 128 ? 28 : 27 };
      }
      if (yParity != null) {
        switch (getNumber(yParity, "sig.yParity")) {
          case 0:
            return { v: 27 };
          case 1:
            return { v: 28 };
        }
        assertError(false, "invalid yParity");
      }
      assertError(false, "missing v");
    })(sig.v, sig.yParityAndS, sig.yParity);
    const result = new _Signature(_guard, r, s, v);
    if (networkV) {
      result.#networkV = networkV;
    }
    assertError(sig.yParity == null || getNumber(sig.yParity, "sig.yParity") === result.yParity, "yParity mismatch");
    assertError(sig.yParityAndS == null || sig.yParityAndS === result.yParityAndS, "yParityAndS mismatch");
    return result;
  }
};

// economy/node_modules/ethers/lib.esm/crypto/signing-key.js
var SigningKey = class _SigningKey {
  #privateKey;
  /**
   *  Creates a new **SigningKey** for %%privateKey%%.
   */
  constructor(privateKey) {
    assertArgument(dataLength(privateKey) === 32, "invalid private key", "privateKey", "[REDACTED]");
    this.#privateKey = hexlify(privateKey);
  }
  /**
   *  The private key.
   */
  get privateKey() {
    return this.#privateKey;
  }
  /**
   *  The uncompressed public key.
   *
   * This will always begin with the prefix ``0x04`` and be 132
   * characters long (the ``0x`` prefix and 130 hexadecimal nibbles).
   */
  get publicKey() {
    return _SigningKey.computePublicKey(this.#privateKey);
  }
  /**
   *  The compressed public key.
   *
   *  This will always begin with either the prefix ``0x02`` or ``0x03``
   *  and be 68 characters long (the ``0x`` prefix and 33 hexadecimal
   *  nibbles)
   */
  get compressedPublicKey() {
    return _SigningKey.computePublicKey(this.#privateKey, true);
  }
  /**
   *  Return the signature of the signed %%digest%%.
   */
  sign(digest) {
    assertArgument(dataLength(digest) === 32, "invalid digest length", "digest", digest);
    const sig = secp256k1.sign(getBytesCopy(digest), getBytesCopy(this.#privateKey), {
      lowS: true
    });
    return Signature.from({
      r: toBeHex(sig.r, 32),
      s: toBeHex(sig.s, 32),
      v: sig.recovery ? 28 : 27
    });
  }
  /**
   *  Returns the [[link-wiki-ecdh]] shared secret between this
   *  private key and the %%other%% key.
   *
   *  The %%other%% key may be any type of key, a raw public key,
   *  a compressed/uncompressed pubic key or aprivate key.
   *
   *  Best practice is usually to use a cryptographic hash on the
   *  returned value before using it as a symetric secret.
   *
   *  @example:
   *    sign1 = new SigningKey(id("some-secret-1"))
   *    sign2 = new SigningKey(id("some-secret-2"))
   *
   *    // Notice that privA.computeSharedSecret(pubB)...
   *    sign1.computeSharedSecret(sign2.publicKey)
   *    //_result:
   *
   *    // ...is equal to privB.computeSharedSecret(pubA).
   *    sign2.computeSharedSecret(sign1.publicKey)
   *    //_result:
   */
  computeSharedSecret(other) {
    const pubKey = _SigningKey.computePublicKey(other);
    return hexlify(secp256k1.getSharedSecret(getBytesCopy(this.#privateKey), getBytes(pubKey), false));
  }
  /**
   *  Compute the public key for %%key%%, optionally %%compressed%%.
   *
   *  The %%key%% may be any type of key, a raw public key, a
   *  compressed/uncompressed public key or private key.
   *
   *  @example:
   *    sign = new SigningKey(id("some-secret"));
   *
   *    // Compute the uncompressed public key for a private key
   *    SigningKey.computePublicKey(sign.privateKey)
   *    //_result:
   *
   *    // Compute the compressed public key for a private key
   *    SigningKey.computePublicKey(sign.privateKey, true)
   *    //_result:
   *
   *    // Compute the uncompressed public key
   *    SigningKey.computePublicKey(sign.publicKey, false);
   *    //_result:
   *
   *    // Compute the Compressed a public key
   *    SigningKey.computePublicKey(sign.publicKey, true);
   *    //_result:
   */
  static computePublicKey(key, compressed) {
    let bytes2 = getBytes(key, "key");
    if (bytes2.length === 32) {
      const pubKey = secp256k1.getPublicKey(bytes2, !!compressed);
      return hexlify(pubKey);
    }
    if (bytes2.length === 64) {
      const pub = new Uint8Array(65);
      pub[0] = 4;
      pub.set(bytes2, 1);
      bytes2 = pub;
    }
    const point = secp256k1.ProjectivePoint.fromHex(bytes2);
    return hexlify(point.toRawBytes(compressed));
  }
  /**
   *  Returns the public key for the private key which produced the
   *  %%signature%% for the given %%digest%%.
   *
   *  @example:
   *    key = new SigningKey(id("some-secret"))
   *    digest = id("hello world")
   *    sig = key.sign(digest)
   *
   *    // Notice the signer public key...
   *    key.publicKey
   *    //_result:
   *
   *    // ...is equal to the recovered public key
   *    SigningKey.recoverPublicKey(digest, sig)
   *    //_result:
   *
   */
  static recoverPublicKey(digest, signature) {
    assertArgument(dataLength(digest) === 32, "invalid digest length", "digest", digest);
    const sig = Signature.from(signature);
    let secpSig = secp256k1.Signature.fromCompact(getBytesCopy(concat([sig.r, sig.s])));
    secpSig = secpSig.addRecoveryBit(sig.yParity);
    const pubKey = secpSig.recoverPublicKey(getBytesCopy(digest));
    assertArgument(pubKey != null, "invalid signature for digest", "signature", signature);
    return "0x" + pubKey.toHex(false);
  }
  /**
   *  Returns the point resulting from adding the ellipic curve points
   *  %%p0%% and %%p1%%.
   *
   *  This is not a common function most developers should require, but
   *  can be useful for certain privacy-specific techniques.
   *
   *  For example, it is used by [[HDNodeWallet]] to compute child
   *  addresses from parent public keys and chain codes.
   */
  static addPoints(p0, p1, compressed) {
    const pub0 = secp256k1.ProjectivePoint.fromHex(_SigningKey.computePublicKey(p0).substring(2));
    const pub1 = secp256k1.ProjectivePoint.fromHex(_SigningKey.computePublicKey(p1).substring(2));
    return "0x" + pub0.add(pub1).toHex(!!compressed);
  }
};

// economy/node_modules/ethers/lib.esm/address/address.js
var BN_03 = BigInt(0);
var BN_36 = BigInt(36);
function getChecksumAddress(address) {
  address = address.toLowerCase();
  const chars = address.substring(2).split("");
  const expanded = new Uint8Array(40);
  for (let i = 0; i < 40; i++) {
    expanded[i] = chars[i].charCodeAt(0);
  }
  const hashed = getBytes(keccak256(expanded));
  for (let i = 0; i < 40; i += 2) {
    if (hashed[i >> 1] >> 4 >= 8) {
      chars[i] = chars[i].toUpperCase();
    }
    if ((hashed[i >> 1] & 15) >= 8) {
      chars[i + 1] = chars[i + 1].toUpperCase();
    }
  }
  return "0x" + chars.join("");
}
var ibanLookup = {};
for (let i = 0; i < 10; i++) {
  ibanLookup[String(i)] = String(i);
}
for (let i = 0; i < 26; i++) {
  ibanLookup[String.fromCharCode(65 + i)] = String(10 + i);
}
var safeDigits = 15;
function ibanChecksum(address) {
  address = address.toUpperCase();
  address = address.substring(4) + address.substring(0, 2) + "00";
  let expanded = address.split("").map((c) => {
    return ibanLookup[c];
  }).join("");
  while (expanded.length >= safeDigits) {
    let block = expanded.substring(0, safeDigits);
    expanded = parseInt(block, 10) % 97 + expanded.substring(block.length);
  }
  let checksum = String(98 - parseInt(expanded, 10) % 97);
  while (checksum.length < 2) {
    checksum = "0" + checksum;
  }
  return checksum;
}
var Base36 = (function() {
  ;
  const result = {};
  for (let i = 0; i < 36; i++) {
    const key = "0123456789abcdefghijklmnopqrstuvwxyz"[i];
    result[key] = BigInt(i);
  }
  return result;
})();
function fromBase36(value) {
  value = value.toLowerCase();
  let result = BN_03;
  for (let i = 0; i < value.length; i++) {
    result = result * BN_36 + Base36[value[i]];
  }
  return result;
}
function getAddress(address) {
  assertArgument(typeof address === "string", "invalid address", "address", address);
  if (address.match(/^(0x)?[0-9a-fA-F]{40}$/)) {
    if (!address.startsWith("0x")) {
      address = "0x" + address;
    }
    const result = getChecksumAddress(address);
    assertArgument(!address.match(/([A-F].*[a-f])|([a-f].*[A-F])/) || result === address, "bad address checksum", "address", address);
    return result;
  }
  if (address.match(/^XE[0-9]{2}[0-9A-Za-z]{30,31}$/)) {
    assertArgument(address.substring(2, 4) === ibanChecksum(address), "bad icap checksum", "address", address);
    let result = fromBase36(address.substring(4)).toString(16);
    while (result.length < 40) {
      result = "0" + result;
    }
    return getChecksumAddress("0x" + result);
  }
  assertArgument(false, "invalid address", "address", address);
}

// economy/node_modules/ethers/lib.esm/transaction/accesslist.js
function accessSetify(addr, storageKeys) {
  return {
    address: getAddress(addr),
    storageKeys: storageKeys.map((storageKey, index) => {
      assertArgument(isHexString(storageKey, 32), "invalid slot", `storageKeys[${index}]`, storageKey);
      return storageKey.toLowerCase();
    })
  };
}
function accessListify(value) {
  if (Array.isArray(value)) {
    return value.map((set, index) => {
      if (Array.isArray(set)) {
        assertArgument(set.length === 2, "invalid slot set", `value[${index}]`, set);
        return accessSetify(set[0], set[1]);
      }
      assertArgument(set != null && typeof set === "object", "invalid address-slot set", "value", value);
      return accessSetify(set.address, set.storageKeys);
    });
  }
  assertArgument(value != null && typeof value === "object", "invalid access list", "value", value);
  const result = Object.keys(value).map((addr) => {
    const storageKeys = value[addr].reduce((accum, storageKey) => {
      accum[storageKey] = true;
      return accum;
    }, {});
    return accessSetify(addr, Object.keys(storageKeys).sort());
  });
  result.sort((a, b) => a.address.localeCompare(b.address));
  return result;
}

// economy/node_modules/ethers/lib.esm/transaction/authorization.js
function authorizationify(auth) {
  return {
    address: getAddress(auth.address),
    nonce: getBigInt(auth.nonce != null ? auth.nonce : 0),
    chainId: getBigInt(auth.chainId != null ? auth.chainId : 0),
    signature: Signature.from(auth.signature)
  };
}

// economy/node_modules/ethers/lib.esm/transaction/address.js
function computeAddress(key) {
  let pubkey;
  if (typeof key === "string") {
    pubkey = SigningKey.computePublicKey(key, false);
  } else {
    pubkey = key.publicKey;
  }
  return getAddress(keccak256("0x" + pubkey.substring(4)).substring(26));
}
function recoverAddress(digest, signature) {
  return computeAddress(SigningKey.recoverPublicKey(digest, signature));
}

// economy/node_modules/ethers/lib.esm/transaction/transaction.js
var BN_04 = BigInt(0);
var BN_22 = BigInt(2);
var BN_272 = BigInt(27);
var BN_282 = BigInt(28);
var BN_352 = BigInt(35);
var BN_MAX_UINT = BigInt("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
var inspect2 = /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom");
var BLOB_SIZE = 4096 * 32;
var CELL_COUNT = 128;
function getKzgLibrary(kzg) {
  const blobToKzgCommitment = (blob) => {
    if ("computeBlobProof" in kzg) {
      if ("blobToKzgCommitment" in kzg && typeof kzg.blobToKzgCommitment === "function") {
        return getBytes(kzg.blobToKzgCommitment(hexlify(blob)));
      }
    } else if ("blobToKzgCommitment" in kzg && typeof kzg.blobToKzgCommitment === "function") {
      return getBytes(kzg.blobToKzgCommitment(blob));
    }
    if ("blobToKZGCommitment" in kzg && typeof kzg.blobToKZGCommitment === "function") {
      return getBytes(kzg.blobToKZGCommitment(hexlify(blob)));
    }
    assertArgument(false, "unsupported KZG library", "kzg", kzg);
  };
  const computeBlobKzgProof = (blob, commitment) => {
    if ("computeBlobProof" in kzg && typeof kzg.computeBlobProof === "function") {
      return getBytes(kzg.computeBlobProof(hexlify(blob), hexlify(commitment)));
    }
    if ("computeBlobKzgProof" in kzg && typeof kzg.computeBlobKzgProof === "function") {
      return kzg.computeBlobKzgProof(blob, commitment);
    }
    if ("computeBlobKZGProof" in kzg && typeof kzg.computeBlobKZGProof === "function") {
      return getBytes(kzg.computeBlobKZGProof(hexlify(blob), hexlify(commitment)));
    }
    assertArgument(false, "unsupported KZG library", "kzg", kzg);
  };
  return { blobToKzgCommitment, computeBlobKzgProof };
}
function getVersionedHash(version2, hash2) {
  let versioned = version2.toString(16);
  while (versioned.length < 2) {
    versioned = "0" + versioned;
  }
  versioned += sha2562(hash2).substring(4);
  return "0x" + versioned;
}
function handleAddress(value) {
  if (value === "0x") {
    return null;
  }
  return getAddress(value);
}
function handleAccessList(value, param) {
  try {
    return accessListify(value);
  } catch (error) {
    assertArgument(false, error.message, param, value);
  }
}
function handleAuthorizationList(value, param) {
  try {
    if (!Array.isArray(value)) {
      throw new Error("authorizationList: invalid array");
    }
    const result = [];
    for (let i = 0; i < value.length; i++) {
      const auth = value[i];
      if (!Array.isArray(auth)) {
        throw new Error(`authorization[${i}]: invalid array`);
      }
      if (auth.length !== 6) {
        throw new Error(`authorization[${i}]: wrong length`);
      }
      if (!auth[1]) {
        throw new Error(`authorization[${i}]: null address`);
      }
      result.push({
        address: handleAddress(auth[1]),
        nonce: handleUint(auth[2], "nonce"),
        chainId: handleUint(auth[0], "chainId"),
        signature: Signature.from({
          yParity: handleNumber(auth[3], "yParity"),
          r: zeroPadValue(auth[4], 32),
          s: zeroPadValue(auth[5], 32)
        })
      });
    }
    return result;
  } catch (error) {
    assertArgument(false, error.message, param, value);
  }
}
function handleNumber(_value, param) {
  if (_value === "0x") {
    return 0;
  }
  return getNumber(_value, param);
}
function handleUint(_value, param) {
  if (_value === "0x") {
    return BN_04;
  }
  const value = getBigInt(_value, param);
  assertArgument(value <= BN_MAX_UINT, "value exceeds uint size", param, value);
  return value;
}
function formatNumber(_value, name) {
  const value = getBigInt(_value, "value");
  const result = toBeArray(value);
  assertArgument(result.length <= 32, `value too large`, `tx.${name}`, value);
  return result;
}
function formatAccessList(value) {
  return accessListify(value).map((set) => [set.address, set.storageKeys]);
}
function formatAuthorizationList(value) {
  return value.map((a) => {
    return [
      formatNumber(a.chainId, "chainId"),
      a.address,
      formatNumber(a.nonce, "nonce"),
      formatNumber(a.signature.yParity, "yParity"),
      toBeArray(a.signature.r),
      toBeArray(a.signature._s)
    ];
  });
}
function formatHashes(value, param) {
  assertArgument(Array.isArray(value), `invalid ${param}`, "value", value);
  for (let i = 0; i < value.length; i++) {
    assertArgument(isHexString(value[i], 32), "invalid ${ param } hash", `value[${i}]`, value[i]);
  }
  return value;
}
function _parseLegacy(data) {
  const fields = decodeRlp(data);
  assertArgument(Array.isArray(fields) && (fields.length === 9 || fields.length === 6), "invalid field count for legacy transaction", "data", data);
  const tx = {
    type: 0,
    nonce: handleNumber(fields[0], "nonce"),
    gasPrice: handleUint(fields[1], "gasPrice"),
    gasLimit: handleUint(fields[2], "gasLimit"),
    to: handleAddress(fields[3]),
    value: handleUint(fields[4], "value"),
    data: hexlify(fields[5]),
    chainId: BN_04
  };
  if (fields.length === 6) {
    return tx;
  }
  const v = handleUint(fields[6], "v");
  const r = handleUint(fields[7], "r");
  const s = handleUint(fields[8], "s");
  if (r === BN_04 && s === BN_04) {
    tx.chainId = v;
  } else {
    let chainId = (v - BN_352) / BN_22;
    if (chainId < BN_04) {
      chainId = BN_04;
    }
    tx.chainId = chainId;
    assertArgument(chainId !== BN_04 || (v === BN_272 || v === BN_282), "non-canonical legacy v", "v", fields[6]);
    tx.signature = Signature.from({
      r: zeroPadValue(fields[7], 32),
      s: zeroPadValue(fields[8], 32),
      v
    });
  }
  return tx;
}
function _serializeLegacy(tx, sig) {
  const fields = [
    formatNumber(tx.nonce, "nonce"),
    formatNumber(tx.gasPrice || 0, "gasPrice"),
    formatNumber(tx.gasLimit, "gasLimit"),
    tx.to || "0x",
    formatNumber(tx.value, "value"),
    tx.data
  ];
  let chainId = BN_04;
  if (tx.chainId != BN_04) {
    chainId = getBigInt(tx.chainId, "tx.chainId");
    assertArgument(!sig || sig.networkV == null || sig.legacyChainId === chainId, "tx.chainId/sig.v mismatch", "sig", sig);
  } else if (tx.signature) {
    const legacy = tx.signature.legacyChainId;
    if (legacy != null) {
      chainId = legacy;
    }
  }
  if (!sig) {
    if (chainId !== BN_04) {
      fields.push(toBeArray(chainId));
      fields.push("0x");
      fields.push("0x");
    }
    return encodeRlp(fields);
  }
  let v = BigInt(27 + sig.yParity);
  if (chainId !== BN_04) {
    v = Signature.getChainIdV(chainId, sig.v);
  } else if (BigInt(sig.v) !== v) {
    assertArgument(false, "tx.chainId/sig.v mismatch", "sig", sig);
  }
  fields.push(toBeArray(v));
  fields.push(toBeArray(sig.r));
  fields.push(toBeArray(sig._s));
  return encodeRlp(fields);
}
function _parseEipSignature(tx, fields) {
  let yParity;
  try {
    yParity = handleNumber(fields[0], "yParity");
    if (yParity !== 0 && yParity !== 1) {
      throw new Error("bad yParity");
    }
  } catch (error) {
    assertArgument(false, "invalid yParity", "yParity", fields[0]);
  }
  const r = zeroPadValue(fields[1], 32);
  const s = zeroPadValue(fields[2], 32);
  const signature = Signature.from({ r, s, yParity });
  tx.signature = signature;
}
function _parseEip1559(data) {
  const fields = decodeRlp(getBytes(data).slice(1));
  assertArgument(Array.isArray(fields) && (fields.length === 9 || fields.length === 12), "invalid field count for transaction type: 2", "data", hexlify(data));
  const tx = {
    type: 2,
    chainId: handleUint(fields[0], "chainId"),
    nonce: handleNumber(fields[1], "nonce"),
    maxPriorityFeePerGas: handleUint(fields[2], "maxPriorityFeePerGas"),
    maxFeePerGas: handleUint(fields[3], "maxFeePerGas"),
    gasPrice: null,
    gasLimit: handleUint(fields[4], "gasLimit"),
    to: handleAddress(fields[5]),
    value: handleUint(fields[6], "value"),
    data: hexlify(fields[7]),
    accessList: handleAccessList(fields[8], "accessList")
  };
  if (fields.length === 9) {
    return tx;
  }
  _parseEipSignature(tx, fields.slice(9));
  return tx;
}
function _serializeEip1559(tx, sig) {
  const fields = [
    formatNumber(tx.chainId, "chainId"),
    formatNumber(tx.nonce, "nonce"),
    formatNumber(tx.maxPriorityFeePerGas || 0, "maxPriorityFeePerGas"),
    formatNumber(tx.maxFeePerGas || 0, "maxFeePerGas"),
    formatNumber(tx.gasLimit, "gasLimit"),
    tx.to || "0x",
    formatNumber(tx.value, "value"),
    tx.data,
    formatAccessList(tx.accessList || [])
  ];
  if (sig) {
    fields.push(formatNumber(sig.yParity, "yParity"));
    fields.push(toBeArray(sig.r));
    fields.push(toBeArray(sig.s));
  }
  return concat(["0x02", encodeRlp(fields)]);
}
function _parseEip2930(data) {
  const fields = decodeRlp(getBytes(data).slice(1));
  assertArgument(Array.isArray(fields) && (fields.length === 8 || fields.length === 11), "invalid field count for transaction type: 1", "data", hexlify(data));
  const tx = {
    type: 1,
    chainId: handleUint(fields[0], "chainId"),
    nonce: handleNumber(fields[1], "nonce"),
    gasPrice: handleUint(fields[2], "gasPrice"),
    gasLimit: handleUint(fields[3], "gasLimit"),
    to: handleAddress(fields[4]),
    value: handleUint(fields[5], "value"),
    data: hexlify(fields[6]),
    accessList: handleAccessList(fields[7], "accessList")
  };
  if (fields.length === 8) {
    return tx;
  }
  _parseEipSignature(tx, fields.slice(8));
  return tx;
}
function _serializeEip2930(tx, sig) {
  const fields = [
    formatNumber(tx.chainId, "chainId"),
    formatNumber(tx.nonce, "nonce"),
    formatNumber(tx.gasPrice || 0, "gasPrice"),
    formatNumber(tx.gasLimit, "gasLimit"),
    tx.to || "0x",
    formatNumber(tx.value, "value"),
    tx.data,
    formatAccessList(tx.accessList || [])
  ];
  if (sig) {
    fields.push(formatNumber(sig.yParity, "recoveryParam"));
    fields.push(toBeArray(sig.r));
    fields.push(toBeArray(sig.s));
  }
  return concat(["0x01", encodeRlp(fields)]);
}
function _parseEip4844(data) {
  let fields = decodeRlp(getBytes(data).slice(1));
  let typeName = "3";
  let blobWrapperVersion = null;
  let blobs = null;
  if (fields.length === 4 && Array.isArray(fields[0])) {
    typeName = "3 (network format)";
    const fBlobs = fields[1], fCommits = fields[2], fProofs = fields[3];
    assertArgument(Array.isArray(fBlobs), "invalid network format: blobs not an array", "fields[1]", fBlobs);
    assertArgument(Array.isArray(fCommits), "invalid network format: commitments not an array", "fields[2]", fCommits);
    assertArgument(Array.isArray(fProofs), "invalid network format: proofs not an array", "fields[3]", fProofs);
    assertArgument(fBlobs.length === fCommits.length, "invalid network format: blobs/commitments length mismatch", "fields", fields);
    assertArgument(fBlobs.length === fProofs.length, "invalid network format: blobs/proofs length mismatch", "fields", fields);
    blobs = [];
    for (let i = 0; i < fields[1].length; i++) {
      blobs.push({
        data: fBlobs[i],
        commitment: fCommits[i],
        proof: fProofs[i]
      });
    }
    fields = fields[0];
  } else if (fields.length === 5 && Array.isArray(fields[0])) {
    typeName = "3 (EIP-7594 network format)";
    blobWrapperVersion = getNumber(fields[1]);
    const fBlobs = fields[2], fCommits = fields[3], fProofs = fields[4];
    assertArgument(blobWrapperVersion === 1, `unsupported EIP-7594 network format version: ${blobWrapperVersion}`, "fields[1]", blobWrapperVersion);
    assertArgument(Array.isArray(fBlobs), "invalid EIP-7594 network format: blobs not an array", "fields[2]", fBlobs);
    assertArgument(Array.isArray(fCommits), "invalid EIP-7594 network format: commitments not an array", "fields[3]", fCommits);
    assertArgument(Array.isArray(fProofs), "invalid EIP-7594 network format: proofs not an array", "fields[4]", fProofs);
    assertArgument(fBlobs.length === fCommits.length, "invalid network format: blobs/commitments length mismatch", "fields", fields);
    assertArgument(fBlobs.length * CELL_COUNT === fProofs.length, "invalid network format: blobs/proofs length mismatch", "fields", fields);
    blobs = [];
    for (let i = 0; i < fBlobs.length; i++) {
      const proof = [];
      for (let j = 0; j < CELL_COUNT; j++) {
        proof.push(fProofs[i * CELL_COUNT + j]);
      }
      blobs.push({
        data: fBlobs[i],
        commitment: fCommits[i],
        proof: concat(proof)
      });
    }
    fields = fields[0];
  }
  assertArgument(Array.isArray(fields) && (fields.length === 11 || fields.length === 14), `invalid field count for transaction type: ${typeName}`, "data", hexlify(data));
  const tx = {
    type: 3,
    chainId: handleUint(fields[0], "chainId"),
    nonce: handleNumber(fields[1], "nonce"),
    maxPriorityFeePerGas: handleUint(fields[2], "maxPriorityFeePerGas"),
    maxFeePerGas: handleUint(fields[3], "maxFeePerGas"),
    gasPrice: null,
    gasLimit: handleUint(fields[4], "gasLimit"),
    to: handleAddress(fields[5]),
    value: handleUint(fields[6], "value"),
    data: hexlify(fields[7]),
    accessList: handleAccessList(fields[8], "accessList"),
    maxFeePerBlobGas: handleUint(fields[9], "maxFeePerBlobGas"),
    blobVersionedHashes: fields[10],
    blobWrapperVersion
  };
  if (blobs) {
    tx.blobs = blobs;
  }
  assertArgument(tx.to != null, `invalid address for transaction type: ${typeName}`, "data", data);
  assertArgument(Array.isArray(tx.blobVersionedHashes), "invalid blobVersionedHashes: must be an array", "data", data);
  for (let i = 0; i < tx.blobVersionedHashes.length; i++) {
    assertArgument(isHexString(tx.blobVersionedHashes[i], 32), `invalid blobVersionedHash at index ${i}: must be length 32`, "data", data);
  }
  if (fields.length === 11) {
    return tx;
  }
  _parseEipSignature(tx, fields.slice(11));
  return tx;
}
function _serializeEip4844(tx, sig, blobs) {
  const fields = [
    formatNumber(tx.chainId, "chainId"),
    formatNumber(tx.nonce, "nonce"),
    formatNumber(tx.maxPriorityFeePerGas || 0, "maxPriorityFeePerGas"),
    formatNumber(tx.maxFeePerGas || 0, "maxFeePerGas"),
    formatNumber(tx.gasLimit, "gasLimit"),
    tx.to || ZeroAddress,
    formatNumber(tx.value, "value"),
    tx.data,
    formatAccessList(tx.accessList || []),
    formatNumber(tx.maxFeePerBlobGas || 0, "maxFeePerBlobGas"),
    formatHashes(tx.blobVersionedHashes || [], "blobVersionedHashes")
  ];
  if (sig) {
    fields.push(formatNumber(sig.yParity, "yParity"));
    fields.push(toBeArray(sig.r));
    fields.push(toBeArray(sig.s));
    if (blobs) {
      if (tx.blobWrapperVersion != null) {
        const wrapperVersion = toBeArray(tx.blobWrapperVersion);
        const cellProofs = [];
        for (const { proof } of blobs) {
          const p = getBytes(proof);
          const cellSize = p.length / CELL_COUNT;
          for (let i = 0; i < p.length; i += cellSize) {
            cellProofs.push(p.subarray(i, i + cellSize));
          }
        }
        return concat([
          "0x03",
          encodeRlp([
            fields,
            wrapperVersion,
            blobs.map((b) => b.data),
            blobs.map((b) => b.commitment),
            cellProofs
          ])
        ]);
      }
      return concat([
        "0x03",
        encodeRlp([
          fields,
          blobs.map((b) => b.data),
          blobs.map((b) => b.commitment),
          blobs.map((b) => b.proof)
        ])
      ]);
    }
  }
  return concat(["0x03", encodeRlp(fields)]);
}
function _parseEip7702(data) {
  const fields = decodeRlp(getBytes(data).slice(1));
  assertArgument(Array.isArray(fields) && (fields.length === 10 || fields.length === 13), "invalid field count for transaction type: 4", "data", hexlify(data));
  const tx = {
    type: 4,
    chainId: handleUint(fields[0], "chainId"),
    nonce: handleNumber(fields[1], "nonce"),
    maxPriorityFeePerGas: handleUint(fields[2], "maxPriorityFeePerGas"),
    maxFeePerGas: handleUint(fields[3], "maxFeePerGas"),
    gasPrice: null,
    gasLimit: handleUint(fields[4], "gasLimit"),
    to: handleAddress(fields[5]),
    value: handleUint(fields[6], "value"),
    data: hexlify(fields[7]),
    accessList: handleAccessList(fields[8], "accessList"),
    authorizationList: handleAuthorizationList(fields[9], "authorizationList")
  };
  if (fields.length === 10) {
    return tx;
  }
  _parseEipSignature(tx, fields.slice(10));
  return tx;
}
function _serializeEip7702(tx, sig) {
  const fields = [
    formatNumber(tx.chainId, "chainId"),
    formatNumber(tx.nonce, "nonce"),
    formatNumber(tx.maxPriorityFeePerGas || 0, "maxPriorityFeePerGas"),
    formatNumber(tx.maxFeePerGas || 0, "maxFeePerGas"),
    formatNumber(tx.gasLimit, "gasLimit"),
    tx.to || "0x",
    formatNumber(tx.value, "value"),
    tx.data,
    formatAccessList(tx.accessList || []),
    formatAuthorizationList(tx.authorizationList || [])
  ];
  if (sig) {
    fields.push(formatNumber(sig.yParity, "yParity"));
    fields.push(toBeArray(sig.r));
    fields.push(toBeArray(sig.s));
  }
  return concat(["0x04", encodeRlp(fields)]);
}
var Transaction = class _Transaction {
  #type;
  #to;
  #data;
  #nonce;
  #gasLimit;
  #gasPrice;
  #maxPriorityFeePerGas;
  #maxFeePerGas;
  #value;
  #chainId;
  #sig;
  #accessList;
  #maxFeePerBlobGas;
  #blobVersionedHashes;
  #kzg;
  #blobs;
  #auths;
  #blobWrapperVersion;
  /**
   *  The transaction type.
   *
   *  If null, the type will be automatically inferred based on
   *  explicit properties.
   */
  get type() {
    return this.#type;
  }
  set type(value) {
    switch (value) {
      case null:
        this.#type = null;
        break;
      case 0:
      case "legacy":
        this.#type = 0;
        break;
      case 1:
      case "berlin":
      case "eip-2930":
        this.#type = 1;
        break;
      case 2:
      case "london":
      case "eip-1559":
        this.#type = 2;
        break;
      case 3:
      case "cancun":
      case "eip-4844":
        this.#type = 3;
        break;
      case 4:
      case "pectra":
      case "eip-7702":
        this.#type = 4;
        break;
      default:
        assertArgument(false, "unsupported transaction type", "type", value);
    }
  }
  /**
   *  The name of the transaction type.
   */
  get typeName() {
    switch (this.type) {
      case 0:
        return "legacy";
      case 1:
        return "eip-2930";
      case 2:
        return "eip-1559";
      case 3:
        return "eip-4844";
      case 4:
        return "eip-7702";
    }
    return null;
  }
  /**
   *  The ``to`` address for the transaction or ``null`` if the
   *  transaction is an ``init`` transaction.
   */
  get to() {
    const value = this.#to;
    if (value == null && this.type === 3) {
      return ZeroAddress;
    }
    return value;
  }
  set to(value) {
    this.#to = value == null ? null : getAddress(value);
  }
  /**
   *  The transaction nonce.
   */
  get nonce() {
    return this.#nonce;
  }
  set nonce(value) {
    this.#nonce = getNumber(value, "value");
  }
  /**
   *  The gas limit.
   */
  get gasLimit() {
    return this.#gasLimit;
  }
  set gasLimit(value) {
    this.#gasLimit = getBigInt(value);
  }
  /**
   *  The gas price.
   *
   *  On legacy networks this defines the fee that will be paid. On
   *  EIP-1559 networks, this should be ``null``.
   */
  get gasPrice() {
    const value = this.#gasPrice;
    if (value == null && (this.type === 0 || this.type === 1)) {
      return BN_04;
    }
    return value;
  }
  set gasPrice(value) {
    this.#gasPrice = value == null ? null : getBigInt(value, "gasPrice");
  }
  /**
   *  The maximum priority fee per unit of gas to pay. On legacy
   *  networks this should be ``null``.
   */
  get maxPriorityFeePerGas() {
    const value = this.#maxPriorityFeePerGas;
    if (value == null) {
      if (this.type === 2 || this.type === 3) {
        return BN_04;
      }
      return null;
    }
    return value;
  }
  set maxPriorityFeePerGas(value) {
    this.#maxPriorityFeePerGas = value == null ? null : getBigInt(value, "maxPriorityFeePerGas");
  }
  /**
   *  The maximum total fee per unit of gas to pay. On legacy
   *  networks this should be ``null``.
   */
  get maxFeePerGas() {
    const value = this.#maxFeePerGas;
    if (value == null) {
      if (this.type === 2 || this.type === 3) {
        return BN_04;
      }
      return null;
    }
    return value;
  }
  set maxFeePerGas(value) {
    this.#maxFeePerGas = value == null ? null : getBigInt(value, "maxFeePerGas");
  }
  /**
   *  The transaction data. For ``init`` transactions this is the
   *  deployment code.
   */
  get data() {
    return this.#data;
  }
  set data(value) {
    this.#data = hexlify(value);
  }
  /**
   *  The amount of ether (in wei) to send in this transactions.
   */
  get value() {
    return this.#value;
  }
  set value(value) {
    this.#value = getBigInt(value, "value");
  }
  /**
   *  The chain ID this transaction is valid on.
   */
  get chainId() {
    return this.#chainId;
  }
  set chainId(value) {
    this.#chainId = getBigInt(value);
  }
  /**
   *  If signed, the signature for this transaction.
   */
  get signature() {
    return this.#sig || null;
  }
  set signature(value) {
    this.#sig = value == null ? null : Signature.from(value);
  }
  isValid() {
    const sig = this.signature;
    if (sig && !sig.isValid()) {
      return false;
    }
    const auths = this.authorizationList;
    if (auths) {
      for (const auth of auths) {
        if (!auth.signature.isValid()) {
          return false;
        }
      }
    }
    return true;
  }
  /**
   *  The access list.
   *
   *  An access list permits discounted (but pre-paid) access to
   *  bytecode and state variable access within contract execution.
   */
  get accessList() {
    const value = this.#accessList || null;
    if (value == null) {
      if (this.type === 1 || this.type === 2 || this.type === 3) {
        return [];
      }
      return null;
    }
    return value;
  }
  set accessList(value) {
    this.#accessList = value == null ? null : accessListify(value);
  }
  get authorizationList() {
    const value = this.#auths || null;
    if (value == null) {
      if (this.type === 4) {
        return [];
      }
    }
    return value;
  }
  set authorizationList(auths) {
    this.#auths = auths == null ? null : auths.map((a) => authorizationify(a));
  }
  /**
   *  The max fee per blob gas for Cancun transactions.
   */
  get maxFeePerBlobGas() {
    const value = this.#maxFeePerBlobGas;
    if (value == null && this.type === 3) {
      return BN_04;
    }
    return value;
  }
  set maxFeePerBlobGas(value) {
    this.#maxFeePerBlobGas = value == null ? null : getBigInt(value, "maxFeePerBlobGas");
  }
  /**
   *  The BLOb versioned hashes for Cancun transactions.
   */
  get blobVersionedHashes() {
    let value = this.#blobVersionedHashes;
    if (value == null && this.type === 3) {
      return [];
    }
    return value;
  }
  set blobVersionedHashes(value) {
    if (value != null) {
      assertArgument(Array.isArray(value), "blobVersionedHashes must be an Array", "value", value);
      value = value.slice();
      for (let i = 0; i < value.length; i++) {
        assertArgument(isHexString(value[i], 32), "invalid blobVersionedHash", `value[${i}]`, value[i]);
      }
    }
    this.#blobVersionedHashes = value;
  }
  /**
   *  The BLObs for the Transaction, if any.
   *
   *  If ``blobs`` is non-``null``, then the [[seriailized]]
   *  will return the network formatted sidecar, otherwise it
   *  will return the standard [[link-eip-2718]] payload. The
   *  [[unsignedSerialized]] is unaffected regardless.
   *
   *  When setting ``blobs``, either fully valid [[Blob]] objects
   *  may be specified (i.e. correctly padded, with correct
   *  committments and proofs) or a raw [[BytesLike]] may
   *  be provided.
   *
   *  If raw [[BytesLike]] are provided, the [[kzg]] property **must**
   *  be already set. The blob will be correctly padded and the
   *  [[KzgLibrary]] will be used to compute the committment and
   *  proof for the blob.
   *
   *  A BLOb is a sequence of field elements, each of which must
   *  be within the BLS field modulo, so some additional processing
   *  may be required to encode arbitrary data to ensure each 32 byte
   *  field is within the valid range.
   *
   *  Setting this automatically populates [[blobVersionedHashes]],
   *  overwriting any existing values. Setting this to ``null``
   *  does **not** remove the [[blobVersionedHashes]], leaving them
   *  present.
   */
  get blobs() {
    if (this.#blobs == null) {
      return null;
    }
    return this.#blobs.map((b) => Object.assign({}, b));
  }
  set blobs(_blobs) {
    if (_blobs == null) {
      this.#blobs = null;
      return;
    }
    const blobs = [];
    const versionedHashes = [];
    for (let i = 0; i < _blobs.length; i++) {
      const blob = _blobs[i];
      if (isBytesLike(blob)) {
        assert(this.#kzg, "adding a raw blob requires a KZG library", "UNSUPPORTED_OPERATION", {
          operation: "set blobs()"
        });
        let data = getBytes(blob);
        assertArgument(data.length <= BLOB_SIZE, "blob is too large", `blobs[${i}]`, blob);
        if (data.length !== BLOB_SIZE) {
          const padded = new Uint8Array(BLOB_SIZE);
          padded.set(data);
          data = padded;
        }
        const commit = this.#kzg.blobToKzgCommitment(data);
        const proof = hexlify(this.#kzg.computeBlobKzgProof(data, commit));
        blobs.push({
          data: hexlify(data),
          commitment: hexlify(commit),
          proof
        });
        versionedHashes.push(getVersionedHash(1, commit));
      } else {
        const data = hexlify(blob.data);
        const commitment = hexlify(blob.commitment);
        const proof = hexlify(blob.proof);
        blobs.push({ data, commitment, proof });
        versionedHashes.push(getVersionedHash(1, commitment));
      }
    }
    this.#blobs = blobs;
    this.#blobVersionedHashes = versionedHashes;
  }
  get kzg() {
    return this.#kzg;
  }
  set kzg(kzg) {
    if (kzg == null) {
      this.#kzg = null;
    } else {
      this.#kzg = getKzgLibrary(kzg);
    }
  }
  get blobWrapperVersion() {
    return this.#blobWrapperVersion;
  }
  set blobWrapperVersion(value) {
    this.#blobWrapperVersion = value;
  }
  /**
   *  Creates a new Transaction with default values.
   */
  constructor() {
    this.#type = null;
    this.#to = null;
    this.#nonce = 0;
    this.#gasLimit = BN_04;
    this.#gasPrice = null;
    this.#maxPriorityFeePerGas = null;
    this.#maxFeePerGas = null;
    this.#data = "0x";
    this.#value = BN_04;
    this.#chainId = BN_04;
    this.#sig = null;
    this.#accessList = null;
    this.#maxFeePerBlobGas = null;
    this.#blobVersionedHashes = null;
    this.#kzg = null;
    this.#blobs = null;
    this.#auths = null;
    this.#blobWrapperVersion = null;
  }
  /**
   *  The transaction hash, if signed. Otherwise, ``null``.
   */
  get hash() {
    if (this.signature == null) {
      return null;
    }
    return keccak256(this.#getSerialized(true, false));
  }
  /**
   *  The pre-image hash of this transaction.
   *
   *  This is the digest that a [[Signer]] must sign to authorize
   *  this transaction.
   */
  get unsignedHash() {
    return keccak256(this.unsignedSerialized);
  }
  /**
   *  The sending address, if signed. Otherwise, ``null``.
   */
  get from() {
    if (this.signature == null) {
      return null;
    }
    return recoverAddress(this.unsignedHash, this.signature.getCanonical());
  }
  /**
   *  The public key of the sender, if signed. Otherwise, ``null``.
   */
  get fromPublicKey() {
    if (this.signature == null) {
      return null;
    }
    return SigningKey.recoverPublicKey(this.unsignedHash, this.signature.getCanonical());
  }
  /**
   *  Returns true if signed.
   *
   *  This provides a Type Guard that properties requiring a signed
   *  transaction are non-null.
   */
  isSigned() {
    return this.signature != null;
  }
  #getSerialized(signed, sidecar) {
    assert(!signed || this.signature != null, "cannot serialize unsigned transaction; maybe you meant .unsignedSerialized", "UNSUPPORTED_OPERATION", { operation: ".serialized" });
    const sig = signed ? this.signature : null;
    switch (this.inferType()) {
      case 0:
        return _serializeLegacy(this, sig);
      case 1:
        return _serializeEip2930(this, sig);
      case 2:
        return _serializeEip1559(this, sig);
      case 3:
        return _serializeEip4844(this, sig, sidecar ? this.blobs : null);
      case 4:
        return _serializeEip7702(this, sig);
    }
    assert(false, "unsupported transaction type", "UNSUPPORTED_OPERATION", { operation: ".serialized" });
  }
  /**
   *  The serialized transaction.
   *
   *  This throws if the transaction is unsigned. For the pre-image,
   *  use [[unsignedSerialized]].
   */
  get serialized() {
    return this.#getSerialized(true, true);
  }
  /**
   *  The transaction pre-image.
   *
   *  The hash of this is the digest which needs to be signed to
   *  authorize this transaction.
   */
  get unsignedSerialized() {
    return this.#getSerialized(false, false);
  }
  /**
   *  Return the most "likely" type; currently the highest
   *  supported transaction type.
   */
  inferType() {
    const types = this.inferTypes();
    if (types.indexOf(2) >= 0) {
      return 2;
    }
    return types.pop();
  }
  /**
   *  Validates the explicit properties and returns a list of compatible
   *  transaction types.
   */
  inferTypes() {
    const hasGasPrice = this.gasPrice != null;
    const hasFee = this.maxFeePerGas != null || this.maxPriorityFeePerGas != null;
    const hasAccessList = this.accessList != null;
    const hasBlob = this.#maxFeePerBlobGas != null || this.#blobVersionedHashes;
    if (this.maxFeePerGas != null && this.maxPriorityFeePerGas != null) {
      assert(this.maxFeePerGas >= this.maxPriorityFeePerGas, "priorityFee cannot be more than maxFee", "BAD_DATA", { value: this });
    }
    assert(!hasFee || this.type !== 0 && this.type !== 1, "transaction type cannot have maxFeePerGas or maxPriorityFeePerGas", "BAD_DATA", { value: this });
    assert(this.type !== 0 || !hasAccessList, "legacy transaction cannot have accessList", "BAD_DATA", { value: this });
    const types = [];
    if (this.type != null) {
      types.push(this.type);
    } else {
      if (this.authorizationList && this.authorizationList.length) {
        types.push(4);
      } else if (hasFee) {
        types.push(2);
      } else if (hasGasPrice) {
        types.push(1);
        if (!hasAccessList) {
          types.push(0);
        }
      } else if (hasAccessList) {
        types.push(1);
        types.push(2);
      } else if (hasBlob && this.to) {
        types.push(3);
      } else {
        types.push(0);
        types.push(1);
        types.push(2);
        types.push(3);
      }
    }
    types.sort();
    return types;
  }
  /**
   *  Returns true if this transaction is a legacy transaction (i.e.
   *  ``type === 0``).
   *
   *  This provides a Type Guard that the related properties are
   *  non-null.
   */
  isLegacy() {
    return this.type === 0;
  }
  /**
   *  Returns true if this transaction is berlin hardform transaction (i.e.
   *  ``type === 1``).
   *
   *  This provides a Type Guard that the related properties are
   *  non-null.
   */
  isBerlin() {
    return this.type === 1;
  }
  /**
   *  Returns true if this transaction is london hardform transaction (i.e.
   *  ``type === 2``).
   *
   *  This provides a Type Guard that the related properties are
   *  non-null.
   */
  isLondon() {
    return this.type === 2;
  }
  /**
   *  Returns true if this transaction is an [[link-eip-4844]] BLOB
   *  transaction.
   *
   *  This provides a Type Guard that the related properties are
   *  non-null.
   */
  isCancun() {
    return this.type === 3;
  }
  /**
   *  Create a copy of this transaciton.
   */
  clone() {
    return _Transaction.from(this);
  }
  /**
   *  Return a JSON-friendly object.
   */
  toJSON() {
    const s = (v) => {
      if (v == null) {
        return null;
      }
      return v.toString();
    };
    return {
      type: this.type,
      to: this.to,
      //            from: this.from,
      data: this.data,
      nonce: this.nonce,
      gasLimit: s(this.gasLimit),
      gasPrice: s(this.gasPrice),
      maxPriorityFeePerGas: s(this.maxPriorityFeePerGas),
      maxFeePerGas: s(this.maxFeePerGas),
      value: s(this.value),
      chainId: s(this.chainId),
      sig: this.signature ? this.signature.toJSON() : null,
      accessList: this.accessList
    };
  }
  [inspect2]() {
    return this.toString();
  }
  toString() {
    const output2 = [];
    const add = (key) => {
      let value = this[key];
      if (typeof value === "string") {
        value = JSON.stringify(value);
      }
      output2.push(`${key}: ${value}`);
    };
    if (this.type) {
      add("type");
    }
    add("to");
    add("data");
    add("nonce");
    add("gasLimit");
    add("value");
    if (this.chainId != null) {
      add("chainId");
    }
    if (this.signature) {
      add("from");
      output2.push(`signature: ${this.signature.toString()}`);
    }
    const auths = this.authorizationList;
    if (auths) {
      const outputAuths = [];
      for (const auth of auths) {
        const o = [];
        o.push(`address: ${JSON.stringify(auth.address)}`);
        if (auth.nonce != null) {
          o.push(`nonce: ${auth.nonce}`);
        }
        if (auth.chainId != null) {
          o.push(`chainId: ${auth.chainId}`);
        }
        if (auth.signature) {
          o.push(`signature: ${auth.signature.toString()}`);
        }
        outputAuths.push(`Authorization { ${o.join(", ")} }`);
      }
      output2.push(`authorizations: [ ${outputAuths.join(", ")} ]`);
    }
    return `Transaction { ${output2.join(", ")} }`;
  }
  /**
   *  Create a **Transaction** from a serialized transaction or a
   *  Transaction-like object.
   */
  static from(tx) {
    if (tx == null) {
      return new _Transaction();
    }
    if (typeof tx === "string") {
      const payload = getBytes(tx);
      if (payload[0] >= 127) {
        return _Transaction.from(_parseLegacy(payload));
      }
      switch (payload[0]) {
        case 1:
          return _Transaction.from(_parseEip2930(payload));
        case 2:
          return _Transaction.from(_parseEip1559(payload));
        case 3:
          return _Transaction.from(_parseEip4844(payload));
        case 4:
          return _Transaction.from(_parseEip7702(payload));
      }
      assert(false, "unsupported transaction type", "UNSUPPORTED_OPERATION", { operation: "from" });
    }
    const result = new _Transaction();
    if (tx.type != null) {
      result.type = tx.type;
    }
    if (tx.to != null) {
      result.to = tx.to;
    }
    if (tx.nonce != null) {
      result.nonce = tx.nonce;
    }
    if (tx.gasLimit != null) {
      result.gasLimit = tx.gasLimit;
    }
    if (tx.gasPrice != null) {
      result.gasPrice = tx.gasPrice;
    }
    if (tx.maxPriorityFeePerGas != null) {
      result.maxPriorityFeePerGas = tx.maxPriorityFeePerGas;
    }
    if (tx.maxFeePerGas != null) {
      result.maxFeePerGas = tx.maxFeePerGas;
    }
    if (tx.maxFeePerBlobGas != null) {
      result.maxFeePerBlobGas = tx.maxFeePerBlobGas;
    }
    if (tx.data != null) {
      result.data = tx.data;
    }
    if (tx.value != null) {
      result.value = tx.value;
    }
    if (tx.chainId != null) {
      result.chainId = tx.chainId;
    }
    if (tx.signature != null) {
      result.signature = Signature.from(tx.signature);
    }
    if (tx.accessList != null) {
      result.accessList = tx.accessList;
    }
    if (tx.authorizationList != null) {
      result.authorizationList = tx.authorizationList;
    }
    if (tx.blobVersionedHashes != null) {
      result.blobVersionedHashes = tx.blobVersionedHashes;
    }
    if (tx.kzg != null) {
      result.kzg = tx.kzg;
    }
    if (tx.blobWrapperVersion != null) {
      result.blobWrapperVersion = tx.blobWrapperVersion;
    }
    if (tx.blobs != null) {
      result.blobs = tx.blobs;
    }
    if (tx.hash != null) {
      assertArgument(result.isSigned(), "unsigned transaction cannot define '.hash'", "tx", tx);
      assertArgument(result.hash === tx.hash, "hash mismatch", "tx", tx);
    }
    if (tx.from != null) {
      assertArgument(result.isSigned(), "unsigned transaction cannot define '.from'", "tx", tx);
      assertArgument(result.from.toLowerCase() === (tx.from || "").toLowerCase(), "from mismatch", "tx", tx);
    }
    return result;
  }
};

// dashboard/assets/vendor-noble.mjs
var pe = BigInt(4294967295);
var Un = BigInt(32);
function io(t3, e = false) {
  return e ? { h: Number(t3 & pe), l: Number(t3 >> Un & pe) } : { h: Number(t3 >> Un & pe) | 0, l: Number(t3 & pe) | 0 };
}
function Rn(t3, e = false) {
  let r = t3.length, n = new Uint32Array(r), s = new Uint32Array(r);
  for (let o = 0; o < r; o++) {
    let { h: i, l: c } = io(t3[o], e);
    [n[o], s[o]] = [i, c];
  }
  return [n, s];
}
function Nn(t3) {
  return t3 instanceof Uint8Array || ArrayBuffer.isView(t3) && t3.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in t3 && t3.BYTES_PER_ELEMENT === 1;
}
var xe = (t3) => t3 ? `"${t3}" ` : "";
function Lt(t3, e = "") {
  if (typeof t3 != "number") throw new TypeError(xe(e) + "expected number, got " + typeof t3);
  if (!Number.isSafeInteger(t3) || t3 < 0) throw new RangeError(xe(e) + "expected integer >= 0, got " + t3);
  return t3;
}
function Cn(t3, e = "") {
  if (typeof t3 != "boolean") throw new TypeError(xe(e) + "expected boolean, got type=" + typeof t3);
  return t3;
}
function be(t3, e, r = "") {
  if (Nn(t3) && (e === void 0 || t3.length === e)) return t3;
  e !== void 0 && Lt(e, "length");
  let n = Nn(t3), s = e !== void 0 ? ` of length ${e}` : "", o = n ? `length=${t3.length}` : `type=${typeof t3}`, i = xe(r) + "expected Uint8Array" + s + ", got " + o;
  throw n ? new RangeError(i) : new TypeError(i);
}
var co = (t3, e) => {
  if (t3 === null || typeof t3 != "object" || Array.isArray(t3)) throw new TypeError((e === "object" ? "" : `"${e}" `) + "expected object, got type=" + typeof t3);
};
var Mn = (t3, e) => {
  co(t3, e);
  let r = Object.getPrototypeOf(t3);
  if (r !== Object.prototype && r !== null) throw new TypeError(`"${e}" expected plain object`);
  if (Object.hasOwn(t3, "__proto__")) throw new TypeError(`"${e}.__proto__" is not allowed`);
};
function Ce(t3, e = true) {
  if (t3.destroyed) throw new Error("hash was destroyed");
  if (e && t3.finished) throw new Error("digest() was already called");
}
function qn(t3, e) {
  be(t3, void 0, "output");
  let r = e.outputLen;
  if (!(t3.length >= r)) throw new RangeError('"output" expected length >= ' + r);
}
function qe(t3) {
  return new Uint32Array(t3.buffer, t3.byteOffset, Math.floor(t3.byteLength / 4));
}
function je(...t3) {
  for (let e = 0; e < t3.length; e++) t3[e].fill(0);
}
var fo = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
function ao(t3) {
  return t3 << 24 & 4278190080 | t3 << 8 & 16711680 | t3 >>> 8 & 65280 | t3 >>> 24 & 255;
}
function uo(t3) {
  for (let e = 0; e < t3.length; e++) t3[e] = ao(t3[e]);
  return t3;
}
var Ve = fo ? (t3) => t3 : uo;
function jn(t3, e, r = "opts") {
  return Mn(t3, "defaults"), e !== void 0 && Mn(e, r), Object.assign(/* @__PURE__ */ Object.create(null), t3, e);
}
function Vn(t3, e = {}) {
  if (typeof t3 != "function") throw new TypeError('"hashCons" expected function, got type=' + typeof t3);
  e = jn({}, e, "info");
  let r = (s, o) => t3(o).update(s).digest(), n = t3(void 0);
  return r.outputLen = n.outputLen, r.blockLen = n.blockLen, r.canXOF = n.canXOF, r.create = (s) => t3(s), Object.assign(r, e), Object.freeze(r);
}
var lo = BigInt(0);
var ee = BigInt(1);
var ho = BigInt(2);
var po = BigInt(7);
var xo = BigInt(256);
var bo = BigInt(113);
var Zn = [];
var Pn = [];
var Gn = [];
for (let t3 = 0, e = ee, r = 1, n = 0; t3 < 24; t3++) {
  [r, n] = [n, (2 * r + 3 * n) % 5], Zn.push(2 * (5 * n + r)), Pn.push((t3 + 1) * (t3 + 2) / 2 % 64);
  let s = lo;
  for (let o = 0; o < 7; o++) e = (e << ee ^ (e >> po) * bo) % xo, e & ho && (s ^= ee << (ee << BigInt(o)) - ee);
  Gn.push(s);
}
var $n = Rn(Gn, true);
var go = $n[0];
var yo = $n[1];
var wo = (t3, e, r) => t3 << r | e >>> 32 - r;
var mo = (t3, e, r) => e << r | t3 >>> 32 - r;
var Eo = (t3, e, r) => e << r - 32 | t3 >>> 64 - r;
var Bo = (t3, e, r) => t3 << r - 32 | e >>> 64 - r;
var Dn = (t3, e, r) => r > 32 ? Eo(t3, e, r) : wo(t3, e, r);
var Kn = (t3, e, r) => r > 32 ? Bo(t3, e, r) : mo(t3, e, r);
var $t = new Uint32Array(10);
function Ao(t3, e = 24) {
  if (!(t3 instanceof Uint32Array)) throw new TypeError('"s" expected Uint32Array(50), got type=' + typeof t3);
  if (t3.length !== 50) throw new RangeError('"s" expected Uint32Array(50), got length=' + t3.length);
  if (Lt(e, "rounds"), e < 1 || e > 24) throw new Error('"rounds" expected integer 1..24');
  for (let r = 24 - e; r < 24; r++) {
    for (let o = 0; o < 10; o++) $t[o] = t3[o] ^ t3[o + 10] ^ t3[o + 20] ^ t3[o + 30] ^ t3[o + 40];
    for (let o = 0; o < 10; o += 2) {
      let i = (o + 8) % 10, c = (o + 2) % 10, f = $t[c], u = $t[c + 1], p = Dn(f, u, 1) ^ $t[i], g = Kn(f, u, 1) ^ $t[i + 1];
      for (let a = 0; a < 50; a += 10) t3[o + a] ^= p, t3[o + a + 1] ^= g;
    }
    let n = t3[2], s = t3[3];
    for (let o = 0; o < 24; o++) {
      let i = Pn[o], c = Dn(n, s, i), f = Kn(n, s, i), u = Zn[o];
      n = t3[u], s = t3[u + 1], t3[u] = c, t3[u + 1] = f;
    }
    for (let o = 0; o < 50; o += 10) {
      let i = t3[o], c = t3[o + 1], f = t3[o + 2], u = t3[o + 3];
      t3[o] ^= ~t3[o + 2] & t3[o + 4], t3[o + 1] ^= ~t3[o + 3] & t3[o + 5], t3[o + 2] ^= ~t3[o + 4] & t3[o + 6], t3[o + 3] ^= ~t3[o + 5] & t3[o + 7], t3[o + 4] ^= ~t3[o + 6] & t3[o + 8], t3[o + 5] ^= ~t3[o + 7] & t3[o + 9], t3[o + 6] ^= ~t3[o + 8] & i, t3[o + 7] ^= ~t3[o + 9] & c, t3[o + 8] ^= ~i & f, t3[o + 9] ^= ~c & u;
    }
    t3[0] ^= go[r], t3[1] ^= yo[r];
  }
  je($t);
}
var De = class t {
  state;
  pos = 0;
  posOut = 0;
  finished = false;
  state32;
  destroyed = false;
  blockLen;
  suffix;
  outputLen;
  canXOF;
  enableXOF = false;
  rounds;
  constructor(e, r, n, s = false, o = 24) {
    if (Lt(e, "blockLen"), Lt(r, "suffix"), Lt(o, "rounds"), Cn(s, "enableXOF"), this.blockLen = e, this.suffix = r, this.outputLen = n, this.enableXOF = s, this.canXOF = s, this.rounds = o, Lt(n, "outputLen"), !(0 < e && e < 200)) throw new Error('"blockLen" must be 1..199');
    this.state = new Uint8Array(200), this.state32 = qe(this.state);
  }
  clone() {
    return this._cloneInto();
  }
  keccak() {
    Ve(this.state32), Ao(this.state32, this.rounds), Ve(this.state32), this.posOut = 0, this.pos = 0;
  }
  update(e) {
    Ce(this), be(e);
    let { blockLen: r, state: n, state32: s } = this, o = e.length, i = r % 4 === 0 && e.byteOffset % 4 === 0, c = r / 4, f = i && o >= r ? qe(e) : void 0;
    for (let u = 0; u < o; ) {
      if (f !== void 0 && this.pos === 0 && u % 4 === 0 && o - u >= r) {
        for (let g = 0, a = u / 4; g < c; g++) s[g] ^= f[a + g];
        u += r, this.pos = r, this.keccak();
        continue;
      }
      let p = Math.min(r - this.pos, o - u);
      for (let g = 0; g < p; g++) n[this.pos++] ^= e[u++];
      this.pos === r && this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished) return;
    this.finished = true;
    let { state: e, suffix: r, pos: n, blockLen: s } = this;
    e[n] ^= r, (r & 128) !== 0 && n === s - 1 && this.keccak(), e[s - 1] ^= 128, this.keccak();
  }
  writeInto(e) {
    Ce(this, false), be(e), this.finish();
    let r = this.state, { blockLen: n } = this;
    for (let s = 0, o = e.length; s < o; ) {
      this.posOut >= n && this.keccak();
      let i = Math.min(n - this.posOut, o - s);
      e.set(r.subarray(this.posOut, this.posOut + i), s), this.posOut += i, s += i;
    }
    return e;
  }
  xofInto(e) {
    if (!this.enableXOF) throw new Error("XOF is not enabled");
    return this.writeInto(e);
  }
  xof(e) {
    return Lt(e), this.xofInto(new Uint8Array(e));
  }
  digestInto(e) {
    if (qn(e, this), this.finished) throw new Error("digest() was already called");
    this.writeInto(e.length === this.outputLen ? e : e.subarray(0, this.outputLen)), this.destroy();
  }
  digest() {
    let e = new Uint8Array(this.outputLen);
    return this.digestInto(e), e;
  }
  destroy() {
    this.destroyed = true, je(this.state);
  }
  _cloneInto(e) {
    let { blockLen: r, suffix: n, outputLen: s, rounds: o, enableXOF: i } = this;
    return e ||= new t(r, n, s, i, o), e.blockLen = r, e.state32.set(this.state32), e.pos = this.pos, e.posOut = this.posOut, e.finished = this.finished, e.rounds = o, e.suffix = n, e.outputLen = s, e.enableXOF = i, e.canXOF = this.canXOF, e.destroyed = this.destroyed, e;
  }
};
var _o = (t3, e, r, n = {}) => Vn(() => new De(e, t3, r), n);
var So = _o(1, 136, 32);
var Mt = typeof globalThis == "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
function Ct(t3) {
  return t3 instanceof Uint8Array || ArrayBuffer.isView(t3) && t3.constructor.name === "Uint8Array";
}
function ne(t3) {
  if (!Number.isSafeInteger(t3) || t3 < 0) throw new Error("positive integer expected, got " + t3);
}
function pt(t3, ...e) {
  if (!Ct(t3)) throw new Error("Uint8Array expected");
  if (e.length > 0 && !e.includes(t3.length)) throw new Error("Uint8Array expected of length " + e + ", got length=" + t3.length);
}
function ge(t3) {
  if (typeof t3 != "function" || typeof t3.create != "function") throw new Error("Hash should be wrapped by utils.createHasher");
  ne(t3.outputLen), ne(t3.blockLen);
}
function Yt(t3, e = true) {
  if (t3.destroyed) throw new Error("Hash instance has been destroyed");
  if (e && t3.finished) throw new Error("Hash#digest() has already been called");
}
function Yn(t3, e) {
  pt(t3);
  let r = e.outputLen;
  if (t3.length < r) throw new Error("digestInto() expects output buffer of length at least " + r);
}
function qt(...t3) {
  for (let e = 0; e < t3.length; e++) t3[e].fill(0);
}
function ye(t3) {
  return new DataView(t3.buffer, t3.byteOffset, t3.byteLength);
}
function xt(t3, e) {
  return t3 << 32 - e | t3 >>> e;
}
var zn = typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function";
var vo = Array.from({ length: 256 }, (t3, e) => e.toString(16).padStart(2, "0"));
function At(t3) {
  if (pt(t3), zn) return t3.toHex();
  let e = "";
  for (let r = 0; r < t3.length; r++) e += vo[t3[r]];
  return e;
}
var Bt = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
function Xn(t3) {
  if (t3 >= Bt._0 && t3 <= Bt._9) return t3 - Bt._0;
  if (t3 >= Bt.A && t3 <= Bt.F) return t3 - (Bt.A - 10);
  if (t3 >= Bt.a && t3 <= Bt.f) return t3 - (Bt.a - 10);
}
function jt(t3) {
  if (typeof t3 != "string") throw new Error("hex string expected, got " + typeof t3);
  if (zn) return Uint8Array.fromHex(t3);
  let e = t3.length, r = e / 2;
  if (e % 2) throw new Error("hex string expected, got unpadded hex of length " + e);
  let n = new Uint8Array(r);
  for (let s = 0, o = 0; s < r; s++, o += 2) {
    let i = Xn(t3.charCodeAt(o)), c = Xn(t3.charCodeAt(o + 1));
    if (i === void 0 || c === void 0) {
      let f = t3[o] + t3[o + 1];
      throw new Error('hex string expected, got non-hex character "' + f + '" at index ' + o);
    }
    n[s] = i * 16 + c;
  }
  return n;
}
function Wn(t3) {
  if (typeof t3 != "string") throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(t3));
}
function re(t3) {
  return typeof t3 == "string" && (t3 = Wn(t3)), pt(t3), t3;
}
function bt(...t3) {
  let e = 0;
  for (let n = 0; n < t3.length; n++) {
    let s = t3[n];
    pt(s), e += s.length;
  }
  let r = new Uint8Array(e);
  for (let n = 0, s = 0; n < t3.length; n++) {
    let o = t3[n];
    r.set(o, s), s += o.length;
  }
  return r;
}
var Xt = class {
};
function Fn(t3) {
  let e = (n) => t3().update(re(n)).digest(), r = t3();
  return e.outputLen = r.outputLen, e.blockLen = r.blockLen, e.create = () => t3(), e;
}
function we(t3 = 32) {
  if (Mt && typeof Mt.getRandomValues == "function") return Mt.getRandomValues(new Uint8Array(t3));
  if (Mt && typeof Mt.randomBytes == "function") return Uint8Array.from(Mt.randomBytes(t3));
  throw new Error("crypto.getRandomValues must be defined");
}
function Io(t3, e, r, n) {
  if (typeof t3.setBigUint64 == "function") return t3.setBigUint64(e, r, n);
  let s = BigInt(32), o = BigInt(4294967295), i = Number(r >> s & o), c = Number(r & o), f = n ? 4 : 0, u = n ? 0 : 4;
  t3.setUint32(e + f, i, n), t3.setUint32(e + u, c, n);
}
function Qn(t3, e, r) {
  return t3 & e ^ ~t3 & r;
}
function Jn(t3, e, r) {
  return t3 & e ^ t3 & r ^ e & r;
}
var me = class extends Xt {
  constructor(e, r, n, s) {
    super(), this.finished = false, this.length = 0, this.pos = 0, this.destroyed = false, this.blockLen = e, this.outputLen = r, this.padOffset = n, this.isLE = s, this.buffer = new Uint8Array(e), this.view = ye(this.buffer);
  }
  update(e) {
    Yt(this), e = re(e), pt(e);
    let { view: r, buffer: n, blockLen: s } = this, o = e.length;
    for (let i = 0; i < o; ) {
      let c = Math.min(s - this.pos, o - i);
      if (c === s) {
        let f = ye(e);
        for (; s <= o - i; i += s) this.process(f, i);
        continue;
      }
      n.set(e.subarray(i, i + c), this.pos), this.pos += c, i += c, this.pos === s && (this.process(r, 0), this.pos = 0);
    }
    return this.length += e.length, this.roundClean(), this;
  }
  digestInto(e) {
    Yt(this), Yn(e, this), this.finished = true;
    let { buffer: r, view: n, blockLen: s, isLE: o } = this, { pos: i } = this;
    r[i++] = 128, qt(this.buffer.subarray(i)), this.padOffset > s - i && (this.process(n, 0), i = 0);
    for (let g = i; g < s; g++) r[g] = 0;
    Io(n, s - 8, BigInt(this.length * 8), o), this.process(n, 0);
    let c = ye(e), f = this.outputLen;
    if (f % 4) throw new Error("_sha2: outputLen should be aligned to 32bit");
    let u = f / 4, p = this.get();
    if (u > p.length) throw new Error("_sha2: outputLen bigger than state");
    for (let g = 0; g < u; g++) c.setUint32(4 * g, p[g], o);
  }
  digest() {
    let { buffer: e, outputLen: r } = this;
    this.digestInto(e);
    let n = e.slice(0, r);
    return this.destroy(), n;
  }
  _cloneInto(e) {
    e || (e = new this.constructor()), e.set(...this.get());
    let { blockLen: r, buffer: n, length: s, finished: o, destroyed: i, pos: c } = this;
    return e.destroyed = i, e.finished = o, e.length = s, e.pos = c, s % r && e.buffer.set(n), e;
  }
  clone() {
    return this._cloneInto();
  }
};
var _t = Uint32Array.from([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
var Lo = Uint32Array.from([1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]);
var Ot = new Uint32Array(64);
var Ke = class extends me {
  constructor(e = 32) {
    super(64, e, 8, false), this.A = _t[0] | 0, this.B = _t[1] | 0, this.C = _t[2] | 0, this.D = _t[3] | 0, this.E = _t[4] | 0, this.F = _t[5] | 0, this.G = _t[6] | 0, this.H = _t[7] | 0;
  }
  get() {
    let { A: e, B: r, C: n, D: s, E: o, F: i, G: c, H: f } = this;
    return [e, r, n, s, o, i, c, f];
  }
  set(e, r, n, s, o, i, c, f) {
    this.A = e | 0, this.B = r | 0, this.C = n | 0, this.D = s | 0, this.E = o | 0, this.F = i | 0, this.G = c | 0, this.H = f | 0;
  }
  process(e, r) {
    for (let g = 0; g < 16; g++, r += 4) Ot[g] = e.getUint32(r, false);
    for (let g = 16; g < 64; g++) {
      let a = Ot[g - 15], l = Ot[g - 2], B = xt(a, 7) ^ xt(a, 18) ^ a >>> 3, S = xt(l, 17) ^ xt(l, 19) ^ l >>> 10;
      Ot[g] = S + Ot[g - 7] + B + Ot[g - 16] | 0;
    }
    let { A: n, B: s, C: o, D: i, E: c, F: f, G: u, H: p } = this;
    for (let g = 0; g < 64; g++) {
      let a = xt(c, 6) ^ xt(c, 11) ^ xt(c, 25), l = p + a + Qn(c, f, u) + Lo[g] + Ot[g] | 0, S = (xt(n, 2) ^ xt(n, 13) ^ xt(n, 22)) + Jn(n, s, o) | 0;
      p = u, u = f, f = c, c = i + l | 0, i = o, o = s, s = n, n = l + S | 0;
    }
    n = n + this.A | 0, s = s + this.B | 0, o = o + this.C | 0, i = i + this.D | 0, c = c + this.E | 0, f = f + this.F | 0, u = u + this.G | 0, p = p + this.H | 0, this.set(n, s, o, i, c, f, u, p);
  }
  roundClean() {
    qt(Ot);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0), qt(this.buffer);
  }
};
var tr = Fn(() => new Ke());
var Ee = class extends Xt {
  constructor(e, r) {
    super(), this.finished = false, this.destroyed = false, ge(e);
    let n = re(r);
    if (this.iHash = e.create(), typeof this.iHash.update != "function") throw new Error("Expected instance of class which extends utils.Hash");
    this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
    let s = this.blockLen, o = new Uint8Array(s);
    o.set(n.length > s ? e.create().update(n).digest() : n);
    for (let i = 0; i < o.length; i++) o[i] ^= 54;
    this.iHash.update(o), this.oHash = e.create();
    for (let i = 0; i < o.length; i++) o[i] ^= 106;
    this.oHash.update(o), qt(o);
  }
  update(e) {
    return Yt(this), this.iHash.update(e), this;
  }
  digestInto(e) {
    Yt(this), pt(e, this.outputLen), this.finished = true, this.iHash.digestInto(e), this.oHash.update(e), this.oHash.digestInto(e), this.destroy();
  }
  digest() {
    let e = new Uint8Array(this.oHash.outputLen);
    return this.digestInto(e), e;
  }
  _cloneInto(e) {
    e || (e = Object.create(Object.getPrototypeOf(this), {}));
    let { oHash: r, iHash: n, finished: s, destroyed: o, blockLen: i, outputLen: c } = this;
    return e = e, e.finished = s, e.destroyed = o, e.blockLen = i, e.outputLen = c, e.oHash = r._cloneInto(e.oHash), e.iHash = n._cloneInto(e.iHash), e;
  }
  clone() {
    return this._cloneInto();
  }
  destroy() {
    this.destroyed = true, this.oHash.destroy(), this.iHash.destroy();
  }
};
var Ze = (t3, e, r) => new Ee(t3, e).update(r).digest();
Ze.create = (t3, e) => new Ee(t3, e);
var $e = BigInt(0);
var Ge = BigInt(1);
function oe(t3, e = "") {
  if (typeof t3 != "boolean") {
    let r = e && `"${e}"`;
    throw new Error(r + "expected boolean, got type=" + typeof t3);
  }
  return t3;
}
function Tt(t3, e, r = "") {
  let n = Ct(t3), s = t3?.length, o = e !== void 0;
  if (!n || o && s !== e) {
    let i = r && `"${r}" `, c = o ? ` of length ${e}` : "", f = n ? `length=${s}` : `type=${typeof t3}`;
    throw new Error(i + "expected Uint8Array" + c + ", got " + f);
  }
  return t3;
}
function se(t3) {
  let e = t3.toString(16);
  return e.length & 1 ? "0" + e : e;
}
function er(t3) {
  if (typeof t3 != "string") throw new Error("hex string expected, got " + typeof t3);
  return t3 === "" ? $e : BigInt("0x" + t3);
}
function zt(t3) {
  return er(At(t3));
}
function Xe(t3) {
  return pt(t3), er(At(Uint8Array.from(t3).reverse()));
}
function Be(t3, e) {
  return jt(t3.toString(16).padStart(e * 2, "0"));
}
function Ye(t3, e) {
  return Be(t3, e).reverse();
}
function rt(t3, e, r) {
  let n;
  if (typeof e == "string") try {
    n = jt(e);
  } catch (o) {
    throw new Error(t3 + " must be hex string or Uint8Array, cause: " + o);
  }
  else if (Ct(e)) n = Uint8Array.from(e);
  else throw new Error(t3 + " must be hex string or Uint8Array");
  let s = n.length;
  if (typeof r == "number" && s !== r) throw new Error(t3 + " of length " + r + " expected, got " + s);
  return n;
}
var Pe = (t3) => typeof t3 == "bigint" && $e <= t3;
function nr(t3, e, r) {
  return Pe(t3) && Pe(e) && Pe(r) && e <= t3 && t3 < r;
}
function rr(t3, e, r, n) {
  if (!nr(e, r, n)) throw new Error("expected valid " + t3 + ": " + r + " <= n < " + n + ", got " + e);
}
function Ae(t3) {
  let e;
  for (e = 0; t3 > $e; t3 >>= Ge, e += 1) ;
  return e;
}
var Ht = (t3) => (Ge << BigInt(t3)) - Ge;
function or(t3, e, r) {
  if (typeof t3 != "number" || t3 < 2) throw new Error("hashLen must be a number");
  if (typeof e != "number" || e < 2) throw new Error("qByteLen must be a number");
  if (typeof r != "function") throw new Error("hmacFn must be a function");
  let n = (l) => new Uint8Array(l), s = (l) => Uint8Array.of(l), o = n(t3), i = n(t3), c = 0, f = () => {
    o.fill(1), i.fill(0), c = 0;
  }, u = (...l) => r(i, o, ...l), p = (l = n(0)) => {
    i = u(s(0), l), o = u(), l.length !== 0 && (i = u(s(1), l), o = u());
  }, g = () => {
    if (c++ >= 1e3) throw new Error("drbg: tried 1000 values");
    let l = 0, B = [];
    for (; l < e; ) {
      o = u();
      let S = o.slice();
      B.push(S), l += o.length;
    }
    return bt(...B);
  };
  return (l, B) => {
    f(), p(l);
    let S;
    for (; !(S = B(g())); ) p();
    return f(), S;
  };
}
function ie(t3, e, r = {}) {
  if (!t3 || typeof t3 != "object") throw new Error("expected valid options object");
  function n(s, o, i) {
    let c = t3[s];
    if (i && c === void 0) return;
    let f = typeof c;
    if (f !== o || c === null) throw new Error(`param "${s}" is invalid: expected ${o}, got ${f}`);
  }
  Object.entries(e).forEach(([s, o]) => n(s, o, false)), Object.entries(r).forEach(([s, o]) => n(s, o, true));
}
function ze(t3) {
  let e = /* @__PURE__ */ new WeakMap();
  return (r, ...n) => {
    let s = e.get(r);
    if (s !== void 0) return s;
    let o = t3(r, ...n);
    return e.set(r, o), o;
  };
}
var st = BigInt(0);
var ot = BigInt(1);
var Vt = BigInt(2);
var cr = BigInt(3);
var fr = BigInt(4);
var ar = BigInt(5);
var Oo = BigInt(7);
var ur = BigInt(8);
var To = BigInt(9);
var lr = BigInt(16);
function ht(t3, e) {
  let r = t3 % e;
  return r >= st ? r : e + r;
}
function ut(t3, e, r) {
  let n = t3;
  for (; e-- > st; ) n *= n, n %= r;
  return n;
}
function sr(t3, e) {
  if (t3 === st) throw new Error("invert: expected non-zero number");
  if (e <= st) throw new Error("invert: expected positive modulus, got " + e);
  let r = ht(t3, e), n = e, s = st, o = ot, i = ot, c = st;
  for (; r !== st; ) {
    let u = n / r, p = n % r, g = s - i * u, a = o - c * u;
    n = r, r = p, s = i, o = c, i = g, c = a;
  }
  if (n !== ot) throw new Error("invert: does not exist");
  return ht(s, e);
}
function We(t3, e, r) {
  if (!t3.eql(t3.sqr(e), r)) throw new Error("Cannot find square root");
}
function dr(t3, e) {
  let r = (t3.ORDER + ot) / fr, n = t3.pow(e, r);
  return We(t3, n, e), n;
}
function Ho(t3, e) {
  let r = (t3.ORDER - ar) / ur, n = t3.mul(e, Vt), s = t3.pow(n, r), o = t3.mul(e, s), i = t3.mul(t3.mul(o, Vt), s), c = t3.mul(o, t3.sub(i, t3.ONE));
  return We(t3, c, e), c;
}
function ko(t3) {
  let e = kt(t3), r = hr(t3), n = r(e, e.neg(e.ONE)), s = r(e, n), o = r(e, e.neg(n)), i = (t3 + Oo) / lr;
  return (c, f) => {
    let u = c.pow(f, i), p = c.mul(u, n), g = c.mul(u, s), a = c.mul(u, o), l = c.eql(c.sqr(p), f), B = c.eql(c.sqr(g), f);
    u = c.cmov(u, p, l), p = c.cmov(a, g, B);
    let S = c.eql(c.sqr(p), f), q = c.cmov(u, p, S);
    return We(c, q, f), q;
  };
}
function hr(t3) {
  if (t3 < cr) throw new Error("sqrt is not defined for small field");
  let e = t3 - ot, r = 0;
  for (; e % Vt === st; ) e /= Vt, r++;
  let n = Vt, s = kt(t3);
  for (; ir(s, n) === 1; ) if (n++ > 1e3) throw new Error("Cannot find square root: probably non-prime P");
  if (r === 1) return dr;
  let o = s.pow(n, e), i = (e + ot) / Vt;
  return function(f, u) {
    if (f.is0(u)) return u;
    if (ir(f, u) !== 1) throw new Error("Cannot find square root");
    let p = r, g = f.mul(f.ONE, o), a = f.pow(u, e), l = f.pow(u, i);
    for (; !f.eql(a, f.ONE); ) {
      if (f.is0(a)) return f.ZERO;
      let B = 1, S = f.sqr(a);
      for (; !f.eql(S, f.ONE); ) if (B++, S = f.sqr(S), B === p) throw new Error("Cannot find square root");
      let q = ot << BigInt(p - B - 1), V = f.pow(g, q);
      p = B, g = f.sqr(V), a = f.mul(a, g), l = f.mul(l, V);
    }
    return l;
  };
}
function Uo(t3) {
  return t3 % fr === cr ? dr : t3 % ur === ar ? Ho : t3 % lr === To ? ko(t3) : hr(t3);
}
var Ro = ["create", "isValid", "is0", "neg", "inv", "sqrt", "sqr", "eql", "add", "sub", "mul", "pow", "div", "addN", "subN", "mulN", "sqrN"];
function Fe(t3) {
  let e = { ORDER: "bigint", MASK: "bigint", BYTES: "number", BITS: "number" }, r = Ro.reduce((n, s) => (n[s] = "function", n), e);
  return ie(t3, r), t3;
}
function No(t3, e, r) {
  if (r < st) throw new Error("invalid exponent, negatives unsupported");
  if (r === st) return t3.ONE;
  if (r === ot) return e;
  let n = t3.ONE, s = e;
  for (; r > st; ) r & ot && (n = t3.mul(n, s)), s = t3.sqr(s), r >>= ot;
  return n;
}
function _e(t3, e, r = false) {
  let n = new Array(e.length).fill(r ? t3.ZERO : void 0), s = e.reduce((i, c, f) => t3.is0(c) ? i : (n[f] = i, t3.mul(i, c)), t3.ONE), o = t3.inv(s);
  return e.reduceRight((i, c, f) => t3.is0(c) ? i : (n[f] = t3.mul(i, n[f]), t3.mul(i, c)), o), n;
}
function ir(t3, e) {
  let r = (t3.ORDER - ot) / Vt, n = t3.pow(e, r), s = t3.eql(n, t3.ONE), o = t3.eql(n, t3.ZERO), i = t3.eql(n, t3.neg(t3.ONE));
  if (!s && !o && !i) throw new Error("invalid Legendre symbol result");
  return s ? 1 : o ? 0 : -1;
}
function Se(t3, e) {
  e !== void 0 && ne(e);
  let r = e !== void 0 ? e : t3.toString(2).length, n = Math.ceil(r / 8);
  return { nBitLength: r, nByteLength: n };
}
function kt(t3, e, r = false, n = {}) {
  if (t3 <= st) throw new Error("invalid field: expected ORDER > 0, got " + t3);
  let s, o, i = false, c;
  if (typeof e == "object" && e != null) {
    if (n.sqrt || r) throw new Error("cannot specify opts in two arguments");
    let a = e;
    a.BITS && (s = a.BITS), a.sqrt && (o = a.sqrt), typeof a.isLE == "boolean" && (r = a.isLE), typeof a.modFromBytes == "boolean" && (i = a.modFromBytes), c = a.allowedLengths;
  } else typeof e == "number" && (s = e), n.sqrt && (o = n.sqrt);
  let { nBitLength: f, nByteLength: u } = Se(t3, s);
  if (u > 2048) throw new Error("invalid field: expected ORDER of <= 2048 bytes");
  let p, g = Object.freeze({ ORDER: t3, isLE: r, BITS: f, BYTES: u, MASK: Ht(f), ZERO: st, ONE: ot, allowedLengths: c, create: (a) => ht(a, t3), isValid: (a) => {
    if (typeof a != "bigint") throw new Error("invalid field element: expected bigint, got " + typeof a);
    return st <= a && a < t3;
  }, is0: (a) => a === st, isValidNot0: (a) => !g.is0(a) && g.isValid(a), isOdd: (a) => (a & ot) === ot, neg: (a) => ht(-a, t3), eql: (a, l) => a === l, sqr: (a) => ht(a * a, t3), add: (a, l) => ht(a + l, t3), sub: (a, l) => ht(a - l, t3), mul: (a, l) => ht(a * l, t3), pow: (a, l) => No(g, a, l), div: (a, l) => ht(a * sr(l, t3), t3), sqrN: (a) => a * a, addN: (a, l) => a + l, subN: (a, l) => a - l, mulN: (a, l) => a * l, inv: (a) => sr(a, t3), sqrt: o || ((a) => (p || (p = Uo(t3)), p(g, a))), toBytes: (a) => r ? Ye(a, u) : Be(a, u), fromBytes: (a, l = true) => {
    if (c) {
      if (!c.includes(a.length) || a.length > u) throw new Error("Field.fromBytes: expected " + c + " bytes, got " + a.length);
      let S = new Uint8Array(u);
      S.set(a, r ? 0 : S.length - a.length), a = S;
    }
    if (a.length !== u) throw new Error("Field.fromBytes: expected " + u + " bytes, got " + a.length);
    let B = r ? Xe(a) : zt(a);
    if (i && (B = ht(B, t3)), !l && !g.isValid(B)) throw new Error("invalid field element: outside of range 0..ORDER");
    return B;
  }, invertBatch: (a) => _e(g, a), cmov: (a, l, B) => B ? l : a });
  return Object.freeze(g);
}
function pr(t3) {
  if (typeof t3 != "bigint") throw new Error("field order must be bigint");
  let e = t3.toString(2).length;
  return Math.ceil(e / 8);
}
function Qe(t3) {
  let e = pr(t3);
  return e + Math.ceil(e / 2);
}
function Je(t3, e, r = false) {
  let n = t3.length, s = pr(e), o = Qe(e);
  if (n < 16 || n < o || n > 1024) throw new Error("expected " + o + "-1024 bytes of input, got " + n);
  let i = r ? Xe(t3) : zt(t3), c = ht(i, e - ot) + ot;
  return r ? Ye(c, s) : Be(c, s);
}
var Wt = BigInt(0);
var Dt = BigInt(1);
function ce(t3, e) {
  let r = e.negate();
  return t3 ? r : e;
}
function Ie(t3, e) {
  let r = _e(t3.Fp, e.map((n) => n.Z));
  return e.map((n, s) => t3.fromAffine(n.toAffine(r[s])));
}
function yr(t3, e) {
  if (!Number.isSafeInteger(t3) || t3 <= 0 || t3 > e) throw new Error("invalid window size, expected [1.." + e + "], got W=" + t3);
}
function tn(t3, e) {
  yr(t3, e);
  let r = Math.ceil(e / t3) + 1, n = 2 ** (t3 - 1), s = 2 ** t3, o = Ht(t3), i = BigInt(t3);
  return { windows: r, windowSize: n, mask: o, maxNumber: s, shiftBy: i };
}
function xr(t3, e, r) {
  let { windowSize: n, mask: s, maxNumber: o, shiftBy: i } = r, c = Number(t3 & s), f = t3 >> i;
  c > n && (c -= o, f += Dt);
  let u = e * n, p = u + Math.abs(c) - 1, g = c === 0, a = c < 0, l = e % 2 !== 0;
  return { nextN: f, offset: p, isZero: g, isNeg: a, isNegF: l, offsetF: u };
}
function Mo(t3, e) {
  if (!Array.isArray(t3)) throw new Error("array expected");
  t3.forEach((r, n) => {
    if (!(r instanceof e)) throw new Error("invalid point at index " + n);
  });
}
function Co(t3, e) {
  if (!Array.isArray(t3)) throw new Error("array of scalars expected");
  t3.forEach((r, n) => {
    if (!e.isValid(r)) throw new Error("invalid scalar at index " + n);
  });
}
var en = /* @__PURE__ */ new WeakMap();
var wr = /* @__PURE__ */ new WeakMap();
function nn(t3) {
  return wr.get(t3) || 1;
}
function br(t3) {
  if (t3 !== Wt) throw new Error("invalid wNAF");
}
var ve = class {
  constructor(e, r) {
    this.BASE = e.BASE, this.ZERO = e.ZERO, this.Fn = e.Fn, this.bits = r;
  }
  _unsafeLadder(e, r, n = this.ZERO) {
    let s = e;
    for (; r > Wt; ) r & Dt && (n = n.add(s)), s = s.double(), r >>= Dt;
    return n;
  }
  precomputeWindow(e, r) {
    let { windows: n, windowSize: s } = tn(r, this.bits), o = [], i = e, c = i;
    for (let f = 0; f < n; f++) {
      c = i, o.push(c);
      for (let u = 1; u < s; u++) c = c.add(i), o.push(c);
      i = c.double();
    }
    return o;
  }
  wNAF(e, r, n) {
    if (!this.Fn.isValid(n)) throw new Error("invalid scalar");
    let s = this.ZERO, o = this.BASE, i = tn(e, this.bits);
    for (let c = 0; c < i.windows; c++) {
      let { nextN: f, offset: u, isZero: p, isNeg: g, isNegF: a, offsetF: l } = xr(n, c, i);
      n = f, p ? o = o.add(ce(a, r[l])) : s = s.add(ce(g, r[u]));
    }
    return br(n), { p: s, f: o };
  }
  wNAFUnsafe(e, r, n, s = this.ZERO) {
    let o = tn(e, this.bits);
    for (let i = 0; i < o.windows && n !== Wt; i++) {
      let { nextN: c, offset: f, isZero: u, isNeg: p } = xr(n, i, o);
      if (n = c, !u) {
        let g = r[f];
        s = s.add(p ? g.negate() : g);
      }
    }
    return br(n), s;
  }
  getPrecomputes(e, r, n) {
    let s = en.get(r);
    return s || (s = this.precomputeWindow(r, e), e !== 1 && (typeof n == "function" && (s = n(s)), en.set(r, s))), s;
  }
  cached(e, r, n) {
    let s = nn(e);
    return this.wNAF(s, this.getPrecomputes(s, e, n), r);
  }
  unsafe(e, r, n, s) {
    let o = nn(e);
    return o === 1 ? this._unsafeLadder(e, r, s) : this.wNAFUnsafe(o, this.getPrecomputes(o, e, n), r, s);
  }
  createCache(e, r) {
    yr(r, this.bits), wr.set(e, r), en.delete(e);
  }
  hasCache(e) {
    return nn(e) !== 1;
  }
};
function mr(t3, e, r, n) {
  let s = e, o = t3.ZERO, i = t3.ZERO;
  for (; r > Wt || n > Wt; ) r & Dt && (o = o.add(s)), n & Dt && (i = i.add(s)), s = s.double(), r >>= Dt, n >>= Dt;
  return { p1: o, p2: i };
}
function Er(t3, e, r, n) {
  Mo(r, t3), Co(n, e);
  let s = r.length, o = n.length;
  if (s !== o) throw new Error("arrays of points and scalars must have equal length");
  let i = t3.ZERO, c = Ae(BigInt(s)), f = 1;
  c > 12 ? f = c - 3 : c > 4 ? f = c - 2 : c > 0 && (f = 2);
  let u = Ht(f), p = new Array(Number(u) + 1).fill(i), g = Math.floor((e.BITS - 1) / f) * f, a = i;
  for (let l = g; l >= 0; l -= f) {
    p.fill(i);
    for (let S = 0; S < o; S++) {
      let q = n[S], V = Number(q >> BigInt(l) & u);
      p[V] = p[V].add(r[S]);
    }
    let B = i;
    for (let S = p.length - 1, q = i; S > 0; S--) q = q.add(p[S]), B = B.add(q);
    if (a = a.add(B), l !== 0) for (let S = 0; S < f; S++) a = a.double();
  }
  return a;
}
function gr(t3, e, r) {
  if (e) {
    if (e.ORDER !== t3) throw new Error("Field.ORDER must match order: Fp == p, Fn == n");
    return Fe(e), e;
  } else return kt(t3, { isLE: r });
}
function Br(t3, e, r = {}, n) {
  if (n === void 0 && (n = t3 === "edwards"), !e || typeof e != "object") throw new Error(`expected valid ${t3} CURVE object`);
  for (let f of ["p", "n", "h"]) {
    let u = e[f];
    if (!(typeof u == "bigint" && u > Wt)) throw new Error(`CURVE.${f} must be positive bigint`);
  }
  let s = gr(e.p, r.Fp, n), o = gr(e.n, r.Fn, n), c = ["Gx", "Gy", "a", t3 === "weierstrass" ? "b" : "d"];
  for (let f of c) if (!s.isValid(e[f])) throw new Error(`CURVE.${f} must be valid field element of CURVE.Fp`);
  return e = Object.freeze(Object.assign({}, e)), { CURVE: e, Fp: s, Fn: o };
}
var Ar = (t3, e) => (t3 + (t3 >= 0 ? e : -e) / _r) / e;
function qo(t3, e, r) {
  let [[n, s], [o, i]] = e, c = Ar(i * t3, r), f = Ar(-s * t3, r), u = t3 - c * n - f * o, p = -c * s - f * i, g = u < vt, a = p < vt;
  g && (u = -u), a && (p = -p);
  let l = Ht(Math.ceil(Ae(r) / 2)) + Qt;
  if (u < vt || u >= l || p < vt || p >= l) throw new Error("splitScalar (endomorphism): failed, k=" + t3);
  return { k1neg: g, k1: u, k2neg: a, k2: p };
}
function on(t3) {
  if (!["compact", "recovered", "der"].includes(t3)) throw new Error('Signature format must be "compact", "recovered", or "der"');
  return t3;
}
function rn(t3, e) {
  let r = {};
  for (let n of Object.keys(e)) r[n] = t3[n] === void 0 ? e[n] : t3[n];
  return oe(r.lowS, "lowS"), oe(r.prehash, "prehash"), r.format !== void 0 && on(r.format), r;
}
var sn = class extends Error {
  constructor(e = "") {
    super(e);
  }
};
var St = { Err: sn, _tlv: { encode: (t3, e) => {
  let { Err: r } = St;
  if (t3 < 0 || t3 > 256) throw new r("tlv.encode: wrong tag");
  if (e.length & 1) throw new r("tlv.encode: unpadded data");
  let n = e.length / 2, s = se(n);
  if (s.length / 2 & 128) throw new r("tlv.encode: long form length too big");
  let o = n > 127 ? se(s.length / 2 | 128) : "";
  return se(t3) + o + s + e;
}, decode(t3, e) {
  let { Err: r } = St, n = 0;
  if (t3 < 0 || t3 > 256) throw new r("tlv.encode: wrong tag");
  if (e.length < 2 || e[n++] !== t3) throw new r("tlv.decode: wrong tlv");
  let s = e[n++], o = !!(s & 128), i = 0;
  if (!o) i = s;
  else {
    let f = s & 127;
    if (!f) throw new r("tlv.decode(long): indefinite length not supported");
    if (f > 4) throw new r("tlv.decode(long): byte length is too big");
    let u = e.subarray(n, n + f);
    if (u.length !== f) throw new r("tlv.decode: length bytes not complete");
    if (u[0] === 0) throw new r("tlv.decode(long): zero leftmost byte");
    for (let p of u) i = i << 8 | p;
    if (n += f, i < 128) throw new r("tlv.decode(long): not minimal encoding");
  }
  let c = e.subarray(n, n + i);
  if (c.length !== i) throw new r("tlv.decode: wrong value length");
  return { v: c, l: e.subarray(n + i) };
} }, _int: { encode(t3) {
  let { Err: e } = St;
  if (t3 < vt) throw new e("integer: negative integers are not allowed");
  let r = se(t3);
  if (Number.parseInt(r[0], 16) & 8 && (r = "00" + r), r.length & 1) throw new e("unexpected DER parsing assertion: unpadded hex");
  return r;
}, decode(t3) {
  let { Err: e } = St;
  if (t3[0] & 128) throw new e("invalid signature integer: negative");
  if (t3[0] === 0 && !(t3[1] & 128)) throw new e("invalid signature integer: unnecessary leading zero");
  return zt(t3);
} }, toSig(t3) {
  let { Err: e, _int: r, _tlv: n } = St, s = rt("signature", t3), { v: o, l: i } = n.decode(48, s);
  if (i.length) throw new e("invalid signature: left bytes after parsing");
  let { v: c, l: f } = n.decode(2, o), { v: u, l: p } = n.decode(2, f);
  if (p.length) throw new e("invalid signature: left bytes after parsing");
  return { r: r.decode(c), s: r.decode(u) };
}, hexFromSig(t3) {
  let { _tlv: e, _int: r } = St, n = e.encode(2, r.encode(t3.r)), s = e.encode(2, r.encode(t3.s)), o = n + s;
  return e.encode(48, o);
} };
var vt = BigInt(0);
var Qt = BigInt(1);
var _r = BigInt(2);
var Le = BigInt(3);
var jo = BigInt(4);
function Ft(t3, e) {
  let { BYTES: r } = t3, n;
  if (typeof e == "bigint") n = e;
  else {
    let s = rt("private key", e);
    try {
      n = t3.fromBytes(s);
    } catch {
      throw new Error(`invalid private key: expected ui8a of size ${r}, got ${typeof e}`);
    }
  }
  if (!t3.isValidNot0(n)) throw new Error("invalid private key: out of range [1..N-1]");
  return n;
}
function Vo(t3, e = {}) {
  let r = Br("weierstrass", t3, e), { Fp: n, Fn: s } = r, o = r.CURVE, { h: i, n: c } = o;
  ie(e, {}, { allowInfinityPoint: "boolean", clearCofactor: "function", isTorsionFree: "function", fromBytes: "function", toBytes: "function", endo: "object", wrapPrivateKey: "boolean" });
  let { endo: f } = e;
  if (f && (!n.is0(o.a) || typeof f.beta != "bigint" || !Array.isArray(f.basises))) throw new Error('invalid endo: expected "beta": bigint and "basises": array');
  let u = vr(n, s);
  function p() {
    if (!n.isOdd) throw new Error("compression is not supported: Field does not have .isOdd()");
  }
  function g(M, b, x) {
    let { x: d, y: E } = b.toAffine(), A = n.toBytes(d);
    if (oe(x, "isCompressed"), x) {
      p();
      let k = !n.isOdd(E);
      return bt(Sr(k), A);
    } else return bt(Uint8Array.of(4), A, n.toBytes(E));
  }
  function a(M) {
    Tt(M, void 0, "Point");
    let { publicKey: b, publicKeyUncompressed: x } = u, d = M.length, E = M[0], A = M.subarray(1);
    if (d === b && (E === 2 || E === 3)) {
      let k = n.fromBytes(A);
      if (!n.isValid(k)) throw new Error("bad point: is not on curve, wrong x");
      let H = S(k), I;
      try {
        I = n.sqrt(H);
      } catch (j) {
        let h = j instanceof Error ? ": " + j.message : "";
        throw new Error("bad point: is not on curve, sqrt error" + h);
      }
      p();
      let U = n.isOdd(I);
      return (E & 1) === 1 !== U && (I = n.neg(I)), { x: k, y: I };
    } else if (d === x && E === 4) {
      let k = n.BYTES, H = n.fromBytes(A.subarray(0, k)), I = n.fromBytes(A.subarray(k, k * 2));
      if (!q(H, I)) throw new Error("bad point: is not on curve");
      return { x: H, y: I };
    } else throw new Error(`bad point: got length ${d}, expected compressed=${b} or uncompressed=${x}`);
  }
  let l = e.toBytes || g, B = e.fromBytes || a;
  function S(M) {
    let b = n.sqr(M), x = n.mul(b, M);
    return n.add(n.add(x, n.mul(M, o.a)), o.b);
  }
  function q(M, b) {
    let x = n.sqr(b), d = S(M);
    return n.eql(x, d);
  }
  if (!q(o.Gx, o.Gy)) throw new Error("bad curve params: generator point");
  let V = n.mul(n.pow(o.a, Le), jo), R = n.mul(n.sqr(o.b), BigInt(27));
  if (n.is0(n.add(V, R))) throw new Error("bad curve params: a or b");
  function T(M, b, x = false) {
    if (!n.isValid(b) || x && n.is0(b)) throw new Error(`bad point coordinate ${M}`);
    return b;
  }
  function Z(M) {
    if (!(M instanceof O)) throw new Error("ProjectivePoint expected");
  }
  function Y(M) {
    if (!f || !f.basises) throw new Error("no endo");
    return qo(M, f.basises, s.ORDER);
  }
  let z = ze((M, b) => {
    let { X: x, Y: d, Z: E } = M;
    if (n.eql(E, n.ONE)) return { x, y: d };
    let A = M.is0();
    b == null && (b = A ? n.ONE : n.inv(E));
    let k = n.mul(x, b), H = n.mul(d, b), I = n.mul(E, b);
    if (A) return { x: n.ZERO, y: n.ZERO };
    if (!n.eql(I, n.ONE)) throw new Error("invZ was invalid");
    return { x: k, y: H };
  }), et = ze((M) => {
    if (M.is0()) {
      if (e.allowInfinityPoint && !n.is0(M.Y)) return;
      throw new Error("bad point: ZERO");
    }
    let { x: b, y: x } = M.toAffine();
    if (!n.isValid(b) || !n.isValid(x)) throw new Error("bad point: x or y not field elements");
    if (!q(b, x)) throw new Error("bad point: equation left != right");
    if (!M.isTorsionFree()) throw new Error("bad point: not in prime-order subgroup");
    return true;
  });
  function P(M, b, x, d, E) {
    return x = new O(n.mul(x.X, M), x.Y, x.Z), b = ce(d, b), x = ce(E, x), b.add(x);
  }
  class O {
    constructor(b, x, d) {
      this.X = T("x", b), this.Y = T("y", x, true), this.Z = T("z", d), Object.freeze(this);
    }
    static CURVE() {
      return o;
    }
    static fromAffine(b) {
      let { x, y: d } = b || {};
      if (!b || !n.isValid(x) || !n.isValid(d)) throw new Error("invalid affine point");
      if (b instanceof O) throw new Error("projective point not allowed");
      return n.is0(x) && n.is0(d) ? O.ZERO : new O(x, d, n.ONE);
    }
    static fromBytes(b) {
      let x = O.fromAffine(B(Tt(b, void 0, "point")));
      return x.assertValidity(), x;
    }
    static fromHex(b) {
      return O.fromBytes(rt("pointHex", b));
    }
    get x() {
      return this.toAffine().x;
    }
    get y() {
      return this.toAffine().y;
    }
    precompute(b = 8, x = true) {
      return it.createCache(this, b), x || this.multiply(Le), this;
    }
    assertValidity() {
      et(this);
    }
    hasEvenY() {
      let { y: b } = this.toAffine();
      if (!n.isOdd) throw new Error("Field doesn't support isOdd");
      return !n.isOdd(b);
    }
    equals(b) {
      Z(b);
      let { X: x, Y: d, Z: E } = this, { X: A, Y: k, Z: H } = b, I = n.eql(n.mul(x, H), n.mul(A, E)), U = n.eql(n.mul(d, H), n.mul(k, E));
      return I && U;
    }
    negate() {
      return new O(this.X, n.neg(this.Y), this.Z);
    }
    double() {
      let { a: b, b: x } = o, d = n.mul(x, Le), { X: E, Y: A, Z: k } = this, H = n.ZERO, I = n.ZERO, U = n.ZERO, N = n.mul(E, E), j = n.mul(A, A), h = n.mul(k, k), y = n.mul(E, A);
      return y = n.add(y, y), U = n.mul(E, k), U = n.add(U, U), H = n.mul(b, U), I = n.mul(d, h), I = n.add(H, I), H = n.sub(j, I), I = n.add(j, I), I = n.mul(H, I), H = n.mul(y, H), U = n.mul(d, U), h = n.mul(b, h), y = n.sub(N, h), y = n.mul(b, y), y = n.add(y, U), U = n.add(N, N), N = n.add(U, N), N = n.add(N, h), N = n.mul(N, y), I = n.add(I, N), h = n.mul(A, k), h = n.add(h, h), N = n.mul(h, y), H = n.sub(H, N), U = n.mul(h, j), U = n.add(U, U), U = n.add(U, U), new O(H, I, U);
    }
    add(b) {
      Z(b);
      let { X: x, Y: d, Z: E } = this, { X: A, Y: k, Z: H } = b, I = n.ZERO, U = n.ZERO, N = n.ZERO, j = o.a, h = n.mul(o.b, Le), y = n.mul(x, A), w = n.mul(d, k), m = n.mul(E, H), _ = n.add(x, d), v = n.add(A, k);
      _ = n.mul(_, v), v = n.add(y, w), _ = n.sub(_, v), v = n.add(x, E);
      let C = n.add(A, H);
      return v = n.mul(v, C), C = n.add(y, m), v = n.sub(v, C), C = n.add(d, E), I = n.add(k, H), C = n.mul(C, I), I = n.add(w, m), C = n.sub(C, I), N = n.mul(j, v), I = n.mul(h, m), N = n.add(I, N), I = n.sub(w, N), N = n.add(w, N), U = n.mul(I, N), w = n.add(y, y), w = n.add(w, y), m = n.mul(j, m), v = n.mul(h, v), w = n.add(w, m), m = n.sub(y, m), m = n.mul(j, m), v = n.add(v, m), y = n.mul(w, v), U = n.add(U, y), y = n.mul(C, v), I = n.mul(_, I), I = n.sub(I, y), y = n.mul(_, w), N = n.mul(C, N), N = n.add(N, y), new O(I, U, N);
    }
    subtract(b) {
      return this.add(b.negate());
    }
    is0() {
      return this.equals(O.ZERO);
    }
    multiply(b) {
      let { endo: x } = e;
      if (!s.isValidNot0(b)) throw new Error("invalid scalar: out of range");
      let d, E, A = (k) => it.cached(this, k, (H) => Ie(O, H));
      if (x) {
        let { k1neg: k, k1: H, k2neg: I, k2: U } = Y(b), { p: N, f: j } = A(H), { p: h, f: y } = A(U);
        E = j.add(y), d = P(x.beta, N, h, k, I);
      } else {
        let { p: k, f: H } = A(b);
        d = k, E = H;
      }
      return Ie(O, [d, E])[0];
    }
    multiplyUnsafe(b) {
      let { endo: x } = e, d = this;
      if (!s.isValid(b)) throw new Error("invalid scalar: out of range");
      if (b === vt || d.is0()) return O.ZERO;
      if (b === Qt) return d;
      if (it.hasCache(this)) return this.multiply(b);
      if (x) {
        let { k1neg: E, k1: A, k2neg: k, k2: H } = Y(b), { p1: I, p2: U } = mr(O, d, A, H);
        return P(x.beta, I, U, E, k);
      } else return it.unsafe(d, b);
    }
    multiplyAndAddUnsafe(b, x, d) {
      let E = this.multiplyUnsafe(x).add(b.multiplyUnsafe(d));
      return E.is0() ? void 0 : E;
    }
    toAffine(b) {
      return z(this, b);
    }
    isTorsionFree() {
      let { isTorsionFree: b } = e;
      return i === Qt ? true : b ? b(O, this) : it.unsafe(this, c).is0();
    }
    clearCofactor() {
      let { clearCofactor: b } = e;
      return i === Qt ? this : b ? b(O, this) : this.multiplyUnsafe(i);
    }
    isSmallOrder() {
      return this.multiplyUnsafe(i).is0();
    }
    toBytes(b = true) {
      return oe(b, "isCompressed"), this.assertValidity(), l(O, this, b);
    }
    toHex(b = true) {
      return At(this.toBytes(b));
    }
    toString() {
      return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
    }
    get px() {
      return this.X;
    }
    get py() {
      return this.X;
    }
    get pz() {
      return this.Z;
    }
    toRawBytes(b = true) {
      return this.toBytes(b);
    }
    _setWindowSize(b) {
      this.precompute(b);
    }
    static normalizeZ(b) {
      return Ie(O, b);
    }
    static msm(b, x) {
      return Er(O, s, b, x);
    }
    static fromPrivateKey(b) {
      return O.BASE.multiply(Ft(s, b));
    }
  }
  O.BASE = new O(o.Gx, o.Gy, n.ONE), O.ZERO = new O(n.ZERO, n.ONE, n.ZERO), O.Fp = n, O.Fn = s;
  let W = s.BITS, it = new ve(O, e.endo ? Math.ceil(W / 2) : W);
  return O.BASE.precompute(8), O;
}
function Sr(t3) {
  return Uint8Array.of(t3 ? 2 : 3);
}
function vr(t3, e) {
  return { secretKey: e.BYTES, publicKey: 1 + t3.BYTES, publicKeyUncompressed: 1 + 2 * t3.BYTES, publicKeyHasPrefix: true, signature: 2 * e.BYTES };
}
function Do(t3, e = {}) {
  let { Fn: r } = t3, n = e.randomBytes || we, s = Object.assign(vr(t3.Fp, r), { seed: Qe(r.ORDER) });
  function o(l) {
    try {
      return !!Ft(r, l);
    } catch {
      return false;
    }
  }
  function i(l, B) {
    let { publicKey: S, publicKeyUncompressed: q } = s;
    try {
      let V = l.length;
      return B === true && V !== S || B === false && V !== q ? false : !!t3.fromBytes(l);
    } catch {
      return false;
    }
  }
  function c(l = n(s.seed)) {
    return Je(Tt(l, s.seed, "seed"), r.ORDER);
  }
  function f(l, B = true) {
    return t3.BASE.multiply(Ft(r, l)).toBytes(B);
  }
  function u(l) {
    let B = c(l);
    return { secretKey: B, publicKey: f(B) };
  }
  function p(l) {
    if (typeof l == "bigint") return false;
    if (l instanceof t3) return true;
    let { secretKey: B, publicKey: S, publicKeyUncompressed: q } = s;
    if (r.allowedLengths || B === S) return;
    let V = rt("key", l).length;
    return V === S || V === q;
  }
  function g(l, B, S = true) {
    if (p(l) === true) throw new Error("first arg must be private key");
    if (p(B) === false) throw new Error("second arg must be public key");
    let q = Ft(r, l);
    return t3.fromHex(B).multiply(q).toBytes(S);
  }
  return Object.freeze({ getPublicKey: f, getSharedSecret: g, keygen: u, Point: t3, utils: { isValidSecretKey: o, isValidPublicKey: i, randomSecretKey: c, isValidPrivateKey: o, randomPrivateKey: c, normPrivateKeyToScalar: (l) => Ft(r, l), precompute(l = 8, B = t3.BASE) {
    return B.precompute(l, false);
  } }, lengths: s });
}
function Ko(t3, e, r = {}) {
  ge(e), ie(r, {}, { hmac: "function", lowS: "boolean", randomBytes: "function", bits2int: "function", bits2int_modN: "function" });
  let n = r.randomBytes || we, s = r.hmac || ((x, ...d) => Ze(e, x, bt(...d))), { Fp: o, Fn: i } = t3, { ORDER: c, BITS: f } = i, { keygen: u, getPublicKey: p, getSharedSecret: g, utils: a, lengths: l } = Do(t3, r), B = { prehash: false, lowS: typeof r.lowS == "boolean" ? r.lowS : false, format: void 0, extraEntropy: false }, S = "compact";
  function q(x) {
    let d = c >> Qt;
    return x > d;
  }
  function V(x, d) {
    if (!i.isValidNot0(d)) throw new Error(`invalid signature ${x}: out of range 1..Point.Fn.ORDER`);
    return d;
  }
  function R(x, d) {
    on(d);
    let E = l.signature, A = d === "compact" ? E : d === "recovered" ? E + 1 : void 0;
    return Tt(x, A, `${d} signature`);
  }
  class T {
    constructor(d, E, A) {
      this.r = V("r", d), this.s = V("s", E), A != null && (this.recovery = A), Object.freeze(this);
    }
    static fromBytes(d, E = S) {
      R(d, E);
      let A;
      if (E === "der") {
        let { r: U, s: N } = St.toSig(Tt(d));
        return new T(U, N);
      }
      E === "recovered" && (A = d[0], E = "compact", d = d.subarray(1));
      let k = i.BYTES, H = d.subarray(0, k), I = d.subarray(k, k * 2);
      return new T(i.fromBytes(H), i.fromBytes(I), A);
    }
    static fromHex(d, E) {
      return this.fromBytes(jt(d), E);
    }
    addRecoveryBit(d) {
      return new T(this.r, this.s, d);
    }
    recoverPublicKey(d) {
      let E = o.ORDER, { r: A, s: k, recovery: H } = this;
      if (H == null || ![0, 1, 2, 3].includes(H)) throw new Error("recovery id invalid");
      if (c * _r < E && H > 1) throw new Error("recovery id is ambiguous for h>1 curve");
      let U = H === 2 || H === 3 ? A + c : A;
      if (!o.isValid(U)) throw new Error("recovery id 2 or 3 invalid");
      let N = o.toBytes(U), j = t3.fromBytes(bt(Sr((H & 1) === 0), N)), h = i.inv(U), y = Y(rt("msgHash", d)), w = i.create(-y * h), m = i.create(k * h), _ = t3.BASE.multiplyUnsafe(w).add(j.multiplyUnsafe(m));
      if (_.is0()) throw new Error("point at infinify");
      return _.assertValidity(), _;
    }
    hasHighS() {
      return q(this.s);
    }
    toBytes(d = S) {
      if (on(d), d === "der") return jt(St.hexFromSig(this));
      let E = i.toBytes(this.r), A = i.toBytes(this.s);
      if (d === "recovered") {
        if (this.recovery == null) throw new Error("recovery bit must be present");
        return bt(Uint8Array.of(this.recovery), E, A);
      }
      return bt(E, A);
    }
    toHex(d) {
      return At(this.toBytes(d));
    }
    assertValidity() {
    }
    static fromCompact(d) {
      return T.fromBytes(rt("sig", d), "compact");
    }
    static fromDER(d) {
      return T.fromBytes(rt("sig", d), "der");
    }
    normalizeS() {
      return this.hasHighS() ? new T(this.r, i.neg(this.s), this.recovery) : this;
    }
    toDERRawBytes() {
      return this.toBytes("der");
    }
    toDERHex() {
      return At(this.toBytes("der"));
    }
    toCompactRawBytes() {
      return this.toBytes("compact");
    }
    toCompactHex() {
      return At(this.toBytes("compact"));
    }
  }
  let Z = r.bits2int || function(d) {
    if (d.length > 8192) throw new Error("input is too large");
    let E = zt(d), A = d.length * 8 - f;
    return A > 0 ? E >> BigInt(A) : E;
  }, Y = r.bits2int_modN || function(d) {
    return i.create(Z(d));
  }, z = Ht(f);
  function et(x) {
    return rr("num < 2^" + f, x, vt, z), i.toBytes(x);
  }
  function P(x, d) {
    return Tt(x, void 0, "message"), d ? Tt(e(x), void 0, "prehashed message") : x;
  }
  function O(x, d, E) {
    if (["recovered", "canonical"].some((w) => w in E)) throw new Error("sign() legacy options not supported");
    let { lowS: A, prehash: k, extraEntropy: H } = rn(E, B);
    x = P(x, k);
    let I = Y(x), U = Ft(i, d), N = [et(U), et(I)];
    if (H != null && H !== false) {
      let w = H === true ? n(l.secretKey) : H;
      N.push(rt("extraEntropy", w));
    }
    let j = bt(...N), h = I;
    function y(w) {
      let m = Z(w);
      if (!i.isValidNot0(m)) return;
      let _ = i.inv(m), v = t3.BASE.multiply(m).toAffine(), C = i.create(v.x);
      if (C === vt) return;
      let F = i.create(_ * i.create(h + C * U));
      if (F === vt) return;
      let G = (v.x === C ? 0 : 2) | Number(v.y & Qt), $ = F;
      return A && q(F) && ($ = i.neg(F), G ^= 1), new T(C, $, G);
    }
    return { seed: j, k2sig: y };
  }
  function W(x, d, E = {}) {
    x = rt("message", x);
    let { seed: A, k2sig: k } = O(x, d, E);
    return or(e.outputLen, i.BYTES, s)(A, k);
  }
  function it(x) {
    let d, E = typeof x == "string" || Ct(x), A = !E && x !== null && typeof x == "object" && typeof x.r == "bigint" && typeof x.s == "bigint";
    if (!E && !A) throw new Error("invalid signature, expected Uint8Array, hex string or Signature instance");
    if (A) d = new T(x.r, x.s);
    else if (E) {
      try {
        d = T.fromBytes(rt("sig", x), "der");
      } catch (k) {
        if (!(k instanceof St.Err)) throw k;
      }
      if (!d) try {
        d = T.fromBytes(rt("sig", x), "compact");
      } catch {
        return false;
      }
    }
    return d || false;
  }
  function M(x, d, E, A = {}) {
    let { lowS: k, prehash: H, format: I } = rn(A, B);
    if (E = rt("publicKey", E), d = P(rt("message", d), H), "strict" in A) throw new Error("options.strict was renamed to lowS");
    let U = I === void 0 ? it(x) : T.fromBytes(rt("sig", x), I);
    if (U === false) return false;
    try {
      let N = t3.fromBytes(E);
      if (k && U.hasHighS()) return false;
      let { r: j, s: h } = U, y = Y(d), w = i.inv(h), m = i.create(y * w), _ = i.create(j * w), v = t3.BASE.multiplyUnsafe(m).add(N.multiplyUnsafe(_));
      return v.is0() ? false : i.create(v.x) === j;
    } catch {
      return false;
    }
  }
  function b(x, d, E = {}) {
    let { prehash: A } = rn(E, B);
    return d = P(d, A), T.fromBytes(x, "recovered").recoverPublicKey(d).toBytes();
  }
  return Object.freeze({ keygen: u, getPublicKey: p, getSharedSecret: g, utils: a, lengths: l, Point: t3, sign: W, verify: M, recoverPublicKey: b, Signature: T, hash: e });
}
function Zo(t3) {
  let e = { a: t3.a, b: t3.b, p: t3.Fp.ORDER, n: t3.n, h: t3.h, Gx: t3.Gx, Gy: t3.Gy }, r = t3.Fp, n = t3.allowedPrivateKeyLengths ? Array.from(new Set(t3.allowedPrivateKeyLengths.map((i) => Math.ceil(i / 2)))) : void 0, s = kt(e.n, { BITS: t3.nBitLength, allowedLengths: n, modFromBytes: t3.wrapPrivateKey }), o = { Fp: r, Fn: s, allowInfinityPoint: t3.allowInfinityPoint, endo: t3.endo, isTorsionFree: t3.isTorsionFree, clearCofactor: t3.clearCofactor, fromBytes: t3.fromBytes, toBytes: t3.toBytes };
  return { CURVE: e, curveOpts: o };
}
function Po(t3) {
  let { CURVE: e, curveOpts: r } = Zo(t3), n = { hmac: t3.hmac, randomBytes: t3.randomBytes, lowS: t3.lowS, bits2int: t3.bits2int, bits2int_modN: t3.bits2int_modN };
  return { CURVE: e, curveOpts: r, hash: t3.hash, ecdsaOpts: n };
}
function Go(t3, e) {
  let r = e.Point;
  return Object.assign({}, e, { ProjectivePoint: r, CURVE: Object.assign({}, t3, Se(r.Fn.ORDER, r.Fn.BITS)) });
}
function Ir(t3) {
  let { CURVE: e, curveOpts: r, hash: n, ecdsaOpts: s } = Po(t3), o = Vo(e, r), i = Ko(o, n, s);
  return Go(t3, i);
}
function Lr(t3, e) {
  let r = (n) => Ir({ ...t3, hash: n });
  return { ...r(e), create: r };
}
var fn = { p: BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f"), n: BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141"), h: BigInt(1), a: BigInt(0), b: BigInt(7), Gx: BigInt("0x79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798"), Gy: BigInt("0x483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8") };
var $o = { beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee"), basises: [[BigInt("0x3086d221a7d46bcde86c90e49284eb15"), -BigInt("0xe4437ed6010e88286f547fa90abfe4c3")], [BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8"), BigInt("0x3086d221a7d46bcde86c90e49284eb15")]] };
var Or = BigInt(2);
function Xo(t3) {
  let e = fn.p, r = BigInt(3), n = BigInt(6), s = BigInt(11), o = BigInt(22), i = BigInt(23), c = BigInt(44), f = BigInt(88), u = t3 * t3 * t3 % e, p = u * u * t3 % e, g = ut(p, r, e) * p % e, a = ut(g, r, e) * p % e, l = ut(a, Or, e) * u % e, B = ut(l, s, e) * l % e, S = ut(B, o, e) * B % e, q = ut(S, c, e) * S % e, V = ut(q, f, e) * q % e, R = ut(V, c, e) * S % e, T = ut(R, r, e) * p % e, Z = ut(T, i, e) * B % e, Y = ut(Z, n, e) * u % e, z = ut(Y, Or, e);
  if (!cn.eql(cn.sqr(z), t3)) throw new Error("Cannot find square root");
  return z;
}
var cn = kt(fn.p, { sqrt: Xo });
var Yo = Lr({ ...fn, Fp: cn, lowS: true, endo: $o }, tr);
function an(t3) {
  return t3 instanceof Uint8Array || ArrayBuffer.isView(t3) && t3.constructor.name === "Uint8Array";
}
function un(t3, e = "") {
  if (!Number.isSafeInteger(t3) || t3 < 0) {
    let r = e && `"${e}" `;
    throw new Error(`${r}expected integer >= 0, got ${t3}`);
  }
}
function X(t3, e, r = "") {
  let n = an(t3), s = t3?.length, o = e !== void 0;
  if (!n || o && s !== e) {
    let i = r && `"${r}" `, c = o ? ` of length ${e}` : "", f = n ? `length=${s}` : `type=${typeof t3}`;
    throw new Error(i + "expected Uint8Array" + c + ", got " + f);
  }
  return t3;
}
function ln(t3, e = true) {
  if (t3.destroyed) throw new Error("Hash instance has been destroyed");
  if (e && t3.finished) throw new Error("Hash#digest() has already been called");
}
function Tr(t3, e) {
  X(t3, void 0, "digestInto() output");
  let r = e.outputLen;
  if (t3.length < r) throw new Error('"digestInto() output" expected to be of length >=' + r);
}
function Hr(t3) {
  return new Uint32Array(t3.buffer, t3.byteOffset, Math.floor(t3.byteLength / 4));
}
function dn(...t3) {
  for (let e = 0; e < t3.length; e++) t3[e].fill(0);
}
var zo = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
function Wo(t3) {
  return t3 << 24 & 4278190080 | t3 << 8 & 16711680 | t3 >>> 8 & 65280 | t3 >>> 24 & 255;
}
function Fo(t3) {
  for (let e = 0; e < t3.length; e++) t3[e] = Wo(t3[e]);
  return t3;
}
var hn = zo ? (t3) => t3 : Fo;
function pn(...t3) {
  let e = 0;
  for (let n = 0; n < t3.length; n++) {
    let s = t3[n];
    X(s), e += s.length;
  }
  let r = new Uint8Array(e);
  for (let n = 0, s = 0; n < t3.length; n++) {
    let o = t3[n];
    r.set(o, s), s += o.length;
  }
  return r;
}
function kr(t3, e = {}) {
  let r = (s, o) => t3(o).update(s).digest(), n = t3(void 0);
  return r.outputLen = n.outputLen, r.blockLen = n.blockLen, r.create = (s) => t3(s), Object.assign(r, e), Object.freeze(r);
}
function Ur(t3 = 32) {
  let e = typeof globalThis == "object" ? globalThis.crypto : null;
  if (typeof e?.getRandomValues != "function") throw new Error("crypto.getRandomValues must be defined");
  return e.getRandomValues(new Uint8Array(t3));
}
var xn = (t3) => ({ oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, t3]) });
function Rr(t3, e = "") {
  if (typeof t3 != "boolean") {
    let r = e && `"${e}" `;
    throw new Error(r + "expected boolean, got type=" + typeof t3);
  }
  return t3;
}
var Oe = BigInt(4294967295);
var Nr = BigInt(32);
function Qo(t3, e = false) {
  return e ? { h: Number(t3 & Oe), l: Number(t3 >> Nr & Oe) } : { h: Number(t3 >> Nr & Oe) | 0, l: Number(t3 & Oe) | 0 };
}
function Mr(t3, e = false) {
  let r = t3.length, n = new Uint32Array(r), s = new Uint32Array(r);
  for (let o = 0; o < r; o++) {
    let { h: i, l: c } = Qo(t3[o], e);
    [n[o], s[o]] = [i, c];
  }
  return [n, s];
}
var Cr = (t3, e, r) => t3 << r | e >>> 32 - r;
var qr = (t3, e, r) => e << r | t3 >>> 32 - r;
var jr = (t3, e, r) => e << r - 32 | t3 >>> 64 - r;
var Vr = (t3, e, r) => t3 << r - 32 | e >>> 64 - r;
var Jo = BigInt(0);
var fe = BigInt(1);
var ts = BigInt(2);
var es = BigInt(7);
var ns = BigInt(256);
var rs = BigInt(113);
var Zr = [];
var Pr = [];
var Gr = [];
for (let t3 = 0, e = fe, r = 1, n = 0; t3 < 24; t3++) {
  [r, n] = [n, (2 * r + 3 * n) % 5], Zr.push(2 * (5 * n + r)), Pr.push((t3 + 1) * (t3 + 2) / 2 % 64);
  let s = Jo;
  for (let o = 0; o < 7; o++) e = (e << fe ^ (e >> es) * rs) % ns, e & ts && (s ^= fe << (fe << BigInt(o)) - fe);
  Gr.push(s);
}
var $r = Mr(Gr, true);
var os = $r[0];
var ss = $r[1];
var Dr = (t3, e, r) => r > 32 ? jr(t3, e, r) : Cr(t3, e, r);
var Kr = (t3, e, r) => r > 32 ? Vr(t3, e, r) : qr(t3, e, r);
function is(t3, e = 24) {
  let r = new Uint32Array(10);
  for (let n = 24 - e; n < 24; n++) {
    for (let i = 0; i < 10; i++) r[i] = t3[i] ^ t3[i + 10] ^ t3[i + 20] ^ t3[i + 30] ^ t3[i + 40];
    for (let i = 0; i < 10; i += 2) {
      let c = (i + 8) % 10, f = (i + 2) % 10, u = r[f], p = r[f + 1], g = Dr(u, p, 1) ^ r[c], a = Kr(u, p, 1) ^ r[c + 1];
      for (let l = 0; l < 50; l += 10) t3[i + l] ^= g, t3[i + l + 1] ^= a;
    }
    let s = t3[2], o = t3[3];
    for (let i = 0; i < 24; i++) {
      let c = Pr[i], f = Dr(s, o, c), u = Kr(s, o, c), p = Zr[i];
      s = t3[p], o = t3[p + 1], t3[p] = f, t3[p + 1] = u;
    }
    for (let i = 0; i < 50; i += 10) {
      for (let c = 0; c < 10; c++) r[c] = t3[i + c];
      for (let c = 0; c < 10; c++) t3[i + c] ^= ~r[(c + 2) % 10] & r[(c + 4) % 10];
    }
    t3[0] ^= os[n], t3[1] ^= ss[n];
  }
  dn(r);
}
var bn = class t2 {
  state;
  pos = 0;
  posOut = 0;
  finished = false;
  state32;
  destroyed = false;
  blockLen;
  suffix;
  outputLen;
  enableXOF = false;
  rounds;
  constructor(e, r, n, s = false, o = 24) {
    if (this.blockLen = e, this.suffix = r, this.outputLen = n, this.enableXOF = s, this.rounds = o, un(n, "outputLen"), !(0 < e && e < 200)) throw new Error("only keccak-f1600 function is supported");
    this.state = new Uint8Array(200), this.state32 = Hr(this.state);
  }
  clone() {
    return this._cloneInto();
  }
  keccak() {
    hn(this.state32), is(this.state32, this.rounds), hn(this.state32), this.posOut = 0, this.pos = 0;
  }
  update(e) {
    ln(this), X(e);
    let { blockLen: r, state: n } = this, s = e.length;
    for (let o = 0; o < s; ) {
      let i = Math.min(r - this.pos, s - o);
      for (let c = 0; c < i; c++) n[this.pos++] ^= e[o++];
      this.pos === r && this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished) return;
    this.finished = true;
    let { state: e, suffix: r, pos: n, blockLen: s } = this;
    e[n] ^= r, (r & 128) !== 0 && n === s - 1 && this.keccak(), e[s - 1] ^= 128, this.keccak();
  }
  writeInto(e) {
    ln(this, false), X(e), this.finish();
    let r = this.state, { blockLen: n } = this;
    for (let s = 0, o = e.length; s < o; ) {
      this.posOut >= n && this.keccak();
      let i = Math.min(n - this.posOut, o - s);
      e.set(r.subarray(this.posOut, this.posOut + i), s), this.posOut += i, s += i;
    }
    return e;
  }
  xofInto(e) {
    if (!this.enableXOF) throw new Error("XOF is not possible for this instance");
    return this.writeInto(e);
  }
  xof(e) {
    return un(e), this.xofInto(new Uint8Array(e));
  }
  digestInto(e) {
    if (Tr(e, this), this.finished) throw new Error("digest() was already called");
    return this.writeInto(e), this.destroy(), e;
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen));
  }
  destroy() {
    this.destroyed = true, dn(this.state);
  }
  _cloneInto(e) {
    let { blockLen: r, suffix: n, outputLen: s, rounds: o, enableXOF: i } = this;
    return e ||= new t2(r, n, s, i, o), e.state32.set(this.state32), e.pos = this.pos, e.posOut = this.posOut, e.finished = this.finished, e.rounds = o, e.suffix = n, e.outputLen = s, e.enableXOF = i, e.destroyed = this.destroyed, e;
  }
};
var Xr = (t3, e, r, n = {}) => kr((s = {}) => new bn(e, t3, s.dkLen === void 0 ? r : s.dkLen, true), n);
var Yr = Xr(31, 168, 16, xn(11));
var ct = Xr(31, 136, 32, xn(12));
function gn(t3) {
  if (!Number.isSafeInteger(t3) || t3 < 0 || t3 > 4294967295) throw new Error("wrong u32 integer:" + t3);
  return t3;
}
function Wr(t3) {
  return gn(t3), (t3 & t3 - 1) === 0 && t3 !== 0;
}
function yn(t3, e) {
  gn(t3);
  let r = 0;
  for (let n = 0; n < e; n++, t3 >>>= 1) r = r << 1 | t3 & 1;
  return r;
}
function Fr(t3) {
  return gn(t3), 31 - Math.clz32(t3);
}
function zr(t3) {
  let e = t3.length;
  if (e < 2 || !Wr(e)) throw new Error("n must be a power of 2 and greater than 1. Got " + e);
  let r = Fr(e);
  for (let n = 0; n < e; n++) {
    let s = yn(n, r);
    if (n < s) {
      let o = t3[n];
      t3[n] = t3[s], t3[s] = o;
    }
  }
  return t3;
}
var wn = (t3, e) => {
  let { N: r, roots: n, dit: s, invertButterflies: o = false, skipStages: i = 0, brp: c = true } = e, f = Fr(r);
  if (!Wr(r)) throw new Error("FFT: Polynomial size should be power of two");
  let u = s !== o;
  return (p) => {
    if (p.length !== r) throw new Error("FFT: wrong Polynomial length");
    s && c && zr(p);
    for (let g = 0, a = 1; g < f - i; g++) {
      let l = s ? g + 1 + i : f - g, B = 1 << l, S = B >> 1, q = r >> l;
      for (let V = 0; V < r; V += B) for (let R = 0, T = a++; R < S; R++) {
        let Z = o ? s ? r - T : T : R * q, Y = V + R, z = V + R + S, et = n[Z], P = p[z], O = p[Y];
        if (u) {
          let W = t3.mul(P, et);
          p[Y] = t3.add(O, W), p[z] = t3.sub(O, W);
        } else o ? (p[Y] = t3.add(P, O), p[z] = t3.mul(t3.sub(P, O), et)) : (p[Y] = t3.add(O, P), p[z] = t3.mul(t3.sub(O, P), et));
      }
    }
    return !s && c && zr(p), p;
  };
};
var mn = Ur;
function En(t3, e) {
  if (t3.length !== e.length) return false;
  let r = 0;
  for (let n = 0; n < t3.length; n++) r |= t3[n] ^ e[n];
  return r === 0;
}
function Bn(t3) {
  if (typeof t3 != "object" || t3 === null || an(t3)) throw new Error("expected opts to be an object");
}
function Te(t3) {
  Bn(t3), t3.context !== void 0 && X(t3.context, void 0, "opts.context");
}
function He(t3) {
  Te(t3), t3.extraEntropy !== false && t3.extraEntropy !== void 0 && X(t3.extraEntropy, void 0, "opts.extraEntropy");
}
function ae(t3, ...e) {
  let r = (s) => typeof s == "number" ? s : s.bytesLen, n = e.reduce((s, o) => s + r(o), 0);
  return { bytesLen: n, encode: (s) => {
    let o = new Uint8Array(n);
    for (let i = 0, c = 0; i < e.length; i++) {
      let f = e[i], u = r(f), p = typeof f == "number" ? s[i] : f.encode(s[i]);
      X(p, u, t3), o.set(p, c), typeof f != "number" && p.fill(0), c += u;
    }
    return o;
  }, decode: (s) => {
    X(s, n, t3);
    let o = [];
    for (let i of e) {
      let c = r(i), f = s.subarray(0, c);
      o.push(typeof i == "number" ? f : i.decode(f)), s = s.subarray(c);
    }
    return o;
  } };
}
function Kt(t3, e) {
  let r = e * t3.bytesLen;
  return { bytesLen: r, encode: (n) => {
    if (n.length !== e) throw new Error(`vecCoder.encode: wrong length=${n.length}. Expected: ${e}`);
    let s = new Uint8Array(r);
    for (let o = 0, i = 0; o < n.length; o++) {
      let c = t3.encode(n[o]);
      s.set(c, i), c.fill(0), i += c.length;
    }
    return s;
  }, decode: (n) => {
    X(n, r);
    let s = [];
    for (let o = 0; o < n.length; o += t3.bytesLen) s.push(t3.decode(n.subarray(o, o + t3.bytesLen)));
    return s;
  } };
}
function wt(...t3) {
  for (let e of t3) if (Array.isArray(e)) for (let r of e) r.fill(0);
  else e.fill(0);
}
function An(t3) {
  return (1 << t3) - 1;
}
var Qr = Uint8Array.of();
function _n(t3, e = Qr) {
  if (X(t3), X(e), e.length > 255) throw new Error("context should be less than 255 bytes");
  return pn(new Uint8Array([0, e.length]), e, t3);
}
var cs = Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2]);
function Jr(t3, e = 0) {
  if (!t3.oid || !En(t3.oid.subarray(0, 10), cs)) throw new Error("hash.oid is invalid: expected NIST hash");
  let r = t3.outputLen * 8 / 2;
  if (e > r) throw new Error("Pre-hash security strength too low: " + r + ", required: " + e);
}
function Sn(t3, e, r = Qr) {
  if (X(e), X(r), r.length > 255) throw new Error("context should be less than 255 bytes");
  let n = t3(e);
  return pn(new Uint8Array([1, r.length]), r, t3.oid, n);
}
var to = (t3) => {
  let { newPoly: e, N: r, Q: n, F: s, ROOT_OF_UNITY: o, brvBits: i, isKyber: c } = t3, f = (R, T = n) => {
    let Z = R % T | 0;
    return (Z >= 0 ? Z | 0 : T + Z | 0) | 0;
  }, u = (R, T = n) => {
    let Z = f(R, T) | 0;
    return (Z > T >> 1 ? Z - T | 0 : Z) | 0;
  };
  function p() {
    let R = e(r);
    for (let T = 0; T < r; T++) {
      let Z = yn(T, i), Y = BigInt(o) ** BigInt(Z) % BigInt(n);
      R[T] = Number(Y) | 0;
    }
    return R;
  }
  let g = p(), a = { add: (R, T) => f((R | 0) + (T | 0)) | 0, sub: (R, T) => f((R | 0) - (T | 0)) | 0, mul: (R, T) => f((R | 0) * (T | 0)) | 0, inv: (R) => {
    throw new Error("not implemented");
  } }, l = { N: r, roots: g, invertButterflies: true, skipStages: c ? 1 : 0, brp: false }, B = wn(a, { dit: false, ...l }), S = wn(a, { dit: true, ...l });
  return { mod: f, smod: u, nttZetas: g, NTT: { encode: (R) => B(R), decode: (R) => {
    S(R);
    for (let T = 0; T < R.length; T++) R[T] = f(s * R[T]);
    return R;
  } }, bitsCoder: (R, T) => {
    let Z = An(R), Y = R * (r / 8);
    return { bytesLen: Y, encode: (z) => {
      let et = new Uint8Array(Y);
      for (let P = 0, O = 0, W = 0, it = 0; P < z.length; P++) for (O |= (T.encode(z[P]) & Z) << W, W += R; W >= 8; W -= 8, O >>= 8) et[it++] = O & An(W);
      return et;
    }, decode: (z) => {
      let et = e(r);
      for (let P = 0, O = 0, W = 0, it = 0; P < z.length; P++) for (O |= z[P] << W, W += 8; W >= R; W -= R, O >>= R) et[it++] = T.decode(O & Z);
      return et;
    } };
  } };
};
var eo = (t3) => (e, r) => {
  r || (r = t3.blockLen);
  let n = new Uint8Array(e.length + 2);
  n.set(e);
  let s = e.length, o = new Uint8Array(r), i = t3.create({}), c = 0, f = 0;
  return { stats: () => ({ calls: c, xofs: f }), get: (u, p) => (n[s + 0] = u, n[s + 1] = p, i.destroy(), i = t3.create({}).update(n), c++, () => (f++, i.xofInto(o))), clean: () => {
    i.destroy(), wt(o, n);
  } };
};
var ke = eo(Yr);
var Ue = eo(ct);
function no(t3) {
  Bn(t3), t3.externalMu !== void 0 && Rr(t3.externalMu, "opts.externalMu");
}
var K = 256;
var Nt = 8380417;
var fs = 1753;
var as = 8347681;
var Pt = 13;
var vn = Math.floor((Nt - 1) / 88) | 0;
var In = Math.floor((Nt - 1) / 32) | 0;
var Ln = { 2: { K: 4, L: 4, D: Pt, GAMMA1: 2 ** 17, GAMMA2: vn, TAU: 39, ETA: 2, OMEGA: 80 }, 3: { K: 6, L: 5, D: Pt, GAMMA1: 2 ** 19, GAMMA2: In, TAU: 49, ETA: 4, OMEGA: 55 }, 5: { K: 8, L: 7, D: Pt, GAMMA1: 2 ** 19, GAMMA2: In, TAU: 60, ETA: 2, OMEGA: 75 } };
var lt = (t3) => new Int32Array(t3);
var { mod: Zt, smod: Ne, NTT: tt, bitsCoder: us } = to({ N: K, Q: Nt, F: as, ROOT_OF_UNITY: fs, newPoly: lt, isKyber: false, brvBits: 8 });
var ro = (t3) => t3;
var ue = (t3, e = ro, r = ro) => us(t3, { encode: (n) => e(r(n)), decode: (n) => r(e(n)) });
var Ut = (t3, e) => {
  for (let r = 0; r < t3.length; r++) t3[r] = Zt(t3[r] + e[r]);
  return t3;
};
var oo = (t3, e) => {
  for (let r = 0; r < t3.length; r++) t3[r] = Zt(t3[r] - e[r]);
  return t3;
};
var ls = (t3) => {
  for (let e = 0; e < K; e++) t3[e] <<= Pt;
  return t3;
};
var le = (t3, e) => {
  for (let r = 0; r < K; r++) if (Math.abs(Ne(t3[r])) >= e) return true;
  return false;
};
var Rt = (t3, e) => {
  let r = lt(K);
  for (let n = 0; n < t3.length; n++) r[n] = Zt(t3[n] * e[n]);
  return r;
};
function Re(t3) {
  let e = lt(K);
  for (let r = 0; r < K; ) {
    let n = t3();
    if (n.length % 3) throw new Error("RejNTTPoly: unaligned block");
    for (let s = 0; r < K && s <= n.length - 3; s += 3) {
      let o = (n[s + 0] | n[s + 1] << 8 | n[s + 2] << 16) & 8388607;
      o < Nt && (e[r++] = o);
    }
  }
  return e;
}
function On(t3) {
  let { K: e, L: r, GAMMA1: n, GAMMA2: s, TAU: o, ETA: i, OMEGA: c } = t3, { CRH_BYTES: f, TR_BYTES: u, C_TILDE_BYTES: p, XOF128: g, XOF256: a, securityLevel: l } = t3;
  if (![2, 4].includes(i)) throw new Error("Wrong ETA");
  if (![1 << 17, 1 << 19].includes(n)) throw new Error("Wrong GAMMA1");
  if (![vn, In].includes(s)) throw new Error("Wrong GAMMA2");
  let B = o * i, S = (h) => {
    let y = Zt(h), w = Ne(y, 2 * s) | 0;
    return y - w === Nt - 1 ? { r1: 0, r0: w - 1 | 0 } : { r1: Math.floor((y - w) / (2 * s)) | 0, r0: w };
  }, q = (h) => S(h).r1, V = (h) => S(h).r0, R = (h, y) => h <= s || h > Nt - s || h === Nt - s && y === 0 ? 0 : 1, T = (h, y) => {
    let w = Math.floor((Nt - 1) / (2 * s)), { r1: m, r0: _ } = S(y);
    return h === 1 ? _ > 0 ? Zt(m + 1, w) | 0 : Zt(m - 1, w) | 0 : m | 0;
  }, Z = (h) => {
    let y = Zt(h), w = Ne(y, 2 ** Pt) | 0;
    return { r1: Math.floor((y - w) / 2 ** Pt) | 0, r0: w };
  }, Y = { bytesLen: c + e, encode: (h) => {
    if (h === false) throw new Error("hint.encode: hint is false");
    let y = new Uint8Array(c + e);
    for (let w = 0, m = 0; w < e; w++) {
      for (let _ = 0; _ < K; _++) h[w][_] !== 0 && (y[m++] = _);
      y[c + w] = m;
    }
    return y;
  }, decode: (h) => {
    let y = [], w = 0;
    for (let m = 0; m < e; m++) {
      let _ = lt(K);
      if (h[c + m] < w || h[c + m] > c) return false;
      for (let v = w; v < h[c + m]; v++) {
        if (v > w && h[v] <= h[v - 1]) return false;
        _[h[v]] = 1;
      }
      w = h[c + m], y.push(_);
    }
    for (let m = w; m < c; m++) if (h[m] !== 0) return false;
    return y;
  } }, z = ue(i === 2 ? 3 : 4, (h) => i - h, (h) => {
    if (!(-i <= h && h <= i)) throw new Error(`malformed key s1/s3 ${h} outside of ETA range [${-i}, ${i}]`);
    return h;
  }), et = ue(13, (h) => (1 << Pt - 1) - h), P = ue(10), O = ue(n === 1 << 17 ? 18 : 20, (h) => Ne(n - h)), W = ue(s === vn ? 6 : 4), it = Kt(W, e), M = ae("publicKey", 32, Kt(P, e)), b = ae("secretKey", 32, 32, u, Kt(z, r), Kt(z, e), Kt(et, e)), x = ae("signature", p, Kt(O, r), Y), d = i === 2 ? (h) => h < 15 ? 2 - h % 5 : false : (h) => h < 9 ? 4 - h : false;
  function E(h) {
    let y = lt(K);
    for (let w = 0; w < K; ) {
      let m = h();
      for (let _ = 0; w < K && _ < m.length; _ += 1) {
        let v = d(m[_] & 15), C = d(m[_] >> 4 & 15);
        v !== false && (y[w++] = v), w < K && C !== false && (y[w++] = C);
      }
    }
    return y;
  }
  let A = (h) => {
    let y = lt(K), w = ct.create({}).update(h), m = new Uint8Array(ct.blockLen);
    w.xofInto(m);
    let _ = m.slice(0, 8);
    for (let v = K - o, C = 8, F = 0, G = 0; v < K; v++) {
      let $ = v + 1;
      for (; $ > v; ) $ = m[C++], !(C < ct.blockLen) && (w.xofInto(m), C = 0);
      y[v] = y[$], y[$] = 1 - ((_[F] >> G++ & 1) << 1), G >= 8 && (F++, G = 0);
    }
    return y;
  }, k = (h) => {
    let y = lt(K), w = lt(K);
    for (let m = 0; m < h.length; m++) {
      let { r0: _, r1: v } = Z(h[m]);
      y[m] = _, w[m] = v;
    }
    return { r0: y, r1: w };
  }, H = (h, y) => {
    for (let w = 0; w < K; w++) h[w] = T(y[w], h[w]);
    return h;
  }, I = (h, y) => {
    let w = lt(K), m = 0;
    for (let _ = 0; _ < K; _++) {
      let v = R(h[_], y[_]);
      w[_] = v, m += v;
    }
    return { v: w, cnt: m };
  }, U = 32, N = ae("seed", 32, 64, 32), j = { info: { type: "internal-ml-dsa" }, lengths: { secretKey: b.bytesLen, publicKey: M.bytesLen, seed: 32, signature: x.bytesLen, signRand: U }, keygen: (h) => {
    let y = new Uint8Array(34), w = h === void 0;
    w && (h = mn(32)), X(h, 32, "seed"), y.set(h), w && wt(h), y[32] = e, y[33] = r;
    let [m, _, v] = N.decode(ct(y, { dkLen: N.bytesLen })), C = a(_), F = [];
    for (let L = 0; L < r; L++) F.push(E(C.get(L & 255, L >> 8 & 255)));
    let G = [];
    for (let L = r; L < r + e; L++) G.push(E(C.get(L & 255, L >> 8 & 255)));
    let $ = F.map((L) => tt.encode(L.slice())), Q = [], nt = [], mt = g(m), J = lt(K);
    for (let L = 0; L < e; L++) {
      wt(J);
      for (let at = 0; at < r; at++) {
        let yt = Re(mt.get(at, L));
        Ut(J, Rt(yt, $[at]));
      }
      tt.decode(J);
      let { r0: dt, r1: ft } = k(Ut(J, G[L]));
      Q.push(dt), nt.push(ft);
    }
    let gt = M.encode([m, nt]), Et = ct(gt, { dkLen: u }), Gt = b.encode([m, v, Et, F, G, Q]);
    return mt.clean(), C.clean(), wt(m, _, v, F, G, $, J, Q, nt, Et, y), { publicKey: gt, secretKey: Gt };
  }, getPublicKey: (h) => {
    let [y, w, m, _, v, C] = b.decode(h), F = g(y), G = _.map((nt) => tt.encode(nt.slice())), $ = [], Q = lt(K);
    for (let nt = 0; nt < e; nt++) {
      Q.fill(0);
      for (let J = 0; J < r; J++) {
        let gt = Re(F.get(J, nt));
        Ut(Q, Rt(gt, G[J]));
      }
      tt.decode(Q), Ut(Q, v[nt]);
      let { r1: mt } = k(Q);
      $.push(mt);
    }
    return F.clean(), wt(Q, G, C, _, v), M.encode([y, $]);
  }, sign: (h, y, w = {}) => {
    He(w), no(w);
    let { extraEntropy: m, externalMu: _ = false } = w, [v, C, F, G, $, Q] = b.decode(y), nt = [], mt = g(v);
    for (let L = 0; L < e; L++) {
      let dt = [];
      for (let ft = 0; ft < r; ft++) dt.push(Re(mt.get(ft, L)));
      nt.push(dt);
    }
    mt.clean();
    for (let L = 0; L < r; L++) tt.encode(G[L]);
    for (let L = 0; L < e; L++) tt.encode($[L]), tt.encode(Q[L]);
    let J = _ ? h : ct.create({ dkLen: f }).update(F).update(h).digest(), gt = m === false ? new Uint8Array(32) : m === void 0 ? mn(U) : m;
    X(gt, 32, "extraEntropy");
    let Et = ct.create({ dkLen: f }).update(C).update(gt).update(J).digest();
    X(Et, f);
    let Gt = a(Et, O.bytesLen);
    t: for (let L = 0; ; ) {
      let dt = [];
      for (let D = 0; D < r; D++, L++) dt.push(O.decode(Gt.get(L & 255, L >> 8)()));
      let ft = dt.map((D) => tt.encode(D.slice())), at = [];
      for (let D = 0; D < e; D++) {
        let te = lt(K);
        for (let It = 0; It < r; It++) Ut(te, Rt(nt[D][It], ft[It]));
        tt.decode(te), at.push(te);
      }
      let yt = at.map((D) => D.map(q)), Jt = ct.create({ dkLen: p }).update(J).update(it.encode(yt)).digest(), de = tt.encode(A(Jt)), he = G.map((D) => Rt(D, de));
      for (let D = 0; D < r; D++) if (Ut(tt.decode(he[D]), dt[D]), le(he[D], n - B)) continue t;
      let Tn = 0, Me = [];
      for (let D = 0; D < e; D++) {
        let te = tt.decode(Rt($[D], de)), It = oo(at[D], te).map(V);
        if (le(It, s - B)) continue t;
        let Hn = tt.decode(Rt(Q[D], de));
        if (le(Hn, s)) continue t;
        Ut(It, Hn);
        let kn = I(It, yt[D]);
        Me.push(kn.v), Tn += kn.cnt;
      }
      if (Tn > c) continue;
      Gt.clean();
      let so = x.encode([Jt, he, Me]);
      return wt(Jt, he, Me, de, yt, at, ft, dt, Et, J, G, $, Q, ...nt), so;
    }
    throw new Error("Unreachable code path reached, report this error");
  }, verify: (h, y, w, m = {}) => {
    no(m);
    let { externalMu: _ = false } = m, [v, C] = M.decode(w), F = ct(w, { dkLen: u });
    if (h.length !== x.bytesLen) return false;
    let [G, $, Q] = x.decode(h);
    if (Q === false) return false;
    for (let L = 0; L < r; L++) if (le($[L], n - B)) return false;
    let nt = _ ? y : ct.create({ dkLen: f }).update(F).update(y).digest(), mt = tt.encode(A(G)), J = $.map((L) => L.slice());
    for (let L = 0; L < r; L++) tt.encode(J[L]);
    let gt = [], Et = g(v);
    for (let L = 0; L < e; L++) {
      let dt = Rt(tt.encode(ls(C[L])), mt), ft = lt(K);
      for (let yt = 0; yt < r; yt++) {
        let Jt = Re(Et.get(yt, L));
        Ut(ft, Rt(Jt, J[yt]));
      }
      let at = tt.decode(oo(ft, dt));
      gt.push(H(at, Q[L]));
    }
    Et.clean();
    let Gt = ct.create({ dkLen: p }).update(nt).update(it.encode(gt)).digest();
    for (let L of Q) if (!(L.reduce((ft, at) => ft + at, 0) <= c)) return false;
    for (let L of $) if (le(L, n - B)) return false;
    return En(G, Gt);
  } };
  return { info: { type: "ml-dsa" }, internal: j, securityLevel: l, keygen: j.keygen, lengths: j.lengths, getPublicKey: j.getPublicKey, sign: (h, y, w = {}) => {
    He(w);
    let m = _n(h, w.context), _ = j.sign(m, y, w);
    return wt(m), _;
  }, verify: (h, y, w, m = {}) => (Te(m), j.verify(h, _n(y, m.context), w)), prehash: (h) => (Jr(h, l), { info: { type: "hashml-dsa" }, securityLevel: l, lengths: j.lengths, keygen: j.keygen, getPublicKey: j.getPublicKey, sign: (y, w, m = {}) => {
    He(m);
    let _ = Sn(h, y, m.context), v = j.sign(_, w, m);
    return wt(_), v;
  }, verify: (y, w, m, _ = {}) => (Te(_), j.verify(y, Sn(h, w, _.context), m)) }) };
}
var yi = On({ ...Ln[2], CRH_BYTES: 64, TR_BYTES: 64, C_TILDE_BYTES: 32, XOF128: ke, XOF256: Ue, securityLevel: 128 });
var ds = On({ ...Ln[3], CRH_BYTES: 64, TR_BYTES: 64, C_TILDE_BYTES: 48, XOF128: ke, XOF256: Ue, securityLevel: 192 });
var wi = On({ ...Ln[5], CRH_BYTES: 64, TR_BYTES: 64, C_TILDE_BYTES: 64, XOF128: ke, XOF256: Ue, securityLevel: 256 });

// economy/lib/verify-worker.mjs
var b64 = (s) => new Uint8Array(Buffer.from(s, "base64"));
function checkTx(raw, chainId = 9127n) {
  try {
    const tx = Transaction.from(raw);
    if (!tx.signature || !tx.from) return { hash: tx.hash, ok: false, reason: "unsigned" };
    if (tx.chainId !== chainId) return { hash: tx.hash, from: tx.from, ok: false, reason: "wrong-chain" };
    if (tx.gasLimit < 21000n) return { hash: tx.hash, from: tx.from, ok: false, reason: "intrinsic-gas" };
    const price = tx.type === 2 ? tx.maxFeePerGas : tx.gasPrice;
    return {
      hash: tx.hash,
      from: tx.from,
      nonce: tx.nonce,
      maxCost: (tx.gasLimit * (price ?? 0n) + tx.value).toString(),
      gasPrice: (price ?? 0n).toString(),
      ok: true
    };
  } catch (e) {
    return { hash: null, ok: false, reason: "decode:" + String(e.shortMessage || e.message).slice(0, 60) };
  }
}
if (parentPort) parentPort.on("message", ({ id, type, items }) => {
  let out;
  if (type === "tx") out = items.map((raw) => checkTx(raw));
  else if (type === "mldsa") out = items.map(({ pk, msg, sig }) => {
    try {
      return ds.verify(b64(sig), b64(msg), b64(pk));
    } catch {
      return false;
    }
  });
  parentPort.postMessage({ id, out });
});
export {
  checkTx
};
